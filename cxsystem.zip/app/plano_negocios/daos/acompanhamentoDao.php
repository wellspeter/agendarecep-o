<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class AcompanhamentoDao extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }

    public function buscaDadosFiltro()
    {
        $sql = "SELECT C.[co_cnpj]
                ,[no_cliente]
                ,[no_segmento_curto]
                ,[ic_tipo]
                ,[co_pv]
                ,[no_pv]
                ,[no_pv_codigo]
                ,[co_seg]
                ,[no_seg]
                ,[co_sr]
                ,[no_sr]
                ,[co_suv]
                ,[no_suv]
                ,[sg_suv]
                ,[co_seh]
                ,[no_seh]
                ,[co_sev]
                ,[no_sev]
            FROM 
            [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] C
            INNER JOIN [DB5131_GOV].[recepcao].T003_MUNICIPIOS_PRIORITARIOS P ON C.co_cnpj = P.CO_CNPJ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }
}
