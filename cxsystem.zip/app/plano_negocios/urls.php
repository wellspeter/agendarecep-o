<?php

/**********************Principal  *********************** */
CxRouter::addUrl(
  'planonegocios',
  'plano_negocios/views/acompanhamento.php',
  $name = 'planonegocios:acompanhamento'
);

// /********************** lista de municipios do estado para confirmação dos convidados *********************** */
// CxRouter::addUrl(
//   'eventos/listaEventosConfirmados/',
//   'eventos/views/relatoriosListaEvento.php',
//   $name = 'eventos:eventosImpressaoConvidados'
// );

// CxRouter::addUrl(
//   'eventos/listConvidadosEvento/<estado>',
//   'eventos/views/relatorioListaConvidadosEvento.php',
//   $name = 'eventos:relatorioListaConvidadosEvento'
// );


// /********************** relatorios de convidados presentes no dia do evento *********************** */
// CxRouter::addUrl(
//   'eventos/presentesDiaEvento/',
//   'eventos/views/relatorioPresentesDiaEvento.php',
//   $name = 'eventos:relatorioPresentesDiaEvento'
// );

// CxRouter::addUrl(
//   'eventos/presentesDiaEventoConvidados/<estado>',
//   'eventos/views/relatorioPresentesDiaEventoConvidados.php',
//   $name = 'eventos:relatorioPresentesDiaEventoConvidados'
// );


// /********************** CONFIRMACAO *********************** */
// CxRouter::addUrl(
//   'eventos/confirmacao/',
//   'eventos/views/indexConfirmacao.php',
//   $name = 'eventos:indexConfirmacao'
// );

// /********************** lista de municipios do estado *********************** */
// CxRouter::addUrl(
//   'eventos/<estado>',
//   'eventos/views/municipios-evento.php',
//   $name = 'eventos:municipios-evento'
// );

// CxRouter::addUrl(
//   'eventos/seg/<estado>',
//   'eventos/views/municipiosEventoSeg.php',
//   $name = 'eventos:municipiosEventoSeg'
// );


// /********************** lista de municipios do estado para confirmação dos convidados *********************** */
// CxRouter::addUrl(
//   'eventos/confirmacao/<estado>',
//   'eventos/views/confirmaConvidadoEvento.php',
//   $name = 'eventos:municipiosConfirmacaoEvento'
// );








/*******************************
 * 
 * Chamadas de API
 * 
 ******************************/

CxRouter::addApiUrl(
  'planonegocios/consultaDadosFiltro',
  'plano_negocios/api/consultaDadosFiltro.php',
  $name = 'planonegocios:api:consultaDadosFiltro'
);

// CxRouter::addApiUrl(
//   'eventos/consultarDadosContatoCPF/<cpf>/<uf>',
//   'eventos/api/consultarDadosContatoCPF.php',
//   $name = 'eventos:api:consultarDadosContatoCPF'
// );

// CxRouter::addApiUrl(
//   'eventos/inserirContatoEvento',
//   'eventos/api/salvarContatoEvento.php',
//   $name = 'eventos:api:salvarContatoEvento'
// );


// CxRouter::addApiUrl(
//   'eventos/iteEvento',
//   'eventos/api/salvarContEvento.php',
//   $name = 'eventos:api:salvarContEvento'
// );

// CxRouter::addApiUrl(
//   'eventos/quantidadeconfirmados/<uf>',
//   'eventos/api/consultarDadosConfirmadosEvento.php',
//   $name = 'eventos:api:obterContagemEvento'
// );



