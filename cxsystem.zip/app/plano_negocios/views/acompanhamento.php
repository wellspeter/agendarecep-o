<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

// require_once(__DIR__ . '/../daos/indexDao.php');
// $dao = new indexDAO();
// $datainsert = new Datetime();
// $dataEnvio = $datainsert->format('Y-m-d');
// $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-1">
    <div class="col-12">
      <h4 class="">Acompanhamento</h4>
    </div>
  </div>
  <div class="row justify-content-md-left">
    <div class="col-3">
      <div class="form-group">
        <label for="first-name-vertical">SURVs</label>
        <select class="select form-control" id="comboboxSurv" name="comboboxSurv">
          <option value="">Selecione...</option>


        </select>
      </div>
    </div>
    <div class="col-3">
      <div class="form-group">
        <label for="first-name-vertical">SEGs</label>
        <select class="select form-control" id="comboboxSegs" name="comboboxSegs">
          <option value="square">Selecione...</option>

        </select>
      </div>
    </div>
    <div class="col-3">
      <div class="form-group">
        <label for="first-name-vertical">Municípios</label>
        <select class="select form-control" id="comboboxMunic" name="comboboxMunic">
          <option value="square">Selecione...</option>
        </select>
      </div>
    </div>
    <div class="col-2">
      <div class="form-group">
        <label for="first-name-vertical">Data</label>
        <select class="select form-control" id="comboboxData">
          <option value="square">Selecione...</option>
        </select>
      </div>
    </div>
    <div class="col-1">
      <div class="form-group mt-2">
        <button type="submit" class="btn btn-primary mr-1">Buscar</button>
      </div>
    </div>
  </div>

  <hr>

  <div class="row">

    <div class="col-2 pr-md-0">
      <div class="card " style="height:200px">
        <div class="card-body text-center">
          <div id="realizado-Chart" style="margin-top: -50px;"></div>
          <h6 class="mt-0"> % Plano de Neg </h6>
        </div>
      </div>

      <div class="card " style="height:200px">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h6 class="">Histórico de variação</h6>
        </div>
        <div class="card-body p-0">
          <div id="variacao-mes-chart"></div>
        </div>
      </div>

      <div class="card " style="height:200px">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h6 class="">Oportunidades no Plano de GO, Debate e Notícias </h6>
        </div>
        <div class="card-body p-1">
          <div class="badge badge-pill badge-light-primary ">CPP</div>
          <div class="badge badge-pill badge-light-primary ">FINISA</div>
          <div class="badge badge-pill badge-light-primary ">Pró-Cidades</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">Pró-Moradia</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
          <div class="badge badge-pill badge-light-primary mr-0 mb-0">CPP</div>
        </div>
      </div>

    </div>
    <div class="col-3 pr-md-0">
      <div class="card h-100">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h6 class="">Por Unidade</h6>
        </div>
        <div class="card-body text-center">
          <div class="table-responsive">
            <table id="table-extended-transactions" class="table mb-0">
              <thead>
                <tr>
                  <th>Unidade</th>
                  <th>Nota</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="align-items-left"><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
                <tr>
                  <td><span>Unidade </span></td>
                  <td class="text-bold-600">90%n</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="col-7 pr-md-0">
      <div class="card h-100">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h6 class="">Por Item</h6>
        </div>
        <div class="card-body text-center">
          <table class="table table-striped table-bordered complex-headers" id="table-produtos">
            <thead>
              <tr>
                <th rowspan="2" class="align-top">Produto</th>
                <th rowspan="2">Expectativa</th>
                <th rowspan="2">Informado</th>
                <th rowspan="2">*Realizado</th>
                <th rowspan="2">%</th>
                <th colspan="3">Preenchimento</th>
                <th rowspan="2">Neg. em R$</th>
              </tr>
              <tr>
                <th>Sim</th>
                <th>Não</th>
                <th>NSA</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
              <tr>
                <td>Folha de Pagto</td>
                <td>250</td>
                <td>220</td>
                <td>222</td>
                <td>110,9%</td>
                <td>220</td>
                <td>28</td>
                <td>02</td>
                <td>20 BI</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</div>

<script>
  $(document).ready(function() {

    // setando todas as variaveis usadas no sistema
    var $primary = '#5A8DEE',
      $success = '#39DA8A',
      $danger = '#FF5B5C',
      $warning = '#FDAC41',
      $info = '#00CFDD',
      $secondary = '#828D99',
      $label_color_light = '#E6EAEE',
      $secondary_light = '#e7edf3',
      $light_primary = "#E2ECFF";

    var themeColors = [$primary, $warning, $danger, $success, $info, $secondary, $label_color_light, $secondary_light, $light_primary];


    // Lista de meses de julho a dezembro
    const meses = [{
        value: "07",
        label: "Julho"
      },
      {
        value: "08",
        label: "Agosto"
      },
      {
        value: "09",
        label: "Setembro"
      },
      {
        value: "10",
        label: "Outubro"
      },
      {
        value: "11",
        label: "Novembro"
      },
      {
        value: "12",
        label: "Dezembro"
      }
    ];


    let itensFiltro;
    let itensArray = [];

    // Listagem dos elementos da pagina
    const comboSurv = document.getElementById("comboboxSurv");
    const comboSeg = document.getElementById("comboboxSegs");
    const comboMunic = document.getElementById("comboboxMunic");
    const comboData = document.getElementById("comboboxData");

    buscarDadosfiltros();

    function buscarDadosfiltros() {
      $.ajax({
        type: 'GET',
        url: '/agendarecepcao/planonegocios/consultaDadosFiltro',
        success: function(response) {
          try {
            itensFiltro = response;
            itensArray = JSON.parse(itensFiltro);
            preencherCombos();
          } catch (e) {
            console.error("Erro ao fazer parse de itensFiltro:", e);
          }
        },
        error: function() {
          alert('Ocorreu um erro ao buscar os dados.');
        }
      });
    }

    function preencherCombos() {
      const survs = [...new Map(itensArray.map(item => [item.co_suv, item])).values()];
      comboSurv.innerHTML = '<option value="">Selecione...</option>';
      survs.forEach(item => {
        comboSurv.innerHTML += `<option value="${item.co_suv}">${item.sg_suv.trim()}</option>`;
      });
    }

    comboSurv.addEventListener("change", function() {
      const segsFiltrados = itensArray.filter(item => item.co_suv === this.value);
      const segsUnicos = [...new Map(segsFiltrados.map(item => [item.co_seg, item])).values()];
      comboSeg.innerHTML = '<option value="">Selecione...</option>';
      comboMunic.innerHTML = '<option value="">Selecione...</option>'; // limpa municípios
      segsUnicos.forEach(item => {
        comboSeg.innerHTML += `<option value="${item.co_seg}">${item.no_seg}</option>`;
      });
    });

    comboSeg.addEventListener("change", function() {
      const municsFiltrados = itensArray.filter(item => item.co_seg === this.value);
      const municsUnicos = [...new Map(municsFiltrados.map(item => [item.co_cnpj, item])).values()];
      comboMunic.innerHTML = '<option value="">Selecione...</option>';
      municsUnicos.forEach(item => {
        comboMunic.innerHTML += `<option value="${item.co_cnpj}">${item.no_cliente}</option>`;
      });
    });


    /******** Preenchimento dos meses ********** */


    // Limpa o combo
    comboData.innerHTML = '<option value="">Selecione...</option>';

    // Mês atual
    const mesAtual = new Date().getMonth() + 1; // getMonth() retorna 0-11
    meses.forEach(mes => {
      const option = document.createElement("option");
      option.value = mes.value;
      option.textContent = mes.label;
      option.disabled = parseInt(mes.value) > mesAtual;
      comboData.appendChild(option);
    });









    /***************     CONFIGURAÇÕES    *************** */

    /****************************************
     *       js of zero configuration        *
     ****************************************/

    $('.zero-configuration').DataTable();

    /********************************************
     *        js of Order by the grouping        *
     ********************************************/

    var groupingTable = $('.row-grouping').DataTable({
      "columnDefs": [{
        "visible": false,
        "targets": 2
      }],
      "order": [
        [2, 'asc']
      ],
      "displayLength": 10,
      "drawCallback": function(settings) {
        var api = this.api();
        var rows = api.rows({
          page: 'current'
        }).nodes();
        var last = null;

        api.column(2, {
          page: 'current'
        }).data().each(function(group, i) {
          if (last !== group) {
            $(rows).eq(i).before(
              '<tr class="group"><td colspan="5">' + group + '</td></tr>'
            );

            last = group;
          }
        });
      }
    });

    $('.row-grouping tbody').on('click', 'tr.group', function() {
      var currentOrder = groupingTable.order()[0];
      if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
        groupingTable.order([2, 'desc']).draw();
      } else {
        groupingTable.order([2, 'asc']).draw();
      }
    });

    /*************************************
     *       js of complex headers        *
     *************************************/

    $('.complex-headers').DataTable();


    /*****************************
     *       js of Add Row        *
     ******************************/

    var t = $('.add-rows').DataTable();
    var counter = 2;

    $('#addRow').on('click', function() {
      t.row.add([
        counter + '.1',
        counter + '.2',
        counter + '.3',
        counter + '.4',
        counter + '.5'
      ]).draw(false);

      counter++;
    });


    /**************************************************************
     * js of Tab for COLUMN SELECTORS WITH EXPORT AND PRINT OPTIONS *
     ***************************************************************/

    $('.dataex-html5-selectors').DataTable({
      dom: 'Bfrtip',
      buttons: [{
          extend: 'copyHtml5',
          exportOptions: {
            columns: [0, ':visible']
          }
        },
        {
          extend: 'pdfHtml5',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          text: 'JSON',
          action: function(e, dt, button, config) {
            var data = dt.buttons.exportData();

            $.fn.dataTable.fileSave(
              new Blob([JSON.stringify(data)]),
              'Export.json'
            );
          }
        },
        {
          extend: 'print',
          exportOptions: {
            columns: ':visible'
          }
        }
      ]
    });

    /**************************************************
     *       js of scroll horizontal & vertical        *
     **************************************************/

    $('.scroll-horizontal-vertical').DataTable({
      "scrollY": 200,
      "scrollX": true
    });


    /**************************************************
     *                     Graficos                   *
     **************************************************/

    // Grafico de % conclusão da meta   
    // ------------------------------
    var realizadoChartOptions = {
      chart: {
        height: 220,
        type: 'radialBar',
        sparkline: {
          show: true
        }
      },
      grid: {
        show: false,
      },
      colors: [$success],
      plotOptions: {
        radialBar: {
          size: 100,
          startAngle: -135,
          endAngle: 135,
          offsetY: 10,
          hollow: {
            size: '60%',
          },
          track: {
            strokeWidth: '90%',
            background: '#fff'
          },
          dataLabels: {
            value: {
              offsetY: -10,
              color: '#475f7b',
              fontSize: '26px'
            },
            name: {
              fontSize: '15px',
              color: "#596778",
              offsetY: 30
            },
          }
        }
      },
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          type: 'horizontal',
          shadeIntensity: 0.5,
          gradientToColors: [$primary],
          inverseColors: true,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 100]
        },
      },
      stroke: {
        dashArray: 3
      },
      series: [78],
      labels: ['Realizado'],
    }

    var realizadoChart = new ApexCharts(
      document.querySelector("#realizado-Chart"),
      realizadoChartOptions
    );

    realizadoChart.render();




    // Grafico de % conclusão da meta   
    // ------------------------------
    var orderSummaryChartOptions = {
      chart: {
        height: 130,
        type: 'line',
        stacked: false,
        toolbar: {
          show: false,
        },
        sparkline: {
          enabled: true
        },
      },
      colors: [$primary, $primary],
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: 'smooth',
        width: 2.5,
        dashArray: [0, 8]
      },
      fill: {
        type: 'gradient',
        gradient: {
          inverseColors: false,
          shade: 'light',
          type: "vertical",
          gradientToColors: [$light_primary, $primary],
          opacityFrom: 0.7,
          opacityTo: 0.55,
          stops: [0, 80, 100]
        }
      },
      series: [{
        name: 'This Month',
        data: [165, 175, 162, 173, 160, 195, 160, 170, 160, 190, 180],
        type: 'area',
      }, {
        name: 'Last Months',
        data: [168, 168, 155, 178, 155, 170, 190, 160, 150, 170, 140],
        type: 'line',
      }],

      xaxis: {
        offsetY: -50,
        categories: ['', 1, 2, 3, 4, 5, 6, 7, 8, 9, ''],
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        labels: {
          show: true,
          style: {
            colors: $secondary
          }
        }
      },
      tooltip: {
        x: {
          show: false
        }
      },
    }

    var orderSummaryChart = new ApexCharts(
      document.querySelector("#variacao-mes-chart"),
      orderSummaryChartOptions
    );

    orderSummaryChart.render();





    if ($.fn.DataTable.isDataTable('#table-produtos')) {
      $('#table-produtos').DataTable().destroy();
    }

    $('#table-produtos').DataTable({
      paging: false,
      searching: false,
      info: false,
      lengthChange: false,
      retrieve: true // garante que os dados existentes no HTML sejam mantidos
    });


  });
</script>