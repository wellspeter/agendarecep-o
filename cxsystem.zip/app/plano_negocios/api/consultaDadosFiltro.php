<?php

require_once(__DIR__ . '/../daos/acompanhamentoDao.php');

$uf = CxRequest::params('uf');

$dao = new AcompanhamentoDao();

// busca de dados para montar os filtros do filtro
$dados = $dao->buscaDadosFiltro();

echo json_encode($dados);
