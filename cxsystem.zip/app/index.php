<section class="kb-content">
    <div class="row justify-content-center">
        <!-- <img style="width: 50%; heigth:50%" alt="aguarde" src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/pg_manutencao_recepcao.png"/> -->
         <div class="col-12 m-0 p-0">
            <!-- <img style="width: 50%; heigth:50%" alt="aguarde" src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/pg_manutencao_recepcao.png"/> -->
            <div class="row match-height">
                <div class="col-4">
                    <div class="col-12 kb-search-content">
                        <div class="card kb-hover-1">
                            <div class="text-right">
                                <span class="badge badge-primary"><small>NOVO</small></span>
                            </div>

                            <div class="card-body text-center">
                                <a href="<?php echo CxUrl::site('rep_eleitos:acao_index') ?>">
                                    <div class=" mb-1">
                                        <i class="livicon-evo" data-options="name: users.svg; size: 50px; strokeColorAlt: #FDAC41; strokeColor: #5A8DEE; style: lines-alt; eventOn: .kb-hover-1;"></i>
                                    </div>
                                    <h5>Ações de Relacionamentos</h5>
                                    <p class=" text-muted">Registrar ações e da Agenda</p>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 kb-search-content">
                        <div class="card kb-hover-1">
                            <div class="text-right">
                                <span class="badge badge-primary"><small>NOVO</small></span>
                            </div>

                            <div class="card-body text-center">
                                <a href="<?php echo CxUrl::site('rep_eleitos:plano_negocio_index') ?>">
                                    <div class=" mb-1">
                                        <i class="livicon-evo" data-options="name: comment.svg; size: 50px; strokeColorAlt: #FDAC41; strokeColor: #5A8DEE; style: lines-alt; eventOn: .kb-hover-1;"></i>
                                    </div>
                                    <h5>Plano de Negócio</h5>
                                    <p class=" text-muted">Construir o Plano de Negócio dos municípios prioritários.</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-2"></div>
                <div class="col-6">
                <img style="width: 50%; heigth:50%;  margin-left: 50%;" alt="aguarde" src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/mapa_brasil.png"/>
                </div>
            </div>
<!-- 
            <div class="row match-height">
                <div class="col-md-4 col-sm-6 kb-search-content">
                    <div class="card kb-hover-1">
                        <div class="text-right">
                            <span class="badge badge-primary"><small>NOVO</small></span>
                        </div>

                        <div class="card-body text-center">
                            <a href="<?php echo CxUrl::site('rep_eleitos:plano_negocio_index') ?>">
                                <div class=" mb-1">
                                    <i class="livicon-evo" data-options="name: users.svg; size: 50px; strokeColorAlt: #FDAC41; strokeColor: #5A8DEE; style: lines-alt; eventOn: .kb-hover-1;"></i>
                                </div>
                                <h5>Plano de Negócio</h5>
                                <p class=" text-muted">Construir o Plano de Negócio dos municípios prioritários.</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div> -->
        </div> 
    </div>
</section>
<!-- Knowledge base ends -->