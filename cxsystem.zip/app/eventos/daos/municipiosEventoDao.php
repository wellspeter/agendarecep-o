<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class municipiosEventoDao extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }

    public function buscaArvoreAcessoPorMatricula($matricula, $data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = " . $matricula . "
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '" . $data . "'
	            AND DT_FIM_ACESSO > '" . $data . "'
        ";
        return $this->buscar_lista($sql, array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorMatricula_homol($matricula, $data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = " . $matricula . "
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '" . $data . "'
	            AND DT_FIM_ACESSO > '" . $data . "'
        ";
        return $this->buscar_lista($sql, array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorUnidade($unidade)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                WHERE NU_UNIDADE = :unidade AND DT_FIM_ACESSO IS NULL AND [ID_TIPO_ACESSO] = 'U'
                GROUP BY 
                     [NU_MATRICULA]
                    ,[NU_UNIDADE]
                    ,[NO_UNIDADE]
                    ,[DT_INICIO_ACESSO]
                    ,[DT_FIM_ACESSO]
                    ,[IDENTIFICACAO_UNIDADE]
                    ,[IDENTIFICACAO_UNIDADE_TIPO]
                    ,[DT_INSERT]
                    ,[ID_TIPO_ACESSO]
                    ,[NIVEL_ACESSO_EDITAR]
                    ,[NIVEL_ACESSO_CONSULTAR]";
        return $this->buscar_lista($sql, array(':unidade' => $unidade));
    }

    public function buscaMunicipiosEventoEstado($estado)
    {
        // $sql = "SELECT 
        //         CASE
        //             WHEN mp.co_cnpj IS NULL THEN 0
        //             ELSE 1
        //         END AS MUNICIPIO_PRIORITARIO
        //         ,c.[CO_CNPJ] as CNPJ
        //         ,[no_cliente] as NOME_MUNICIPIO
        //         ,[ic_capital] as CAPITAL
        //         ,[sg_uf] AS UF
        //         ,[no_segmento_curto] AS NOME_SEGMENTO
        //         ,[co_seg] AS CODIGO_SEG
        //         ,[no_seg] AS NOME_SEG
        //        	,CASE
        //             WHEN cadastro_principal IS NULL THEN 0
        //             WHEN cadastro_principal = 0 THEN 0
        //             ELSE 1
        //         END AS cadastro_principal

        //     FROM 
        //         [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] as c
        //         left join [DB5131_GOV].[recepcao].[T003_MUNICIPIOS_PRIORITARIOS] as mp on mp.CO_CNPJ = c.CO_CNPJ
        //         left join [DB5131_GOV].[recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] as e on  e.CO_CNPJ = c.CO_CNPJ
        //         where ic_tipo = 'M' and sg_uf = :estado 
        //         order by MUNICIPIO_PRIORITARIO desc
        //     ";
         $sql = "SELECT 
                    CASE
                        WHEN mp.co_cnpj IS NULL THEN 0
                        ELSE 1
                    END AS MUNICIPIO_PRIORITARIO
                    ,c.[CO_CNPJ] as CNPJ
                    ,[no_cliente] as NOME_MUNICIPIO
                    ,[ic_capital] as CAPITAL
                    ,[sg_uf] AS UF
                    ,[no_segmento_curto] AS NOME_SEGMENTO
                    ,[co_seg] AS CODIGO_SEG
                    ,[no_seg] AS NOME_SEG
                    ,CASE
                        WHEN cadastro_principal IS NULL THEN 0
                        WHEN cadastro_principal = 0 THEN 0
                        ELSE 1
                    END AS cadastro_principal
                FROM 
                    [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] as c
                    left join [DB5131_GOV].[recepcao].[T003_MUNICIPIOS_PRIORITARIOS] as mp on mp.CO_CNPJ = c.CO_CNPJ
                    left join (
                        select CO_CNPJ, MAX(cadastro_principal) AS cadastro_principal from  [DB5131_GOV].[recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] group by CO_CNPJ
                    ) as e on  e.CO_CNPJ = c.CO_CNPJ
                    where ic_tipo = 'M' 
                    and sg_uf = :estado  
                    order by MUNICIPIO_PRIORITARIO desc
                ";
        return $this->buscar_lista($sql, array(':estado' => $estado));
    }

    public function verificarExistenciaCNPJ($cnpj)
    {
        $sql = "SELECT * FROM [recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] WHERE CO_CNPJ = :cnpj and cadastro_antecipado = 1 and cadastro_principal = 1 ";
        return $this->buscar_lista($sql, array(':cnpj' => $cnpj));
    }

    public function municipiosPorUf($uf)
    {
        $sql = "SELECT 
                    [no_cliente] as nome 
                    ,[CO_CNPJ] as cnpj
                    ,[ic_tipo] as tipo
                FROM [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] 
                where sg_uf = :uf ";
        return $this->buscar_lista($sql, array(':uf' => $uf));
    }


    public function inserirContatosMunicipio($data)
    {
        $sql = "INSERT INTO [recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] (
                    CO_CNPJ,
                    nomeCont1,
                    cpfCont1,
                    celularCont1,
                    emailCont1,
                    nomeCont2,
                    cpfCont2,
                    celularCont2,
                    emailCont2,
                    NU_EVENTO,
                    DT_INSERT,
                    NU_MATRICULA_INSERT,
                    cadastro_antecipado,
                    cadastro_principal
                ) VALUES (
                    :cnpj,
                    :nomeCont1,
                    :cpfCont1,
                    :celularCont1,
                    :emailCont1,
                    :nomeCont2,
                    :cpfCont2,
                    :celularCont2,
                    :emailCont2,
                    :NU_EVENTO,
                    :datainsert,
                    :matricula,
                    1,
                    1
                )";

        return $this->inserir($sql, array(
            ':cnpj' => $data['cnpj'],
            ':nomeCont1' => $data['nomeCont1'],
            ':cpfCont1' => $data['cpfCont1'],
            ':celularCont1' => $data['celularCont1'],
            ':emailCont1' => $data['emailCont1'],
            ':nomeCont2' => $data['nomeCont2'],
            ':cpfCont2' => $data['cpfCont2'],
            ':celularCont2' => $data['celularCont2'],
            ':emailCont2' => $data['emailCont2'],
            ':NU_EVENTO' => $data['NU_EVENTO'],
            ':datainsert' => $data['datainsert'],
            ':matricula' => $data['matricula']
        ));
    }

    public function atualizarContatosMunicipio($data)
    {
        $sql = "UPDATE [recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO]
                SET 
                    nomeCont1 = :nomeCont1,
                    cpfCont1 = :cpfCont1,
                    celularCont1 = :celularCont1,
                    emailCont1 = :emailCont1,
                    nomeCont2 = :nomeCont2,
                    cpfCont2 = :cpfCont2,
                    celularCont2 = :celularCont2,
                    emailCont2 = :emailCont2,
                    NU_EVENTO = :NU_EVENTO,
                    DT_INSERT = :datainsert,
                    NU_MATRICULA_INSERT = :matricula,
                    cadastro_antecipado = 1,
                    cadastro_principal = 1
                WHERE CO_CNPJ = :cnpj";

        return $this->atualizar($sql, array(
            ':cnpj' => $data['cnpj'],
            ':nomeCont1' => $data['nomeCont1'],
            ':cpfCont1' => $data['cpfCont1'],
            ':celularCont1' => $data['celularCont1'],
            ':emailCont1' => $data['emailCont1'],
            ':nomeCont2' => $data['nomeCont2'],
            ':cpfCont2' => $data['cpfCont2'],
            ':celularCont2' => $data['celularCont2'],
            ':emailCont2' => $data['emailCont2'],
            ':NU_EVENTO' => $data['NU_EVENTO'],
            ':datainsert' => $data['datainsert'],
            ':matricula' => $data['matricula']
        ));
    }

    public function contagemConvidadosEvento($ufestado)
    {
        $sql = "SELECT 
                    T002.sg_uf,
                    t002.no_estado,
                    COUNT(CASE WHEN T010.cpfCont1 IS NOT NULL AND T010.cpfCont1 <> '' THEN 1 END) +
                    COUNT(CASE WHEN T010.cpfCont2 IS NOT NULL AND T010.cpfCont2 <> '' THEN 1 END) AS total_cadastrados,
                    COUNT(CASE WHEN T010.confirmacaoCont1 IS NOT NULL THEN 1 END) +
                    COUNT(CASE WHEN T010.confirmacaoCont2 IS NOT NULL THEN 1 END) AS total_confirmacao
                FROM 
                    [DB5131_GOV].[recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] T010
                    INNER JOIN [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] T002 ON T010.CO_CNPJ = T002.CO_CNPJ
                WHERE 
                    T002.sg_uf = :estado 
                GROUP BY 
                    T002.sg_uf, t002.no_estado";

        return $this->buscar_lista($sql, array(
            ':estado' => $ufestado
        ));
    }

    public function consultaCPFEvento($cpf,$uf)
    {
        $sql = " SELECT 
                    CASE
                        WHEN T010.cpfCont1 = '" . $cpf . "' THEN T010.nomeCont1
                        WHEN T010.cpfCont2 = '" . $cpf . "' THEN T010.nomeCont2
                    END AS nomeCont,
                    CASE
                        WHEN T010.cpfCont1 = '" . $cpf . "' THEN T010.cpfCont1
                        WHEN T010.cpfCont2 = '" . $cpf . "' THEN T010.cpfCont2
                    END AS cpfCont,
                    CASE
                        WHEN T010.cpfCont1 = '" . $cpf . "' THEN T010.celularCont1
                        WHEN T010.cpfCont2 = '" . $cpf . "' THEN T010.celularCont2
                    END AS celularCont,
                    CASE
                        WHEN T010.cpfCont1 = '" . $cpf . "' THEN T010.emailCont1
                        WHEN T010.cpfCont2 = '" . $cpf . "' THEN T010.emailCont2
                    END AS emailCont,
                    CASE
                        WHEN T010.cpfCont1 = '" . $cpf . "' THEN 1
                        WHEN T010.cpfCont2 = '" . $cpf . "' THEN 2
                    END AS tipocontato,
                    NU_EVENTO, 
                    t010.CO_CNPJ 
                FROM 
                     [DB5131_GOV].[recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] T010
                     INNER JOIN [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] T002 ON T010.CO_CNPJ = T002.CO_CNPJ
                WHERE 
                    T010.cpfCont1 = '" . $cpf . "'
                    OR T010.cpfCont2 = '" . $cpf . "'
                    AND T002.sg_uf = '".$uf."' 
                    AND T002.ic_tipo = 'M'
                ";
        //            return $sql;
        return $this->buscar_lista($sql, array());
    }

    public function confirmarPresencaEvento($data)
    {
        $sql = "UPDATE [DB5131_GOV].[recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO]
                SET 
                    [dt_confirmacao] = '".$data['dt_confirmacao']."'
                    ,[matricula_confirmacao_insert] = ".$data['matricula_confirmacao_insert'];
                if( $data['tipocontato'] == 1){
                    $sql = $sql." ,[confirmacaoCont1] = 1 WHERE [cpfCont1] = '".$data['cpf']."'";

                }else{
                    $sql = $sql." ,[confirmacaoCont2] = 1 WHERE [cpfCont2] = '".$data['cpf']."'";

                }
               
        //return $sql;
        return $this->atualizar($sql, array());
    }

    public function inserirContatosMunicipioNoEvento($data)
    {
        $sql = "INSERT INTO [recepcao].[T010_CONTATOS_MUNICIPIOS_EVENTO] (
                    CO_CNPJ,
                    nomeCont1,
                    cpfCont1,
                    celularCont1,
                    emailCont1,
                    NU_EVENTO,
                    DT_INSERT,
                    NU_MATRICULA_INSERT,
                    confirmacaoCont1,
                    dt_confirmacao,
                    matricula_confirmacao_insert,
                    cargoCont1,
                    orgaoVinculadoCont1
                ) VALUES (
                    :cnpj,
                    :nomeCont1,
                    :cpfCont1,
                    :celularCont1,
                    :emailCont1,
                    :NU_EVENTO,
                    :datainsert,
                    :matricula,
                    1,
                    :dt_confirmacao,
                    :matricula_confirmacao_insert,
                    :cargoCont1,
                    :orgaoVinculadoCont1
                )";

        return $this->inserir($sql, array(
            ':cnpj' => $data['cnpj'],
            ':nomeCont1' => $data['nomeCont1'],
            ':cpfCont1' => $data['cpfCont1'],
            ':celularCont1' => $data['celularCont1'],
            ':emailCont1' => $data['emailCont1'],
            ':NU_EVENTO' => $data['NU_EVENTO'],
            ':datainsert' => $data['datainsert'],
            ':matricula' => $data['matricula'],
            ':dt_confirmacao' => $data['datainsert'],
            ':matricula_confirmacao_insert' => $data['matricula'],
            ':cargoCont1' => $data['cargoCont1'],
            ':orgaoVinculadoCont1' => $data['orgaoVinculadoCont1']
        ));
    }

    public function buscarListaPessoasEventos($uf)
    {
        $sql = "SELECT
                    m.no_cliente AS NOME_MUNICIPIO,
                    c.nomeCont1 AS NOME,
                    c.cpfCont1  AS CPF,
                    c.celularCont1 AS CELULAR,
                    c.emailCont1 AS EMAIL,
                    '' AS ASSINATURA
                FROM
                    [DB5131_GOV].[recepcao].T010_CONTATOS_MUNICIPIOS_EVENTO c
                    INNER JOIN [DB5131_GOV].[dbo].T002_CLIENTE_MINIC_ESTADO m ON c.CO_CNPJ = m.CO_CNPJ
                WHERE
                    c.nomeCont1 IS NOT NULL
                    AND m.sg_uf = '".$uf."' 
                    AND c.cadastro_antecipado = 1

                UNION ALL

                SELECT
                    
                    SUBSTRING ( m.no_cliente, 14, 50 ) AS NOME_MUNICIPIO,
                    c.nomeCont2 AS NOME,
                    c.cpfCont2 AS CPF,
                    c.celularCont2 AS CELULAR,
                    c.emailCont2 AS EMAIL,
                    ''
                FROM
                    [DB5131_GOV].[recepcao].T010_CONTATOS_MUNICIPIOS_EVENTO c
                    INNER JOIN [DB5131_GOV].[dbo].T002_CLIENTE_MINIC_ESTADO m ON c.CO_CNPJ = m.CO_CNPJ
                WHERE
                    c.nomeCont2 IS NOT NULL
                    and c.nomeCont2 <> ''
                    AND m.sg_uf = '".$uf."' 
                    AND c.cadastro_antecipado = 1

                ORDER BY
                    m.no_cliente,
                    [NOME]";

        //return $sql;
        return $this->buscar_lista($sql, array());
    }

    public function listaPresentesNoEvento($uf)
    {
        $sql = "with cte as ( 
                    SELECT
                    case 
                        when confirmacaoCont1 = 1 then 'SIM'
                        else 'Não'
                    end as PRESENTE,

                    case 
                            when m.ic_tipo = 'E' then 'OUTROS'
                            when m.ic_tipo = 'M' then m.no_cliente 
                        end AS NOME_MUNICIPIO,
                        c.nomeCont1 AS NOME,
                        c.cpfCont1  AS CPF,
                        c.celularCont1 AS CELULAR,
                        c.emailCont1 AS EMAIL,
                        case 
                            when  c.cadastro_antecipado = 1 then 'SIM'
                            else 'Não'
                        end as CAD_ANTECIPADO,

                        [cargoCont1] AS CARGO,
                        [orgaoVinculadoCont1] AS ORGAO
                    FROM
                        [DB5131_GOV].[recepcao].T010_CONTATOS_MUNICIPIOS_EVENTO c
                        INNER JOIN [DB5131_GOV].[dbo].T002_CLIENTE_MINIC_ESTADO m ON c.CO_CNPJ = m.CO_CNPJ
                    WHERE
                        c.nomeCont1 IS NOT NULL
                        AND m.sg_uf = '".$uf."' 

                    UNION ALL

                    SELECT
                         case 
                            when confirmacaoCont1 = 1 then 'SIM'
                            else 'Não'
                        end as PRESENTE,
                        SUBSTRING ( m.no_cliente, 14, 50 ) AS NOME_MUNICIPIO,
                        c.nomeCont2 AS NOME,
                        c.cpfCont2 AS CPF,
                        c.celularCont2 AS CELULAR,
                        c.emailCont2 AS EMAIL,
                        case 
                            when  c.cadastro_antecipado = 1 then 'SIM'
                            else 'Não'
                        end as CAD_ANTECIPADO,
                        '' as cargo,
                        '' as orgam
                    FROM
                        [DB5131_GOV].[recepcao].T010_CONTATOS_MUNICIPIOS_EVENTO c
                        INNER JOIN [DB5131_GOV].[dbo].T002_CLIENTE_MINIC_ESTADO m ON c.CO_CNPJ = m.CO_CNPJ
                    WHERE
                        c.nomeCont2 IS NOT NULL
                        and c.nomeCont2 <> ''
                        AND m.sg_uf = '".$uf."' 

                )

                select * from cte order by NOME_MUNICIPIO";

        //return $sql;
        return $this->buscar_lista($sql, array());
    }

}
