<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class usuarioDAO extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }
    
    public function buscaArvoreAcessoPorMatricula($matricula,$data)
    {
        $sql = "SELECT *
        FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
        where nu_matricula = ".$matricula."
        AND [ID_TIPO_ACESSO] = 'M'
        AND DT_INICIO_ACESSO < '".$data."'
        AND DT_FIM_ACESSO > '".$data."'
        ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorUnidade($unidade)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                WHERE NU_UNIDADE = :unidade AND DT_FIM_ACESSO IS NULL AND [ID_TIPO_ACESSO] = 'U'
                GROUP BY 
                     [NU_MATRICULA]
                    ,[NU_UNIDADE]
                    ,[NO_UNIDADE]
                    ,[DT_INICIO_ACESSO]
                    ,[DT_FIM_ACESSO]
                    ,[IDENTIFICACAO_UNIDADE]
                    ,[IDENTIFICACAO_UNIDADE_TIPO]
                    ,[DT_INSERT]
                    ,[ID_TIPO_ACESSO]
                    ,[NIVEL_ACESSO_EDITAR]
                    ,[NIVEL_ACESSO_CONSULTAR]";
        return $this->buscar_lista($sql, array(':unidade' => $unidade));
    }


    
}

