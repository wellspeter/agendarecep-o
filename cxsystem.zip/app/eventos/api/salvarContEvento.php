<?php

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');

$dao = new municipiosEventoDao();

// Função para verificar e decidir qual valor salvar
function verificarCampo($original, $mascarado) {
    // Se o campo original for nulo ou estiver mascarado (contém *), retorna o original (se existir)
    // Caso contrário, retorna o mascarado (supondo que foi alterado pelo usuário)
    return ($original === null || strpos($mascarado, '*') !== false) ? ($original !== null ? $original : null) : $mascarado;
}


// // Recebe os dados do formulário
// $dataAcao = isset($_POST['dataAcaoADD']) ? $_POST['dataAcaoADD'] : null;

// Contato 1
$nomeCont1 = isset($_POST['nomeCont1']) ? $_POST['nomeCont1'] : null;
$cargoCont1 = isset($_POST['cargoCont1']) ? $_POST['cargoCont1'] : null;
$celularCont1 = isset($_POST['celularCont1']) ? $_POST['celularCont1'] : null;
$emailCont1 = isset($_POST['emailCont1']) ? $_POST['emailCont1'] : null;

$nomeCont1_masc = isset($_POST['nomeCont1_masc']) ? $_POST['nomeCont1_masc'] : null;
$cargoCont1_masc = isset($_POST['cargoCont1_masc']) ? $_POST['cargoCont1_masc'] : null;
$celularCont1_masc = isset($_POST['celularCont1_masc']) ? $_POST['celularCont1_masc'] : null;
$emailCont1_masc = isset($_POST['emailCont1_masc']) ? $_POST['emailCont1_masc'] : null;

// Contato 2
$nomeCont2 = isset($_POST['nomeCont2']) ? $_POST['nomeCont2'] : null;
$cargoCont2 = isset($_POST['cargoCont2']) ? $_POST['cargoCont2'] : null;
$celularCont2 = isset($_POST['celularCont2']) ? $_POST['celularCont2'] : null;
$emailCont2 = isset($_POST['emailCont2']) ? $_POST['emailCont2'] : null;

$nomeCont2_masc = isset($_POST['nomeCont2_masc']) ? $_POST['nomeCont2_masc'] : null;
$cargoCont2_masc = isset($_POST['cargoCont2_masc']) ? $_POST['cargoCont2_masc'] : null;
$celularCont2_masc = isset($_POST['celularCont2_masc']) ? $_POST['celularCont2_masc'] : null;
$emailCont2_masc = isset($_POST['emailCont2_masc']) ? $_POST['emailCont2_masc'] : null;

// Matrícula, CNPJ e data
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
$cadastro_principal = isset($_POST['cadastro_principal']) ? $_POST['cadastro_principal'] : null;

// Formatar a data
$date = str_replace('/', '-', $dataAcao);
$dataAcaoInformada = date('Y-m-d', strtotime($date));
$datainsert = new DateTime();

// // Criação do array com os dados
$data = [
    'nomeCont1' => verificarCampo(null, $nomeCont1),
    'cpfCont1' => verificarCampo(null, $cpfCont1),
    'celularCont1' => verificarCampo(null, $celularCont1),
    'emailCont1' => verificarCampo(null, $emailCont1),

    'nomeCont2' => verificarCampo(null, $nomeCont2),
    'cpfCont2' => verificarCampo(null, $cpfCont2),
    'celularCont2' => verificarCampo(null, $celularCont2),
    'emailCont2' => verificarCampo(null, $emailCont2),

    'matricula' => $matricula,
    'datainsert' => $datainsert->format('Y-m-d H:i:s'),
    'cnpj' => $cnpj,
    'cadastro_principal' => $cadastro_principal
];

//echo json_encode($data);

// // Verificar se o CNPJ já existe
$existe = $dao->verificarExistenciaCNPJ($cnpj);

if (count($existe)>0) {
    // Atualizar os contatos existentes
    $result = $dao->atualizarContatosMunicipio($data);
} else {
    // Inserir novos contatos
    $result = $dao->inserirContatosMunicipio($data);
}

// Retorno de sucesso ou erro
if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']);
}








