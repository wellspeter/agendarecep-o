<?php

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');

$uf = CxRequest::params('uf');

$dao = new municipiosEventoDao();

// Verificar se o CNPJ já existe
$existe = $dao->contagemConvidadosEvento($uf);

echo json_encode($existe);
