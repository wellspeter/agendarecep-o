<?php

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');

$cnpj = CxRequest::params('cnpj');

$dao = new municipiosEventoDao();

// Verificar se o CNPJ já existe
$existe = $dao->verificarExistenciaCNPJ($cnpj);

echo json_encode($existe);
