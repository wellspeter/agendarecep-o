<?php

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');

$cpf = CxRequest::params('cpf');
$uf = CxRequest::params('uf');

$dao = new municipiosEventoDao();

// Verificar se o CNPJ já existe
$existe = $dao->consultaCPFEvento($cpf,$uf);

echo json_encode($existe);
