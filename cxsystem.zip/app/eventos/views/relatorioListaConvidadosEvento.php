<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];

$estado = CxRequest::params('estado');
$estadoDescrito = '';
switch ($estado) {
  case 'TO':
    $estadoDescrito = "Tocantins";
    break;
  case 'AP':
    $estadoDescrito = "Amapá";
    break;
  case 'BA':
    $estadoDescrito = "Bahia";
    break;
  case 'CE':
    $estadoDescrito = "Ceará";
    break;
  case 'SE':
    $estadoDescrito = "Sergipe";
    break;
  case 'MA':
    $estadoDescrito = "Maranhão";
    break;
  case 'MT':
    $estadoDescrito = "Mato Grosso";
    break;
  case 'RJ':
    $estadoDescrito = "Rio de Janeiro";
    break;
}

// if($matricula == '145234'){
//   $lotacao_fisica =  6753;
// }

//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');
require_once(__DIR__ . '/../controllers/exportarEventosController.php');
$dao = new municipiosEventoDao();

//$teste = dadosBuscaListaVisitante($estado);
//echo var_dump($teste);

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);

if (count($acessoUsuarioPorMatricula) > 0) {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
} else {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}

//echo var_dump($acessoUsuarioPorMatricula);
//echo var_dump($dadosArvoreAcesso);
if (count($dadosArvoreAcesso) > 0) {
  $listaMunc = dadosBuscaListaVisitante($estado);
  //echo var_dump($listaMunc);
  if (count($listaMunc) > 0) {

?>

    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title ">Lista de Convidados do <?php echo $estadoDescrito ?></h4>
            </div>

            <div class="card-body ">
              <div class="table-responsive">
                <table id="table-municipios" class="table table-striped dataex-html5-selectors mb-0">
                  <thead>
                    <tr>
                      <th>Município</th>
                      <th>nome</th>
                      <th>cpf </th>
                      <!-- <th>celular </th> -->
                      <th>assinatura</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($listaMunc as $resultado) {
                      echo "<tr>";
                      echo "<td class='text-bold-600 pr-0'>" . $resultado['NOME_MUNICIPIO'] . "</td>";
                      echo "<td class='text-bold-600 pr-0'>" . $resultado['NOME'] . "</td>";
                      echo "<td>" . $resultado['CPF'] . "</td>"; 
                      // echo "<td>" . $resultado['CELULAR'] . "</td>";
                      echo "<td>" . $resultado['ASSINATURA'] . "</td>";
                      echo "</tr>";
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script>

      $(document).ready(function() {

        /********************************************
         *        js of Order by the grouping        *
         ********************************************/

        var groupingTable = $('.row-grouping').DataTable({
          "columnDefs": [{
            "visible": false,
            "targets": 2
          }],
          "order": [
            [2, 'asc']
          ],
          "displayLength": 10,
          "drawCallback": function(settings) {
            var api = this.api();
            var rows = api.rows({
              page: 'current'
            }).nodes();
            var last = null;

            api.column(2, {
              page: 'current'
            }).data().each(function(group, i) {
              if (last !== group) {
                $(rows).eq(i).before(
                  '<tr class="group"><td colspan="5">' + group + '</td></tr>'
                );

                last = group;
              }
            });
          }
        });

        $('.row-grouping tbody').on('click', 'tr.group', function() {
          var currentOrder = groupingTable.order()[0];
          if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
            groupingTable.order([2, 'desc']).draw();
          } else {
            groupingTable.order([2, 'asc']).draw();
          }
        });




        /*****************************
         *       js of Add Row        *
         ******************************/

        var t = $('.add-rows').DataTable();
        var counter = 2;

        $('#addRow').on('click', function() {
          t.row.add([
            counter + '.1',
            counter + '.2',
            counter + '.3',
            counter + '.4',
            counter + '.5'
          ]).draw(false);

          counter++;
        });


        /**************************************************************
         * js of Tab for COLUMN SELECTORS WITH EXPORT AND PRINT OPTIONS *
         ***************************************************************/

        $('.dataex-html5-selectors').DataTable({
          dom: 'Bfrtip',
          buttons: [
            {
              extend: 'copyHtml5',
              exportOptions: {
                columns: [0, ':visible']
              }
            },
            {
              extend: 'excel', 
              exportOptions: {
                columns: ':visible'
              }
            },
            {
              extend: 'pdfHtml5',
              exportOptions: {
                columns: ':visible'
              }
            },
            {
              extend: 'print',
              exportOptions: {
                columns: ':visible'
              }
            }
          ]
        });
      });

    </script>

<?
  }
} else {

  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo Contém dados para Exibição!</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}


?>