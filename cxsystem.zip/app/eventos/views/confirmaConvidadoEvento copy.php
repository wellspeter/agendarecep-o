<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];

$estado = CxRequest::params('estado');
$estadoDescrito = '';
switch ($estado) {
  case 'TO':
    $estadoDescrito = "Tocantins";
    break;
  case 'AP':
    $estadoDescrito = "Amapá";
    break;
  case 'BA':
    $estadoDescrito = "Bahia";
    break;
  case 'CE':
    $estadoDescrito = "Ceará";
    break;
  case 'SE':
    $estadoDescrito = "Sergipe";
    break;
  case 'MA':
    $estadoDescrito = "Maranhão";
    break;
  case 'MT':
    $estadoDescrito = "Mato Grosso";
    break;
  case 'RJ':
    $estadoDescrito = "Rio de Janeiro";
    break;
}


// if($matricula == '145234'){
//   $lotacao_fisica =  6753;
// }

//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');
$dao = new municipiosEventoDao();

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);

if (count($acessoUsuarioPorMatricula) > 0) {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
} else {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}

//echo var_dump($acessoUsuarioPorMatricula);
//echo var_dump($dadosArvoreAcesso);
if (count($dadosArvoreAcesso) > 0) {
  $qtdConvidados = $dao->contagemConvidadosEvento($estado);
  //echo var_dump($qtdConvidados);
?>
  <style>
    .faq-search button {
      /* search button position */
      right: 8px;
      top: 6px;
    }

    .faq .wrapper-content {
      display: none;
    }

    .faq .wrapper-content.active {
      display: block;
    }

    @media only screen and (max-width: 576px) {
      .faq-title {
        font-size: 1.73rem;
      }

      .faq-subtitle {
        font-size: 1.3rem;
      }
    }

    @media only screen and (max-width: 768px) {
      .faq-search .faq-search-width {
        /* search box responsive */
        width: 100% !important;
      }
    }

    @media only screen and (min-width: 1024px) {
      .faq-bg {
        padding: 5rem 0 !important;
      }
    }
  </style>

  <div class="container-fluid">
    <div class="row align-items-center  mb-2">

      <div class="col-10">
        <h4 class=""><? echo $estadoDescrito ?></h4>
      </div>
      <div class="col-2">
        <div class="my-auto  text-right">
          <div class="statistics">
            <span class="font-medium-2 text-bold-600" id="divConfirmados">Presença no Evento: <? if (count($qtdConvidados) > 0) {
                                                                                          echo $qtdConvidados[0]['total_confirmacao'];
                                                                                        } else {
                                                                                          echo '0';
                                                                                        } ?></span>
          </div>
          <div class="statistics-date">
            <small class="text-muted " id="divCadastrados">(Cadastrados: <? if (count($qtdConvidados) > 0) {
                                                                            echo $qtdConvidados[0]['total_cadastrados'];
                                                                          } else {
                                                                            echo '0';
                                                                          } ?>)</small>
          </div>
        </div>
      </div>
    </div>
    <section class="faq-search">
      <div class="row">
        <div class="col-12">
          <div class="card faq-bg bg-transparent box-shadow-0 p-1 p-md-5">
            <div class="card-body p-0">
              <h1 class="faq-title text-center mb-3">Confirmação de Convidados!</h1>
              <form>
                <fieldset class="faq-search-width form-group position-relative w-50 mx-auto">
                  <input type="text" class="form-control round form-control-lg shadow pl-2 text-center" id="searchbar">
                  <button class="btn btn-primary round position-absolute d-none d-sm-block" type="button" id="btnBuscaCPF" onclick="popularParametrosModal();">Busca por CPF</button>
                  <button class="btn btn-primary round position-absolute d-block d-sm-none" type="button"><i class="bx bx-search"></i></button>
                </fieldset>
              </form>
              <!-- <p class="card-text text-center mt-3 font-medium-1 text-muted" id="divAlerta">
                Informe um CPF</p> -->
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>


  <!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->
  <div class="modal fade" id="adicionarContadosModal" tabindex="-1" role="dialog" aria-labelledby="adicionarContadosModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="form-cadastro-contato-evento" method="post" action="javascript:void(0)">

          <input type="hidden" id="cnpj" name="cnpj">
          <input type="hidden" id="matricula" name="matricula" value="<? echo $matricula ?>">
          <input type="hidden" id="estado" name="estado" value="<? echo $estado ?>">
          <input type="hidden" id="idEvento" name="idEvento" value="1">
          <input type="hidden" id="tipocontato" name="tipocontato" >

          <div class="modal-header border-bottom">
            <h5 class="modal-title" id="tituloAcaoADD">Confirmação de Presença no Evento</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="bx bx-x"></i>
            </button>
          </div>

          <div class="modal-body" style="padding:0px; margin-top:10px">
            <!-- Spinner de Carregamento -->
            <div id="loadingSpinner" class="text-center my-3">
              <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Carregando...</span>
              </div>
            </div>

            <!-- Conteúdo do Formulário (Inicialmente Oculto) -->
            <div id="formContent" style="display: none;">
              <!-- Seu conteúdo de formulário existente -->
              <div class="col">
                <div class="row">
                  <!-- Contato 1 -->
                  <div class="col-9">
                    <div class="form-group">
                      <label>Nome</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="nomeCont1_masc" readonly="readonly" name="nomeCont1_masc">
                        <input type="hidden" id="nomeCont1" name="nomeCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-user'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>

                  <div class="col-3">
                    <div class="form-group">
                      <label>CPF</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="cpfCont1_masc" readonly="readonly" name="cpfCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        <input type="hidden" id="cpfCont1" name="cpfCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-building-house'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                </div>
                <div class="row">


                  <div class="col-9">
                    <div class="form-group">
                      <label>Email</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="emailCont1_masc" readonly="readonly" name="emailCont1_masc">
                        <input type="hidden" id="emailCont1" name="emailCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-envelope'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>

                  <div class="col-3">
                    <div class="form-group">
                      <label>Celular</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="celularCont1_masc" readonly="readonly" name="celularCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        <input type="hidden" id="celularCont1" name="celularCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-phone'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                </div>
                <hr>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
              <i class="bx bx-x d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Cancelar</span>
            </button>
            <button type="button" class="btn btn-primary ml-1" id="submiContatoADD" value="submiContatoADD">
              <i class="bx bx-check d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Confirmar Presença</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>



  <script>
    <? echo "const uf = '".$estado."';" ?>
     
    function popularParametrosModal() {

      var cpf = $('#searchbar').val();

      if (cpf == '') {
        toastr['error']('CPF não informado', 'Informe o CPF para que seja realizada a busca', {
          positionClass: 'toast-bottom-full-width',
          rtl: true
        });
        return;
      }

      if (!testaCPF(cpf)) {
        toastr['error']('Informe o CPF correto para que seja realizada a busca', 'CPF informado incorreto', {
          positionClass: 'toast-bottom-full-width',
          rtl: true
        });
        return;
      }

      // limpar todos 
      limparcampo();

      // Exibir o modal
      $('#adicionarContadosModal').modal('show');

      // Exibir o spinner e ocultar o conteúdo do formulário
      $('#loadingSpinner').show();
      $('#formContent').hide();

      var link = '<? echo CxUrl::site('eventos:api:consultarDadosContatoCPF') ?>'.slice(0, -10) + cpf  ;
      link = link + '/' + uf;
      // Fazer a chamada à API usando $.ajax
      $.ajax({
        url: link,
        method: 'GET',
        dataType: 'json',
        headers: {
          'Content-Type': 'application/json',
          // Adicione outros headers se necessário, como autenticação
        },
        success: function(data) {
          if (data.length > 0) {
            // Dados puros dados
            const nomeCont1 = data[0].nomeCont ? data[0].nomeCont : '';
            const cpfCont1 = data[0].cpfCont ? data[0].cpfCont : '';
            const celularCont1 = data[0].celularCont ? data[0].celularCont : '';
            const emailCont1 = data[0].emailCont ? data[0].emailCont : '';

            const idEvento = data[0].NU_EVENTO ? data[0].NU_EVENTO : '';
            const tipocontato = data[0].tipocontato ? data[0].tipocontato : '';

            // Preencher os campos do modal

            $('#idEvento').val(idEvento);
            $('#tipocontato').val(tipocontato);

            $('#nomeCont1_masc').val(nomeCont1);
            $('#cpfCont1_masc').val(cpfCont1);
            $('#celularCont1_masc').val(celularCont1);
            $('#emailCont1_masc').val(emailCont1);

            // Armazenar os dados originais para comparação futura (opcional)
            $('#form-cadastro-contato').data('originalData', data);
          }

          // Ocultar o spinner e exibir o conteúdo do formulário
          $('#loadingSpinner').hide();
          $('#formContent').show();
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.error('Erro ao popular o modal:', textStatus, errorThrown);
          alert('Ocorreu um erro ao carregar os dados. Por favor, tente novamente.');

          // Ocultar o spinner e exibir o conteúdo do formulário, mesmo em caso de erro
          $('#loadingSpinner').hide();
          $('#formContent').show();
        }
      });
    }

    function limparcampo() {
      $('#idEvento').val('');
      $('#tipocontato').val('');

      $('#nomeCont1_masc').val('');
      $('#cpfCont1_masc').val('');
      $('#celularCont1_masc').val('');
      $('#emailCont1_masc').val('');
    }

    function testaCPF(strCPF) {
      var Soma;
      var Resto;
      Soma = 0;
      if (strCPF == "00000000000") return false;

      for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
      Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11)) Resto = 0;
      if (Resto != parseInt(strCPF.substring(9, 10))) return false;

      Soma = 0;
      for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
      Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11)) Resto = 0;
      if (Resto != parseInt(strCPF.substring(10, 11))) return false;
      return true;
    }

    $(document).ready(function() {

      //Salvar os dados
      $('#submiContatoADD').on('click', function() {
        // Exibir um spinner de salvamento ou desabilitar o botão (opcional)
        $('#submiContatoADD').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Salvando...');

        $.ajax({
          type: 'POST',
          url: '<? echo CxUrl::site('rep_eleitos:api:confirmarContEvento') ?>',
          data: $('#form-cadastro-contato-evento').serialize(),
          success: function(response) {
            Swal.fire({
              icon: "success",
              title: 'Sucesso!',
              text: 'Confirmado a Presença no evento.',
              confirmButtonClass: 'btn btn-success',
            }).then(function(result) {
              if (result.value) {
                // Limpar Campo da busca
                $('#searchbar').val('');
                // Fechar o modal
                $('#adicionarContadosModal').modal('hide');
                // Reabilitar o botão "Salvar"
                $('#submiContatoADD').prop('disabled', false).html('<i class="bx bx-check d-block d-sm-none"></i><span class="d-none d-sm-block">Salvar</span>');
                var nomebtn = '#btnpessoas' + $('#cnpj').val();
                $(nomebtn).html('<i class="bx bxs-edit"></i>');
              }
            })
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error('Erro ao salvar os dados:', textStatus, errorThrown);
            Swal.fire({
              title: 'Error',
              text: 'Tente novamente, pois não conseguimos salvar.',
              icon: 'error',
              confirmButtonClass: 'btn btn-success',
            })
            // Reabilitar o botão "Salvar"
            $('#submiContatoADD').prop('disabled', false).html('<i class="bx bx-check d-block d-sm-none"></i><span class="d-none d-sm-block">Salvar</span>');
          }
        });
      });





    });
  </script>

<?

} else {

  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo tem acesso a essa funcionalidade</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}


?>