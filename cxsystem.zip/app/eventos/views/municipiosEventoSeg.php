<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];

$estado = CxRequest::params('seg');
$estadoDescrito = '';
switch ($estado) {
  case 'TO':
    $estadoDescrito = "Tocantins";
    break;
  case 'AP':
    $estadoDescrito = "Amapá";
    break;
  case 'BA':
    $estadoDescrito = "Bahia";
    break;
  case 'CE':
    $estadoDescrito = "Ceará";
    break;
  case 'SE':
    $estadoDescrito = "Sergipe";
    break;
  case 'MA':
    $estadoDescrito = "Maranhão";
    break;
  case 'MT':
    $estadoDescrito = "Mato Grosso";
    break;
  case 'RJ':
    $estadoDescrito = "Rio de Janeiro";
    break;
}

// if($matricula == '145234'){
//   $lotacao_fisica =  6753;
// }

//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');
require_once(__DIR__ . '/../controllers/exportarEventosController.php');
$dao = new municipiosEventoDao();

//$teste = dadosBuscaListaVisitante($estado);
//echo var_dump($teste);

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);

if (count($acessoUsuarioPorMatricula) > 0) {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
} else {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}

//echo var_dump($acessoUsuarioPorMatricula);
//echo var_dump($dadosArvoreAcesso);
if (count($dadosArvoreAcesso) > 0) {
  $listaMunc = $dao->buscaMunicipiosEventoEstado($estado);
  //echo var_dump($listaMunc);
  if (count($listaMunc) > 0) {

?>

    <div class="container-fluid">
      <div class="row align-items-center  mb-2">
        <div class="col-12">
          <h4 class="">Incluir convidados para o Evento Regional</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title "><?php echo $estado ?></h4>
            </div>

            <div class="card-body ">
              <div class="table-responsive">
                <table id="table-municipios" class="table zero-configuration mb-0">
                  <thead>
                    <tr>
                      <th>Prior.</th>
                      <th>Cliente</th>
                      <th>Segmento </th>
                      <th>SEG</th>
                      <th class="text-center">Cadastrar</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($listaMunc as $resultado) {
                      echo "<tr>";
                      if ($resultado['MUNICIPIO_PRIORITARIO'] == 0) {
                        echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle danger font-small-1 ml-1 '></i></td>";
                      } else {
                        echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle success font-small-1 ml-1' style='margin-top: 5px;'></i></td>";
                      }
                      echo "<td class='text-bold-600 pr-0'>" . $resultado['NOME_MUNICIPIO'] . "</td>";
                      echo "<td>" . $resultado['NOME_SEGMENTO'] . "</td>"; // verificar

                      echo "<td>" . $resultado['NOME_SEG'] . "</td>";

                      //  echo '<td  class="text -center"><button type="button" class="btn btn-icon rounded-circle btn-primary" data-toggle="modal" data-target="#adicionarContadosModal" ><i class="bx bxs-user-plus"></i></button></td>';
                      echo "<td  class='text-center'><button type='button' id='btnpessoas" . $resultado['CNPJ'] . "' class='btn btn-icon rounded-circle btn-primary'  onclick='popularParametrosModal(\"" . $resultado['CNPJ'] . "\");'>";
                      if ($resultado['cadastro_principal'] == 0) {
                        echo "<i class='bx bxs-user-plus'></i>";
                      } else {
                        echo "<i class='bx bxs-edit'></i>";
                      }

                      echo "</button></td>";
                      echo "</tr>";
                    } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->
    <div class="modal fade" id="adicionarContadosModal" tabindex="-1" role="dialog" aria-labelledby="adicionarContadosModal" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form id="form-cadastro-contato-evento" method="post" action="javascript:void(0)">
            <input type="hidden" id="cnpj" name="cnpj">
            <input type="hidden" id="matricula" name="matricula" value="<? echo $matricula ?>">
            <input type="hidden" id="idEvento" name="idEvento" value="1">
            <input type="hidden" id="cadastro_principal" name="cadastro_principal" value="1">
            <input type="hidden" id="estado" name="estado" value="<? echo $estado ?>">
            <input type="hidden" id="actionType" name="actionType" value="">

            <div class="modal-header border-bottom">
              <h5 class="modal-title" id="tituloAcaoADD">Adicionar Contatos do Município</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="bx bx-x"></i>
              </button>
            </div>

            <div class="modal-body" style="padding:0px; margin-top:10px">
              <!-- Spinner de Carregamento -->
              <div id="loadingSpinner" class="text-center my-3">
                <div class="spinner-border text-primary" role="status">
                  <span class="sr-only">Carregando...</span>
                </div>
              </div>

              <!-- Conteúdo do Formulário (Inicialmente Oculto) -->
              <div id="formContent" style="display: none;">
                <!-- Seu conteúdo de formulário existente -->
                <div class="col">
                  <div class="row">
                    <!-- Contato 1 -->
                    <div class="col-3">
                      <div class="form-group">
                        <label>Nome do Prefeito(a)</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="nomeCont1_masc" name="nomeCont1_masc" placeholder="Prefeito(a)">
                          <input type="hidden" id="nomeCont1" name="nomeCont1">
                          <div class="form-control-position">
                            <i class='bx bxs-user'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>CPF</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="cpfCont1_masc" name="cpfCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                          <input type="hidden" id="cpfCont1" name="cpfCont1">
                          <div class="form-control-position">
                            <i class='bx bxs-building-house'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>Celular</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="celularCont1_masc" name="celularCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                          <input type="hidden" id="celularCont1" name="celularCont1">
                          <div class="form-control-position">
                            <i class='bx bxs-phone'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>Email</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="emailCont1_masc" name="emailCont1_masc">
                          <input type="hidden" id="emailCont1" name="emailCont1">
                          <div class="form-control-position">
                            <i class='bx bxs-phone'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>
                  </div>
                  <hr>
                </div>

                <div class="col">
                  <div class="row">
                    <!-- Contato 2 -->
                    <div class="col-3">
                      <div class="form-group">
                        <label>Nome do Acompanhante</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="nomeCont2_masc" name="nomeCont2_masc" placeholder="Acompanhante">
                          <input type="hidden" id="nomeCont2" name="nomeCont2">
                          <div class="form-control-position">
                            <i class='bx bxs-user'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>CPF</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="cpfCont2_masc" name="cpfCont2_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                          <input type="hidden" id="cpfCont2" name="cpfCont2">
                          <div class="form-control-position">
                            <i class='bx bxs-building-house'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>Celular</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="celularCont2_masc" name="celularCont2_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="">
                          <input type="hidden" id="celularCont2" name="celularCont2">
                          <div class="form-control-position">
                            <i class='bx bxs-phone'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-3">
                      <div class="form-group">
                        <label>Email</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="emailCont2_masc" name="emailCont2_masc">
                          <input type="hidden" id="emailCont2" name="emailCont2">
                          <div class="form-control-position">
                            <i class='bx bxs-phone'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>


                  </div>
                </div>
              </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
                <i class="bx bx-x d-block d-sm-none"></i>
                <span class="d-none d-sm-block">Cancelar</span>
              </button>
              <button type="button" class="btn btn-primary ml-1" id="submiContatoADD" value="submiContatoADD">
                <i class="bx bx-check d-block d-sm-none"></i>
                <span class="d-none d-sm-block">Salvar</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>



    <script>
      <? echo "const uf = '" . $estado . "';" ?>

      function popularParametrosModal(cnpj) {

        // limpar todos 
        limparcampo();

        $('.is-invalid').removeClass('is-invalid');
        // Exibir o modal
        $('#adicionarContadosModal').modal('show');

        // Exibir o spinner e ocultar o conteúdo do formulário
        $('#loadingSpinner').show();
        $('#formContent').hide();

        var link = '<? echo CxUrl::site('eventos:api:consultarDadosContato') ?>'.slice(0, -6) + cnpj;

        $('#cnpj').val(cnpj);

        // Fazer a chamada à API usando $.ajax
        $.ajax({
          url: link,
          method: 'GET',
          dataType: 'json',
          headers: {
            'Content-Type': 'application/json',
            // Adicione outros headers se necessário, como autenticação
          },
          success: function(data) {
            if (data.length > 0) {
              $('#actionType').val('edit'); // Definir o tipo de ação como 'edit'

              // Aplicar as funções de ocultação nos dados
              const nomeCont1Ocultado = data[0].nomeCont1 ? data[0].nomeCont1 : '';
              const cpfCont1Ocultado = data[0].cpfCont1 ? (data[0].cpfCont1) : '';
              const celularCont1Ocultado = data[0].celularCont1 ? (data[0].celularCont1) : '';
              const emailCont1Ocultado = data[0].emailCont1 ? (data[0].emailCont1) : '';

              const nomeCont2Ocultado = data[0].nomeCont2 ? (data[0].nomeCont2) : '';
              const cpfCont2Ocultado = data[0].cpfCont2 ? (data[0].cpfCont2) : '';
              const celularCont2Ocultado = data[0].celularCont2 ? (data[0].celularCont2) : '';
              const emailCont2Ocultado = data[0].emailCont2 ? (data[0].emailCont2) : '';

              // Dados puros dados
              const nomeCont1 = data[0].nomeCont1 ? data[0].nomeCont1 : '';
              const cpfCont1 = data[0].cpfCont1 ? data[0].cpfCont1 : '';
              const celularCont1 = data[0].celularCont1 ? data[0].celularCont1 : '';
              const emailCont1 = data[0].emailCont1 ? data[0].emailCont1 : '';

              const nomeCont2 = data[0].nomeCont2 ? data[0].nomeCont2 : '';
              const cpfCont2 = data[0].cpfCont2 ? data[0].cpfCont2 : '';
              const celularCont2 = data[0].celularCont2 ? data[0].celularCont2 : '';
              const emailCont2 = data[0].emailCont2 ? data[0].emailCont2 : '';

              const idEvento = data[0].NU_EVENTO ? data[0].NU_EVENTO : '';

              // Preencher os campos do modal

              $('#idEvento').val(idEvento);

              $('#nomeCont1_masc').val(nomeCont1Ocultado);
              $('#cpfCont1_masc').val(cpfCont1Ocultado);
              $('#celularCont1_masc').val(celularCont1Ocultado);
              $('#emailCont1_masc').val(emailCont1Ocultado);

              $('#nomeCont1').val(nomeCont1);
              $('#cpfCont1').val(cpfCont1);
              $('#celularCont1').val(celularCont1);
              $('#emailCont1').val(emailCont1);

              $('#nomeCont2_masc').val(nomeCont2Ocultado);
              $('#cpfCont2_masc').val(cpfCont2Ocultado);
              $('#celularCont2_masc').val(celularCont2Ocultado);
              $('#emailCont2_masc').val(emailCont2Ocultado);

              $('#nomeCont2').val(nomeCont2);
              $('#cpfCont2').val(cpfCont2);
              $('#celularCont2').val(celularCont2);
              $('#emailCont2').val(emailCont2);

              // Armazenar os dados originais para comparação futura (opcional)
              $('#form-cadastro-contato').data('originalData', data);
            }else{
              $('#actionType').val('register'); // Definir o tipo de ação como 'register'
            }

            // Ocultar o spinner e exibir o conteúdo do formulário
            $('#loadingSpinner').hide();
            $('#formContent').show();
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error('Erro ao popular o modal:', textStatus, errorThrown);
            alert('Ocorreu um erro ao carregar os dados. Por favor, tente novamente.');

            // Ocultar o spinner e exibir o conteúdo do formulário, mesmo em caso de erro
            $('#loadingSpinner').hide();
            $('#formContent').show();
          }
        });
      }

      function limparcampo() {
        $('.is-invalid').removeClass('is-invalid');
        $('#idEvento').val('');
        $('#cnpj').val('');

        $('#nomeCont1_masc').val('');
        $('#cpfCont1_masc').val('');
        $('#celularCont1_masc').val('');
        $('#emailCont1_masc').val('');

        $('#nomeCont1').val('');
        $('#cpfCont1').val('');
        $('#celularCont1').val('');
        $('#emailCont1').val('');

        $('#nomeCont2_masc').val('');
        $('#cpfCont2_masc').val('');
        $('#celularCont2_masc').val('');
        $('#emailCont2_masc').val('');

        $('#nomeCont2').val('');
        $('#cpfCont2').val('');
        $('#celularCont2').val('');
        $('#emailCont2').val('');
      }

      function testaCPF(strCPF) {
        var Soma;
        var Resto;
        Soma = 0;
        if (strCPF == "00000000000") return false;

        for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(9, 10))) return false;

        Soma = 0;
        for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
        Resto = (Soma * 10) % 11;

        if ((Resto == 10) || (Resto == 11)) Resto = 0;
        if (Resto != parseInt(strCPF.substring(10, 11))) return false;
        return true;
      }

      //Verrificando se tem cadastro desse CPF no Evento
      function verificarCPFCadastrado(strCPF) {
        return new Promise((resolve, reject) => {
          if (strCPF === '') {
            resolve(false);
            return;
          }

          var link = '<?php echo CxUrl::site('eventos:api:consultarDadosContatoCPF') ?>'.slice(0, -10) + strCPF + '/' + uf;

          $.ajax({
            url: link,
            method: 'GET',
            dataType: 'json',
            success: function(data) {
              if (data.length > 0) {
                resolve(true);
              } else {
                resolve(false);
              }
            },
            error: function(jqXHR, textStatus, errorThrown) {
              console.error('Erro ao verificar CPF:', textStatus, errorThrown);
              Swal.fire({
                title: 'Erro',
                text: 'Não foi possível verificar se o CPF está cadastrado. Tente novamente.',
                icon: 'error',
                confirmButtonClass: 'btn btn-success',
              });
              resolve(false);
            }
          });
        });
      }


      $(document).ready(function() {
        //Salvar os dados
        $('#submiContatoADD').on('click', async function() {
          let isValid = true;
          let lisCPFCadastrados = '';
          // Limpar mensagens de erro anteriores
          $('.is-invalid').removeClass('is-invalid');


          var nome1 = $('#nomeCont1_masc').val().trim();
          var cpf1 = $('#cpfCont1_masc').val().trim();
          var cel1 = $('#celularCont1_masc').val().trim();
          var email1 = $('#emailCont1_masc').val().trim();

          var nome2 = $('#nomeCont2_masc').val().trim();
          var cpf2 = $('#cpfCont2_masc').val().trim();
          var cel2 = $('#celularCont2_masc').val().trim();
          var email2 = $('#emailCont2_masc').val().trim();

          /**************************Validando o primeir contato */
          // Validar Nome (sempre obrigatório)
          if (nome1 === '') {
            $('#nomeCont1_masc').addClass('is-invalid');
            isValid = false;
          }

          // Validar CPF (sempre obrigatório)
          if (cpf1 === '') {
            $('#cpfCont1_masc').addClass('is-invalid');
            isValid = false;
          }

          //testando o CPF
          if (!testaCPF(cpf1)) {
            toastr['error']('Informe o CPF correto do Prefeito(a) para que seja salvo', 'CPF informado incorreto', {
              positionClass: 'toast-bottom-full-width',
              rtl: true
            });
            $('#cpfCont1_masc').addClass('is-invalid');
            isValid = false;
          }

          // Validar Telefone (se preenchido)
          if (cel1 !== '') {
            const telefoneRegex = /^\d{11}$/;
            if (!telefoneRegex.test(cel1)) {
              $('#celularCont1_masc').addClass('is-invalid');
              isValid = false;
            }
          }

          // Validar Email (se preenchido)
          if (email1 !== '') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email1)) {
              $('#emailCont1_masc').addClass('is-invalid');
              isValid = false;
            }
          }

          /**************************Validando o Segundo contato */
          if (nome2 !== '') {
            // Validar CPF caso tenha o preenchimento do segundo nome
            if (cpf2 === '') {
              $('#cpfCont2_masc').addClass('is-invalid');
              isValid = false;
            }

            //testando o CPF
            if (!testaCPF(cpf2)) {
              toastr['error']('Informe o CPF correto do Acompanhante para que seja salvo', 'CPF informado incorreto', {
                positionClass: 'toast-bottom-full-width',
                rtl: true
              });
              $('#cpfCont2_masc').addClass('is-invalid');
              isValid = false;
            }
          }

          // Validar Telefone (se preenchido)
          if (cel2 !== '') {
            if (nome2 === '') {
              $('#nomeCont2_masc').addClass('is-invalid');
              isValid = false;
            }

            const telefoneRegex = /^\d{11}$/;
            if (!telefoneRegex.test(cel2)) {
              $('#celularCont2_masc').addClass('is-invalid');
              isValid = false;
            }
          }

          // Validar Email (se preenchido)
          if (email2 !== '') {
            if (nome2 === '') {
              $('#nomeCont2_masc').addClass('is-invalid');
              isValid = false;
            }
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email2)) {
              $('#emailCont2_masc').addClass('is-invalid');
              isValid = false;
            }
          }

          if (nome2 !== '' && nome2 === '') {
            // Validar CPF caso tenha o preenchimento do segundo nome
            toastr['error']('Não é possivel adicionar Acompanhante sem Prefeito!', 'Acompanhante sem Prefeito!', {
              positionClass: 'toast-bottom-full-width',
              rtl: true
            });
            $('#cpfCont2_masc').addClass('is-invalid');
            isValid = false;
          }

          if (!isValid) {
            toastr['error']('Por favor, corrija os campos destacados.', 'Erro de validação', {
              positionClass: 'toast-bottom-full-width',
              rtl: true
            });
            $('#submiContatoADD').prop('disabled', false).html('<i class="bx bx-check d-block d-sm-none"></i><span class="d-none d-sm-block">Salvar</span>');

            return;
          }

          // Espera para fazer as verificações se tem os CPFs cadastrados
          $('#loadingSpinner').show();
          let isValidCPF = true;

          try {
            if ($('#actionType').val() == 'register') {
              // Verificar ambos os CPFs simultaneamente
              const [cpf1Exists, cpf2Exists] = await Promise.all([
                verificarCPFCadastrado(cpf1),
                verificarCPFCadastrado(cpf2)
              ]);

              if (cpf1Exists) {
                lisCPFCadastrados += cpf1;
                $('#cpfCont1_masc').addClass('is-invalid');
                isValidCPF = false;
              }

              if (cpf2Exists) {
                if (lisCPFCadastrados !== '') {
                  lisCPFCadastrados += ', ' + cpf2;
                } else {
                  lisCPFCadastrados = cpf2;
                }
                $('#cpfCont2_masc').addClass('is-invalid');
                isValidCPF = false;
              }

              if (!isValidCPF) {
                $('#loadingSpinner').hide();
                Swal.fire({
                  title: 'CPF(s) já cadastrado no Evento.',
                  text: 'O(s) CPF(s) ' + lisCPFCadastrados + ' informado(s) está(ão) cadastrado(s) no evento.',
                  icon: 'error',
                  confirmButtonClass: 'btn btn-success',
                });
                return;
              }
            }
            // Continuar com a submissão dos dados
            $('#submiContatoADD').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Salvando...');

            $.ajax({
              type: 'POST',
              url: '<?php echo CxUrl::site('rep_eleitos:api:salvarContEvento') ?>',
              data: $('#form-cadastro-contato-evento').serialize(),
              success: function(response) {
                Swal.fire({
                  icon: "success",
                  title: 'Sucesso!',
                  text: 'Dados salvos com sucesso.',
                  confirmButtonClass: 'btn btn-success',
                }).then(function(result) {
                  if (result.value) {
                    // Fechar o modal
                    $('#adicionarContadosModal').modal('hide');
                    // Reabilitar o botão "Salvar"
                    $('#submiContatoADD').prop('disabled', false).html('<i class="bx bx-check d-block d-sm-none"></i><span class="d-none d-sm-block">Salvar</span>');
                    var nomebtn = '#btnpessoas' + $('#cnpj').val();
                    $(nomebtn).html('<i class="bx bxs-edit"></i>');
                  }
                });
              },
              error: function(jqXHR, textStatus, errorThrown) {
                console.error('Erro ao salvar os dados:', textStatus, errorThrown);
                Swal.fire({
                  title: 'Erro',
                  text: 'Não foi possível salvar os dados. Tente novamente.',
                  icon: 'error',
                  confirmButtonClass: 'btn btn-success',
                });
                // Reabilitar o botão "Salvar"
                $('#submiContatoADD').prop('disabled', false).html('<i class="bx bx-check d-block d-sm-none"></i><span class="d-none d-sm-block">Salvar</span>');
              }
            });

          } catch (error) {
            console.error('Erro na verificação dos CPFs:', error);
            $('#loadingSpinner').hide();
            Swal.fire({
              title: 'Erro',
              text: 'Ocorreu um erro durante a verificação dos CPFs. Tente novamente.',
              icon: 'error',
              confirmButtonClass: 'btn btn-success',
            });
          }
        });

        /****************************************
         *       js of zero configuration        *
         ****************************************/

        $('.zero-configuration').DataTable();

        /********************************************
         *        js of Order by the grouping        *
         ********************************************/

        var groupingTable = $('.row-grouping').DataTable({
          "columnDefs": [{
            "visible": false,
            "targets": 2
          }],
          "order": [
            [2, 'asc']
          ],
          "displayLength": 10,
          "drawCallback": function(settings) {
            var api = this.api();
            var rows = api.rows({
              page: 'current'
            }).nodes();
            var last = null;

            api.column(2, {
              page: 'current'
            }).data().each(function(group, i) {
              if (last !== group) {
                $(rows).eq(i).before(
                  '<tr class="group"><td colspan="5">' + group + '</td></tr>'
                );

                last = group;
              }
            });
          }
        });

        $('.row-grouping tbody').on('click', 'tr.group', function() {
          var currentOrder = groupingTable.order()[0];
          if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
            groupingTable.order([2, 'desc']).draw();
          } else {
            groupingTable.order([2, 'asc']).draw();
          }
        });

        /*************************************
         *       js of complex headers        *
         *************************************/

        $('.complex-headers').DataTable();


        /*****************************
         *       js of Add Row        *
         ******************************/

        var t = $('.add-rows').DataTable();
        var counter = 2;

        $('#addRow').on('click', function() {
          t.row.add([
            counter + '.1',
            counter + '.2',
            counter + '.3',
            counter + '.4',
            counter + '.5'
          ]).draw(false);

          counter++;
        });


        /**************************************************************
         * js of Tab for COLUMN SELECTORS WITH EXPORT AND PRINT OPTIONS *
         ***************************************************************/

        $('.dataex-html5-selectors').DataTable({
          dom: 'Bfrtip',
          buttons: [{
              extend: 'copyHtml5',
              exportOptions: {
                columns: [0, ':visible']
              }
            },
            {
              extend: 'pdfHtml5',
              exportOptions: {
                columns: ':visible'
              }
            },
            {
              text: 'JSON',
              action: function(e, dt, button, config) {
                var data = dt.buttons.exportData();

                $.fn.dataTable.fileSave(
                  new Blob([JSON.stringify(data)]),
                  'Export.json'
                );
              }
            },
            {
              extend: 'print',
              exportOptions: {
                columns: ':visible'
              }
            }
          ]
        });

        /**************************************************
         *       js of scroll horizontal & vertical        *
         **************************************************/

        $('.scroll-horizontal-vertical').DataTable({
          "scrollY": 200,
          "scrollX": true
        });
      });

      function ocultarCPF(cpf) {
        return '***.***.***-' + cpf.slice(-2);
        // if (cpf.length >= 11) {
        //   return '***.***.***-' + cpf.slice(-2);
        // }
        // return cpf;
      }


      function primeiroNome(name) {
        const array = name.split(" ");
        return array[0];
      }

      // Oculta o e-mail para retornar assim: fula********@*******com
      function ocultarEmail(email) {
        // Verifica se o e-mail é válido
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailRegex.test(email)) {
          // Divide o e-mail em duas partes: usuário e domínio
          const [usuario, dominio] = email.split('@');

          // Exibir os primeiros 4 caracteres do usuário e ocultar o restante
          const usuarioOcultado = usuario.substring(0, 4) + '*'.repeat(Math.max(0, usuario.length - 4));

          // Exibir o primeiro caractere do domínio e ocultar o restante até os últimos 3 caracteres
          const dominioOcultado = dominio.substring(0, 1) + '*'.repeat(Math.max(0, dominio.length - 4)) + dominio.slice(-3);

          // Monta o e-mail com a máscara aplicada
          const emailOcultado = `${usuarioOcultado}@${dominioOcultado}`;

          return emailOcultado;
        } else {
          // Retorna uma mensagem de erro se o e-mail for inválido
          return "";
        }
      }

      // Oculta o telefone para retornar assim: Saída: (61) 9*****23
      function ocultarTelefone(telefone) {
        // Remove todos os caracteres que não são números
        const somenteNumeros = telefone.replace(/\D/g, '');

        // Verifica se o telefone tem o tamanho correto (11 dígitos, incluindo DDD)
        //if (somenteNumeros.length === 11) {
        // Divide o telefone em partes: DDD, primeiro dígito, parte oculta e últimos 2 dígitos
        const ddd = somenteNumeros.substring(0, 2); // Os primeiros 2 dígitos (DDD)
        const primeiroDigito = somenteNumeros.substring(2, 3); // O primeiro dígito do número (normalmente 9)
        const ocultado = '*'.repeat(5); // 5 asteriscos para ocultar o meio
        const ultimosDois = somenteNumeros.slice(-2); // Os últimos 2 dígitos

        // Monta o número com a máscara (00) 9*****00
        const telefoneFormatado = `(${ddd}) ${primeiroDigito}${ocultado}${ultimosDois}`;

        return telefoneFormatado;
        // } else {
        //   // Retorna uma mensagem de erro se o telefone não tiver o tamanho esperado
        //   return "";
        // }
      }

      // Oculta o nome para retornar assim: Saída: Fulano ** ***** **uro
      function ocultarNome(nomeCompleto) {
        // Quebra o nome completo em partes
        const partesNome = nomeCompleto.split(" ");

        // Mantém o primeiro nome como está
        const primeiroNome = partesNome[0];

        // Pega o último nome
        const ultimoNome = partesNome[partesNome.length - 1];

        // Oculta todas as letras do último nome, exceto as últimas 3
        const tamanhoUltimoNome = ultimoNome.length;
        let ultimoNomeOculto;
        if (tamanhoUltimoNome > 3) {
          ultimoNomeOculto = '*'.repeat(tamanhoUltimoNome - 3) + ultimoNome.slice(-3);
        } else {
          // Se o último nome tiver 3 ou menos letras, não oculta nada
          ultimoNomeOculto = ultimoNome;
        }

        // Oculta todos os nomes intermediários
        const nomesIntermediariosOcultos = [];
        for (let i = 1; i < partesNome.length - 1; i++) {
          nomesIntermediariosOcultos.push('*'.repeat(partesNome[i].length));
        }

        // Constrói o nome final
        const nomeOcultado = [primeiroNome, ...nomesIntermediariosOcultos, ultimoNomeOculto].join(' ');

        return nomeOcultado;
      }
    </script>

<?
  }
} else {

  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo Contém dados para Exibição!</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}


?>