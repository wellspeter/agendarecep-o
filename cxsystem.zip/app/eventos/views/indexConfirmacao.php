<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/indexDao.php');
$dao = new indexDAO();
$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$dadosArvoreAcesso = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Confirmação de Convidados Eventos Regionais</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_tocantins.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Tocantins</h4>
            <p class="card-text text-ellipsis">
             Data do evento 31/10/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'TO']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_amapa.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Amapá</h4>
            <p class="card-text text-ellipsis">
             Data do evento 31/10/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'AP']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_bahia.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Bahia</h4>
            <p class="card-text text-ellipsis">
             Data do evento 13/12/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'BA']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_ceara.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Ceara</h4>
            <p class="card-text text-ellipsis">
             Data do evento 22/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'CE']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_sergipe.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Sergipe</h4>
            <p class="card-text text-ellipsis">
             Data do evento 08/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'SE']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_maranhao.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Maranhão</h4>
            <p class="card-text text-ellipsis">
             Data do evento 29/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'MA']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_mato_grosso.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Mato Grosso</h4>
            <p class="card-text text-ellipsis">
             Data do evento 29/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'MT']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_rio_de_janeiro.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Rio de Janeiro</h4>
            <p class="card-text text-ellipsis">
             Data do evento 12/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:municipiosConfirmacaoEvento', ['estado' => 'RJ']) ?>" class="white">Clique aqui p/ Confirmar Convidado no  Evento</a> 
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->
<div class="modal fade" id="recepcaoModal" tabindex="-1" role="dialog" aria-labelledby="editarAcoesModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form id="form-edicao-acao" method="post" action="javascript:void(0)">
        <div class="modal-header border-bottom">
          <h5 class="modal-title" id="tituloAcaoEditar">Bem vindo a Recepção de Eleitos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="bx bx-x"></i>
          </button>
        </div>
        <div class="modal-body" style="padding:0px;">
          <div class="">
            <div id="carousel-example-card" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carousel-example-card" data-slide-to="0" class="active" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="1" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="2" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="3" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="4" style="color: #000000;"></li>
              </ol>
              <div class="carousel-inner rounded-0" role="listbox">
                <div class="carousel-item active">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem1.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem2.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem3.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem4.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem5.png" class="d-block w-100" alt="">
                </div>
              </div>
              <a class="carousel-control-prev" href="#carousel-example-card" role="button" data-slide="prev">
                <span class="bx bx-chevron-left icon-prev" aria-hidden="true" style="color: #000000;"></span>
                <span class="sr-only">Voltar</span>
              </a>
              <a class="carousel-control-next" href="#carousel-example-card" role="button" data-slide="next">
                <span class="bx bx-chevron-right icon-next" aria-hidden="true" style="color: #000000;"></span>
                <span class="sr-only">Próximo</span>
              </a>
            </div>
            <div class="card-body">
              <div class="checkbox checkbox-primary checkbox-shadow">
                <input type="checkbox" id="checkboxNaoVerModal" onchange="atualizarVisualizacaoModalInicial();">
                <label for="checkboxNaoVerModal">Não ver mais essa mensagem</label>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>


<script>
  function verificaLocalstorage() {
    // //verificando se existe o elemento no localStorage
    let checkExist;
    checkExist = localStorage.getItem("naoVerModalBemVindoAcoes");

    if (!checkExist) {
      console.log("não tem dados");
      localStorage.setItem("naoVerModalBemVindoAcoes", 1);
      return 1;
    }

    return checkExist;
  }

  function atualizarVisualizacaoModalInicial() {
    // Verifica se tem ou nao o elemento no localstorage
    verificaLocalstorage();
    // verifica o valor retornado, se o valor vier comom 0, o cliente ja informou que nao quer ver mais o modal
    if (verificaLocalstorage() == 1) {
      // abre o modal
      $('#recepcaoModal').modal('show');
      // pega o evento do click do check para adicionar o valor para o 
      const checkNaoVerMaisModal = document.getElementById("checkboxNaoVerModal");
      if (this.checkNaoVerMaisModal) {
        localStorage.setItem("naoVerModalBemVindoAcoes", 1);
      } else {
        localStorage.setItem("naoVerModalBemVindoAcoes", 0);
      }

    }
  }

  $(document).ready(function() {
    verificaLocalstorage();
    if (verificaLocalstorage() == 1) {
      // abre o modal
      $('#recepcaoModal').modal('show');
    }


    /****************************************
     *       js of zero configuration        *
     ****************************************/

    $('.zero-configuration').DataTable();

    /********************************************
     *        js of Order by the grouping        *
     ********************************************/

    var groupingTable = $('.row-grouping').DataTable({
      "columnDefs": [{
        "visible": false,
        "targets": 2
      }],
      "order": [
        [2, 'asc']
      ],
      "displayLength": 10,
      "drawCallback": function(settings) {
        var api = this.api();
        var rows = api.rows({
          page: 'current'
        }).nodes();
        var last = null;

        api.column(2, {
          page: 'current'
        }).data().each(function(group, i) {
          if (last !== group) {
            $(rows).eq(i).before(
              '<tr class="group"><td colspan="5">' + group + '</td></tr>'
            );

            last = group;
          }
        });
      }
    });

    $('.row-grouping tbody').on('click', 'tr.group', function() {
      var currentOrder = groupingTable.order()[0];
      if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
        groupingTable.order([2, 'desc']).draw();
      } else {
        groupingTable.order([2, 'asc']).draw();
      }
    });

    /*************************************
     *       js of complex headers        *
     *************************************/

    $('.complex-headers').DataTable();


    /*****************************
     *       js of Add Row        *
     ******************************/

    var t = $('.add-rows').DataTable();
    var counter = 2;

    $('#addRow').on('click', function() {
      t.row.add([
        counter + '.1',
        counter + '.2',
        counter + '.3',
        counter + '.4',
        counter + '.5'
      ]).draw(false);

      counter++;
    });


    /**************************************************************
     * js of Tab for COLUMN SELECTORS WITH EXPORT AND PRINT OPTIONS *
     ***************************************************************/

    $('.dataex-html5-selectors').DataTable({
      dom: 'Bfrtip',
      buttons: [{
          extend: 'copyHtml5',
          exportOptions: {
            columns: [0, ':visible']
          }
        },
        {
          extend: 'pdfHtml5',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          text: 'JSON',
          action: function(e, dt, button, config) {
            var data = dt.buttons.exportData();

            $.fn.dataTable.fileSave(
              new Blob([JSON.stringify(data)]),
              'Export.json'
            );
          }
        },
        {
          extend: 'print',
          exportOptions: {
            columns: ':visible'
          }
        }
      ]
    });

    /**************************************************
     *       js of scroll horizontal & vertical        *
     **************************************************/

    $('.scroll-horizontal-vertical').DataTable({
      "scrollY": 200,
      "scrollX": true
    });
  });
</script>