<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

// require_once(__DIR__ . '/../daos/indexDao.php');
// $dao = new indexDAO();
// $datainsert = new Datetime();
// $dataEnvio = $datainsert->format('Y-m-d');
// $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Convidados confirmados para os Eventos</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_tocantins.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Tocantins</h4>
            <p class="card-text text-ellipsis">
             Data do evento 31/10/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'TO']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_amapa.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Amapá</h4>
            <p class="card-text text-ellipsis">
             Data do evento 31/10/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'AP']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_bahia.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Bahia</h4>
            <p class="card-text text-ellipsis">
             Data do evento 13/12/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'BA']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_ceara.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Ceara</h4>
            <p class="card-text text-ellipsis">
             Data do evento 22/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'CE']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_sergipe.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Sergipe</h4>
            <p class="card-text text-ellipsis">
             Data do evento 08/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'SE']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_maranhao.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Maranhão</h4>
            <p class="card-text text-ellipsis">
             Data do evento 29/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'MA']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_mato_grosso.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Mato Grosso</h4>
            <p class="card-text text-ellipsis">
             Data do evento 29/11/2024.
            </p>
          </div>
          <div class="overlay-status">
            <!-- <p class="mb-25"><small>Last updated 3 mins ago</small></p> -->
            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'MT']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6 col-sm-12">
      <div class="card">
        <img class="card-img img-fluid" src="<?php echo CxUrl::statics() ?>/app-assets/images/cards/card_evento_rio_de_janeiro.png" alt="Card image">
        <div class="card-img-overlay overlay-dark bg-overlay d-flex justify-content-between flex-column">
          <div class="overlay-content">
            <h4 class="card-title mb-50">Rio de Janeiro</h4>
            <p class="card-text text-ellipsis">
             Data do evento 12/11/2024.
            </p>
          </div>
          <div class="overlay-status">

            <a href="<?php echo CxUrl::site('eventos:relatorioListaConvidadosEvento', ['estado' => 'RJ']) ?>" class="white">Clique aqui p/ Lista de Convidados</a> 
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
 

  $(document).ready(function() {

    
  });
</script>