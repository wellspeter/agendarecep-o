<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];

$estado = CxRequest::params('estado');
$estadoDescrito = '';
switch ($estado) {
  case 'TO':
    $estadoDescrito = "Tocantins";
    break;
  case 'AP':
    $estadoDescrito = "Amapá";
    break;
  case 'BA':
    $estadoDescrito = "Bahia";
    break;
  case 'CE':
    $estadoDescrito = "Ceará";
    break;
  case 'SE':
    $estadoDescrito = "Sergipe";
    break;
  case 'MA':
    $estadoDescrito = "Maranhão";
    break;
  case 'MT':
    $estadoDescrito = "Mato Grosso";
    break;
  case 'RJ':
    $estadoDescrito = "Rio de Janeiro";
    break;
}


// if($matricula == '145234'){
//   $lotacao_fisica =  6753;
// }

//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/municipiosEventoDao.php');
$dao = new municipiosEventoDao();

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);

if (count($acessoUsuarioPorMatricula) > 0) {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
} else {
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}

//echo var_dump($acessoUsuarioPorMatricula);
//echo var_dump($dadosArvoreAcesso);
if (count($dadosArvoreAcesso) > 0) {
  $qtdConvidados = $dao->contagemConvidadosEvento($estado);
  $listMunicipios = $dao->municipiosPorUf($estado);
  //echo var_dump($qtdConvidados);
?>
  <style>
    .faq-search button {
      /* search button position */
      right: 8px;
      top: 6px;
    }

    .faq .wrapper-content {
      display: none;
    }

    .faq .wrapper-content.active {
      display: block;
    }

    @media only screen and (max-width: 576px) {
      .faq-title {
        font-size: 1.73rem;
      }

      .faq-subtitle {
        font-size: 1.3rem;
      }
    }

    @media only screen and (max-width: 768px) {
      .faq-search .faq-search-width {
        /* search box responsive */
        width: 100% !important;
      }
    }

    @media only screen and (min-width: 1024px) {
      .faq-bg {
        padding: 5rem 0 !important;
      }
    }
  </style>

  <div class="container-fluid">
    <div class="row align-items-center  mb-2">

      <div class="col-10">
        <h4 class=""><? echo $estadoDescrito ?></h4>
      </div>
      <div class="col-2">
        <div class="my-auto  text-right">
          <div class="statistics">
            <span class="font-medium-2 text-bold-600" id="divConfirmados">Presença no Evento: <? if (count($qtdConvidados) > 0) {
                                                                                                echo $qtdConvidados[0]['total_confirmacao'];
                                                                                              } else {
                                                                                                echo '0';
                                                                                              } ?></span>
          </div>
          <div class="statistics-date">
            <small class="text-muted " id="divCadastrados">(Cadastrados: <? if (count($qtdConvidados) > 0) {
                                                                            echo $qtdConvidados[0]['total_cadastrados'];
                                                                          } else {
                                                                            echo '0';
                                                                          } ?>)</small>
          </div>
        </div>
      </div>
    </div>
    <section class="faq-search">
      <div class="row">
        <div class="col-12">
          <div class="card faq-bg bg-transparent box-shadow-0 p-1 p-md-5">
            <div class="card-body p-0">
              <h1 class="faq-title text-center mb-3">Confirmação de Convidados!</h1>
              <form>
                <fieldset class="faq-search-width form-group position-relative w-50 mx-auto">
                  <input type="text" class="form-control round form-control-lg shadow pl-2 text-center" id="searchbar">
                  <button class="btn btn-primary round position-absolute d-none d-sm-block" type="button" id="btnBuscaCPF" onclick="popularParametrosModal();">Busca por CPF</button>
                  <button class="btn btn-primary round position-absolute d-block d-sm-none" type="button"><i class="bx bx-search"></i></button>
                </fieldset>
              </form>
              <!-- <p class="card-text text-center mt-3 font-medium-1 text-muted" id="divAlerta">
                Informe um CPF</p> -->
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>


  <!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->
  <div class="modal fade" id="adicionarContadosModal" tabindex="-1" role="dialog" aria-labelledby="adicionarContadosModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="form-cadastro-contato-evento" method="post" action="javascript:void(0)">

          <input type="hidden" id="cnpj" name="cnpj">
          <input type="hidden" id="matricula" name="matricula" value="<? echo $matricula ?>">
          <input type="hidden" id="estado" name="estado" value="<? echo $estado ?>">
          <input type="hidden" id="idEvento" name="idEvento" value="1">
          <input type="hidden" id="tipocontato" name="tipocontato">
          <input type="hidden" id="actionType" name="actionType" value="">

          <div class="modal-header border-bottom">
            <h5 class="modal-title" id="tituloAcaoADD">Confirmação de Presença no Evento</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="bx bx-x"></i>
            </button>
          </div>

          <div class="modal-body" style="padding:0px; margin-top:10px">
            <!-- Spinner de Carregamento -->
            <div id="loadingSpinner" class="text-center my-3">
              <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Carregando...</span>
              </div>
            </div>

            <!-- Conteúdo do Formulário (Inicialmente Oculto) -->
            <div id="formContent" style="display: none;">
              <!-- Seu conteúdo de formulário existente -->
              <div class="col">
                <div class="row">
                  <!-- Contato 1 -->
                  <div class="col-9">
                    <div class="form-group">
                      <label>Nome</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="nomeCont1_masc" readonly="readonly" name="nomeCont1_masc">
                        <input type="hidden" id="nomeCont1" name="nomeCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-user'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>

                  <div class="col-3">
                    <div class="form-group">
                      <label>CPF</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="cpfCont1_masc" readonly="readonly" name="cpfCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        <input type="hidden" id="cpfCont1" name="cpfCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-building-house'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-9">
                    <div class="form-group">
                      <label>Email</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="emailCont1_masc" readonly="readonly" name="emailCont1_masc">
                        <input type="hidden" id="emailCont1" name="emailCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-envelope'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>

                  <div class="col-3">
                    <div class="form-group">
                      <label>Celular</label>
                      <fieldset class="form-group position-relative has-icon-left">
                        <input type="text" class="form-control" id="celularCont1_masc" readonly="readonly" name="celularCont1_masc" maxlength="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        <input type="hidden" id="celularCont1" name="celularCont1">
                        <div class="form-control-position">
                          <i class='bx bxs-phone'></i>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="row" id="municipioRow" style="display: none;">
                  <div class="col-12">
                    <div class="form-group">
                      <label>Município</label>
                      <select class="form-control" id="municipio" name="municipio" onchange="verificarTipo()">
                        <option value="">Selecione um município</option>
                        <!-- As opções serão adicionadas via JavaScript -->
                      </select>
                    </div>
                  </div>
                </div>

                <div id="vinculacao" style="display: none;">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label>Cargo</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="cargoCont1_masc" name="cargoCont1_masc" maxlength="200">
                          <div class="form-control-position">
                            <i class='bx bxs-user'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>

                    <div class="col-6">
                      <div class="form-group">
                        <label>Órgão Vinculado</label>
                        <fieldset class="form-group position-relative has-icon-left">
                          <input type="text" class="form-control" id="orgaoVinculadoCont1_masc" name="orgaoVinculadoCont1_masc" maxlength="200">
                          <div class="form-control-position">
                            <i class='bx bxs-building-house'></i>
                          </div>
                        </fieldset>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
              <i class="bx bx-x d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Cancelar</span>
            </button>
            <button type="button" class="btn btn-primary ml-1" id="submiContatoADD" value="submiContatoADD">
              <i class="bx bx-check d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Confirmar Presença</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>



  <script>
    <? echo "const uf = '" . $estado . "';" ?>
    <? echo 'const municipios = ' . json_encode($listMunicipios, JSON_UNESCAPED_UNICODE) . ';' ?>

    function popularParametrosModal() {
      var cpf = $('#searchbar').val();

      if (cpf == '') {
        toastr['error']('CPF não informado', 'Informe o CPF para que seja realizada a busca', {
          positionClass: 'toast-bottom-full-width',
          rtl: true
        });
        return;
      }

      if (!testaCPF(cpf)) {
        toastr['error']('Informe o CPF correto para que seja realizada a busca', 'CPF informado incorreto', {
          positionClass: 'toast-bottom-full-width',
          rtl: true
        });
        return;
      }

      // Limpar todos os campos
      limparcampo();

      var link = '<?php echo CxUrl::site('eventos:api:consultarDadosContatoCPF') ?>'.slice(0, -10) + cpf;
      link = link + '/' + uf;

      $.ajax({
        url: link,
        method: 'GET',
        dataType: 'json',
        success: function(data) {
          if (data.length > 0) {
            // Dados encontrados - preencher campos e torná-los readonly
            configurarModal(data[0], true);
          } else {
            // Nenhum dado encontrado - perguntar se deseja cadastrar
            $('#loadingSpinner').hide();
            Swal.fire({
              title: 'Pessoa não cadastrada',
              text: 'Deseja realizar o cadastro agora?',
              icon: 'warning',
              showCancelButton: true,
              confirmButtonText: 'Sim',
              cancelButtonText: 'Não'
            }).then((result) => {
              if (result.isConfirmed) {
                // Usuário quer cadastrar
                configurarModal({
                  cpfCont: cpf
                }, false);
              } else {
                // Fechar o modal
                //$('#adicionarContadosModal').modal('hide');
              }
            });
          }
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.error('Erro ao popular o modal:', textStatus, errorThrown);
          alert('Ocorreu um erro ao carregar os dados. Por favor, tente novamente.');

          // Ocultar o spinner e fechar o modal em caso de erro
          $('#loadingSpinner').hide();
          $('#adicionarContadosModal').modal('hide');
        }
      });
    }

    function updateEventCounts() {
      // Definir a URL da API
      var apiUrl = '<?php echo CxUrl::site('eventos:api:obterContagemEvento') ?>'.slice(0, -4) + uf;

      // Obter o parâmetro 'estado' (certifique-se de que está disponível no JavaScript)
      var estado = '<?php echo $estado ?>';

      // Fazer uma requisição AJAX GET para a API
      $.ajax({
        url: apiUrl,
        method: 'GET',
        dataType: 'json',
        success: function(data) {
          // Supondo que a API retorna um objeto com 'total_cadastrados' e 'total_confirmacao'
          if (data && data[0].total_cadastrados !== undefined && data[0].total_confirmacao !== undefined) {
            $('#divCadastrados').text('(Cadastrados: ' + data[0].total_cadastrados + ')');
            $('#divConfirmados').text('Presença no Evento: ' + data[0].total_confirmacao);
          }
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.error('Erro ao obter contagem do evento:', textStatus, errorThrown);
          // Opcionalmente, você pode exibir uma mensagem de erro ou tratar o erro de outra forma
        }
      });
    }


    function configurarModal(data, isReadonly) {

      // Exibir o modal
      $('#adicionarContadosModal').modal('show');
      //ocultar campo de orgao vinculado e fução
      const divVinculada = document.getElementById("vinculacao");
      divVinculada.style.display = "none";

      // Exibir o spinner e ocultar o conteúdo do formulário
      $('#loadingSpinner').show();
      $('#formContent').hide();

      // Preencher os campos com os dados ou deixar em branco
      $('#idEvento').val(data.NU_EVENTO || '');
      $('#tipocontato').val(data.tipocontato || '');
      $('#cnpj').val(data.CO_CNPJ || '');

      $('#nomeCont1_masc').val(data.nomeCont || '').prop('readonly', isReadonly);
      $('#cpfCont1_masc').val(data.cpfCont || '').prop('readonly', true); // CPF sempre readonly
      $('#cpfCont1').val(data.cpfCont || ''); // Campo hidden

      $('#celularCont1_masc').val(data.celularCont || '').prop('readonly', isReadonly);
      $('#emailCont1_masc').val(data.emailCont || '').prop('readonly', isReadonly);


      // Mostrar ou ocultar o combobox de municípios
      if (isReadonly) {
        $('#municipioRow').hide();
        $('#actionType').val('confirm'); // Definir o tipo de ação como 'confirm'
      } else {
        $('#municipioRow').show();
        $('#actionType').val('register'); // Definir o tipo de ação como 'register'
        // Popular o combobox de municípios
        populateMunicipiosCombobox();
      }

      // Ajustar o título do modal
      $('#tituloAcaoADD').text(isReadonly ? 'Confirmação de Presença no Evento' : 'Cadastro de Novo Convidado');

      // Ocultar o spinner e exibir o conteúdo do formulário
      $('#loadingSpinner').hide();
      $('#formContent').show();
    }

    function limparcampo() {
      $('#idEvento').val('');
      $('#tipocontato').val('');

      $('#nomeCont1_masc').val('').prop('readonly', true);
      $('#cpfCont1_masc').val('').prop('readonly', true);
      $('#cpfCont1').val('');

      $('#celularCont1_masc').val('').prop('readonly', true);
      $('#emailCont1_masc').val('').prop('readonly', true);

      $('#orgaoVinculadoCont1_masc').val('');
      $('#cargoCont1_masc').val('');

      // Ocultar o combobox de municípios por padrão
      $('#municipioRow').hide();

      //ocultar campo de orgao vinculado e fução
      const divVinculada = document.getElementById("vinculacao");
      divVinculada.style.display = "none";

    }

    function populateMunicipiosCombobox() {
      $('#municipio').empty();
      $('#municipio').append('<option value="">Selecione um município</option>');

      municipios.forEach(function(municipio) {
        if (municipio.tipo == 'E') {
          $('#municipio').append(
            //$('#municipio').append('<option value="0">Outros</option>')
            $('<option>', {
              value: municipio.cnpj,
              text: 'Outros'
            })
          )
        } else {
          $('#municipio').append(
            $('<option>', {
              value: municipio.cnpj,
              text: municipio.nome
            })
          )
        }
      });
    }

    function testaCPF(strCPF) {
      var Soma;
      var Resto;
      Soma = 0;
      if (strCPF == "00000000000") return false;

      for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
      Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11)) Resto = 0;
      if (Resto != parseInt(strCPF.substring(9, 10))) return false;

      Soma = 0;
      for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
      Resto = (Soma * 10) % 11;

      if ((Resto == 10) || (Resto == 11)) Resto = 0;
      if (Resto != parseInt(strCPF.substring(10, 11))) return false;
      return true;
    }

    function verificarTipo() {

      //const selectMunicipio =  $('#municipio')
      //obtendo o valor do combobox
      const cnpjSelecionado = $('#municipio').val();

      //encontrar o cnpj na lista correspondente
      const itemSelecionado = municipios.find(item => item.cnpj === cnpjSelecionado);

      //referencia da div
      const divVinculada = document.getElementById("vinculacao");

      //obter a div se o item for encontrado
      if (itemSelecionado) {
        if (itemSelecionado.tipo === "E") {
          $('#orgaoVinculadoCont1_masc').val('');
          $('#cargoCont1_masc').val('');
          divVinculada.style.display = "block";
        } else {
          divVinculada.style.display = "none";
        }
      } else {
        divVinculada.style.display = "none";
      }
    }

    $(document).ready(function() {

      // atualizar dados de presença no evento
      updateEventCounts();
      // Configurar a função para ser chamada a cada 5 segundos (5000 milissegundos)
      setInterval(updateEventCounts, 5000);

      //Salvar os dados
      $('#submiContatoADD').on('click', function() {
        let isValid = true;

        // Limpar mensagens de erro anteriores
        $('.is-invalid').removeClass('is-invalid');

        // Validar Nome (sempre obrigatório)
        if ($('#nomeCont1_masc').val().trim() === '') {
          $('#nomeCont1_masc').addClass('is-invalid');
          isValid = false;
        }

        // Validar Telefone (se preenchido)
        const telefone = $('#celularCont1_masc').val().trim();
        if (telefone !== '') {
          if ($('#actionType').val() == 'register') {
            const telefoneRegex = /^\d{11}$/;
            if (!telefoneRegex.test(telefone)) {
              $('#celularCont1_masc').addClass('is-invalid');
              isValid = false;
            }
          }
        }


        // Validar Email (se preenchido)
        const email = $('#emailCont1_masc').val().trim();
        if (email !== '') {
          if ($('#actionType').val() == 'register') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
              $('#emailCont1_masc').addClass('is-invalid');
              isValid = false;
            }
          }
        }

        // Validar Município se o combobox estiver visível (apenas no cadastro)
        if ($('#municipioRow').is(':visible')) {
          if ($('#municipio').val() === '') {
            $('#municipio').addClass('is-invalid');
            isValid = false;
          } else {
            $('#municipio').removeClass('is-invalid');
          }
        }

        if ($('#vinculacao').is(':visible')) {
          if ($('#cargoCont1_masc').val().trim() === '') {
            $('#cargoCont1_masc').addClass('is-invalid');
            isValid = false;
          } else {
            $('#cargoCont1_masc').removeClass('is-invalid');
          }
        }

        if (!isValid) {
          toastr['error']('Por favor, corrija os campos destacados.', 'Erro de validação', {
            positionClass: 'toast-bottom-full-width',
            rtl: true
          });
          return;
        }

        // Desabilitar o botão e mostrar spinner
        $('#submiContatoADD').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Salvando...');

        // Coletar os dados do formulário
        const formData = $('#form-cadastro-contato-evento').serialize();
        const link = '<?php echo CxUrl::site('rep_eleitos:api:confirmarContEvento') ?>';

        // Fazer o POST via AJAX
        $.ajax({
          type: 'POST',
          url: link,
          data: formData,
          success: function(response) {
            Swal.fire({
              icon: "success",
              title: 'Sucesso!',
              text: $('#actionType').val() === 'register' ? 'Cadastro realizado e presença confirmada.' : 'Presença confirmada com sucesso.',
              confirmButtonClass: 'btn btn-success',
            }).then(function(result) {
              if (result.value) {
                //Atualizar o campo de presentes no evento
                updateEventCounts();
                // Limpar o campo de busca
                $('#searchbar').val('');
                // Fechar o modal
                $('#adicionarContadosModal').modal('hide');
                // Reabilitar o botão
                $('#submiContatoADD').prop('disabled', false).html('<span class="d-none d-sm-block">Confirmar Presença</span>');
              }
            })
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error('Erro ao salvar os dados:', textStatus, errorThrown);
            Swal.fire({
              title: 'Erro',
              text: 'Não foi possível salvar os dados. Tente novamente.',
              icon: 'error',
              confirmButtonClass: 'btn btn-danger',
            });
            // Reabilitar o botão
            $('#submiContatoADD').prop('disabled', false).html('<span class="d-none d-sm-block">Confirmar Presença</span>');
          }
        });
      });


    });
  </script>

<?

} else {

  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo tem acesso a essa funcionalidade</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}


?>