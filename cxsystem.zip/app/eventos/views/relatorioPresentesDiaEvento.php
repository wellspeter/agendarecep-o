<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

// require_once(__DIR__ . '/../daos/indexDao.php');
// $dao = new indexDAO();
// $datainsert = new Datetime();
// $dataEnvio = $datainsert->format('Y-m-d');
// $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorMatricula($matricula, $dataEnvio);


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">lista de Convidados Presentes nos Eventos</h4>
    </div>
  </div>
  <div class="row">
    <div class="card col">
      <div class="card-header">
        <h4 class="card-title "></h4>
      </div>

      <div class="card-body ">
        <table id="table-extended-success" class="table zero-configuration mb-0">
          <thead>
            <tr>
              <th>Evento</th>
              <th>Nome Evento</th>
              <th>Data</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Evento Regional</td>
              <td>Amapá</td>
              <td>31/10/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'AP'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Tocantins</td>
              <td>31/10/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'TO'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Bahia</td>
              <td>13/12/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'BA'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Ceará</td>
              <td>22/11/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'CE'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Sergipe</td>
              <td>08/11/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'SE'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Maranhão</td>
              <td>29/11/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'MA'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Mato Grosso</td>
              <td>29/11/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'MT'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
            <tr>
              <td>Evento Regional</td>
              <td>Rio de Janeiro</td>
              <td>12/11/2024</td>
              <td><a href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEventoConvidados', ['estado' => 'RJ'])  ?>"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>


  </div>
</div>

<script>
  $(document).ready(function() {


  });
</script>