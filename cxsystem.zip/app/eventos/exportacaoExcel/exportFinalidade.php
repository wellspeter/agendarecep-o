<?php
    
require_once(__DIR__ . '/../controllers/exportarEventosController.php');
$uf = CxRequest::params('uf');



$fundingUnidades = dados($uf);

// função é usada para filtrar a string antes de ser adicionada à linha de dados do Excel
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Nome do arquivo Excel para download 
$fileName = "FinalidadeUnidades_" . date('Y-m-d') ."_".$busca.".xls"; 

//Define a coluna nomeada da planilha Excel
$fields = array('UNIDADE', 'NOME', 'CNPJ','NUMERO_CONTRATO', 'TIPO_FINALIDADE','TX_JUROS', 'VALOR_CONTRATO'); 
//Adicione a primeira linha à planilha do Excel como um nome de coluna
$excelData = implode("\t", array_values($fields)) . "\n"; 

for ($i = 0; $i < count($fundingUnidades); $i++) {
    $lineData = array(
        $fundingUnidades[$i]['UNIDADE']
        ,$fundingUnidades[$i]['NOME']
        ,formatar_cnpj($fundingUnidades[$i]['CNPJ'])    
        ,$fundingUnidades[$i]['NUMERO_CONTRATO']
        ,$fundingUnidades[$i]['TIPO_FINALIDADE']
        ,$fundingUnidades[$i]['TX_JUROS']
        ,$fundingUnidades[$i]['VALOR_CONTRATO']); 
    array_walk($lineData, 'filterData'); 
    $excelData .= implode("\t", array_values($lineData)) . "\n"; 
}

// CABEÇALHO PARA DOWNLOADS 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// RENDER PARA EXCEL
echo $excelData; 
 
exit;

?>
