<?php

/**
 * Esse é o arquivo com as regras de negócios a serem utilizadas no arquivos principais.
 * Aqui é bem sim, são apenas funções com as regras de negócios. Essas funções instanciam o DAO (Data Acess Object),
 * objeto que possui as regras para buscar as informações no banco de dados;
 * 
 * (ver daos/orcamentoDao.php)
 */
require_once(__DIR__ .'/../daos/municipiosEventoDao.php');

/** */

function mascararNome($nome) {
  // Remove espaços extras
  $nome = trim($nome);
  // Separa o nome em palavras
  $partes = explode(' ', $nome);
  // Obtém o primeiro nome
  $primeiroNome = $partes[0];
  // Remove espaços para trabalhar com o nome completo sem espaços
  $nomeSemEspacos = str_replace(' ', '', $nome);
  // Obtém os 3 últimos caracteres do nome completo
  $ultimosTres = substr($nomeSemEspacos, -3);
  // Calcula o número de caracteres a serem substituídos por *
  $numAsteriscos = strlen($nomeSemEspacos) - strlen($primeiroNome) - 3;
  // Gera a sequência de asteriscos
  $asteriscos = str_repeat('*', max(0, $numAsteriscos));
  // Concatena as partes
  $nomeMascarado = $primeiroNome . $asteriscos . $ultimosTres;
  return $nomeMascarado;
}

function mascararCPF($cpf) {
  // Remove caracteres não numéricos
  $cpf = preg_replace('/\D/', '', $cpf);
  // Obtém os 3 primeiros e os 2 últimos caracteres
  $primeirosTres = substr($cpf, 0, 3);
  $ultimosDois = substr($cpf, -2);
  // Calcula o número de caracteres a serem substituídos por *
  $numAsteriscos = strlen($cpf) - 5;
  // Gera a sequência de asteriscos
  $asteriscos = str_repeat('*', max(0, $numAsteriscos));
  // Concatena as partes
  $cpfMascarado = $primeirosTres . $asteriscos . $ultimosDois;
  return $cpfMascarado;
}

function mascararCelular($celular) {
  // Remove caracteres não numéricos
  $celular = preg_replace('/\D/', '', $celular);
  // Verifica se o celular tem pelo menos 6 dígitos
  if (strlen($celular) < 6) {
      return $celular; // Ou aplique outra regra se preferir
  }
  // Obtém os 4 primeiros e os 2 últimos dígitos
  $primeirosQuatro = substr($celular, 0, 4);
  $ultimosDois = substr($celular, -2);
  // Calcula o número de caracteres a serem substituídos por *
  $numAsteriscos = strlen($celular) - 6;
  // Gera a sequência de asteriscos
  $asteriscos = str_repeat('*', max(0, $numAsteriscos));
  // Concatena as partes
  $celularMascarado = $primeirosQuatro . $asteriscos . $ultimosDois;
  return $celularMascarado;
}

function mascararEmail($email) {
  // Encontra a posição do @
  $posicaoArroba = strpos($email, '@');
  if ($posicaoArroba === false) {
      // Email inválido, retorne como está ou aplique outra regra
      return $email;
  }
  // Obtém os 3 primeiros caracteres
  $primeirosTres = substr($email, 0, 3);
  // Gera asteriscos até o @
  $asteriscosUsuario = str_repeat('*', max(0, $posicaoArroba - 3));
  // Parte após o @
  $dominio = substr($email, $posicaoArroba + 1);
  // Obtém os 4 últimos caracteres do domínio
  $ultimosQuatroDominio = substr($dominio, -4);
  // Gera asteriscos para o domínio
  $numAsteriscosDominio = strlen($dominio) - 4;
  $asteriscosDominio = str_repeat('*', max(0, $numAsteriscosDominio));
  // Concatena as partes
  $emailMascarado = $primeirosTres . $asteriscosUsuario . '@' . $asteriscosDominio . $ultimosQuatroDominio;
  return $emailMascarado;
}


// function buscaMunicipiorPorSeg($codSeg)
// {
//   $dao = new indexDAO();
//   return $dao-> buscaListaMunicipiorPorSeg($codSeg);
// }

function dadosBuscaListaVisitante($uf)
{
  $dao = new municipiosEventoDao();
  $dados = $dao-> buscarListaPessoasEventos($uf);
  $lista = [];

  foreach ($dados as $linha) {
    $newdata = [
      'NOME_MUNICIPIO' => $linha['NOME_MUNICIPIO'],
      'NOME' => $linha['NOME'],
      'CPF' => mascararCPF($linha['CPF']),
      'CELULAR' => mascararCelular($linha['CELULAR']),
      'EMAIL' => mascararEmail($linha['EMAIL']),
      'ASSINATURA' => $linha['ASSINATURA']
    ];
    array_push($lista,$newdata);
  }

  return $lista;

}



function dadosBuscaListaPresentesNoEvento($uf)
{
  $dao = new municipiosEventoDao();
  $dados = $dao-> listaPresentesNoEvento($uf);
  $lista = [];

  foreach ($dados as $linha) {
    $newdata = [
      'PRESENTE' => $linha['PRESENTE'],
      'NOME_MUNICIPIO' => $linha['NOME_MUNICIPIO'],
      'NOME' => ($linha['NOME']),
      'CPF' => ($linha['CPF']),
      'CELULAR' => ($linha['CELULAR']),
      'EMAIL' => ($linha['EMAIL']),
      'CAD_ANTECIPADO' => $linha['CAD_ANTECIPADO'],
      'CARGO' => $linha['CARGO'],
      'ORGAO' => $linha['ORGAO']
    ];
    array_push($lista,$newdata);
  }

  return $lista;

}

function dadosBuscaListaPresentesNoEventoMascara($uf)
{
  $dao = new municipiosEventoDao();
  $dados = $dao-> listaPresentesNoEvento($uf);
  $lista = [];

  foreach ($dados as $linha) {
    $newdata = [
      'PRESENTE' => $linha['PRESENTE'],
      'NOME_MUNICIPIO' => $linha['NOME_MUNICIPIO'],
      'NOME' => mascararNome($linha['NOME']),
      'CPF' => mascararCPF($linha['CPF']),
      'CELULAR' => mascararCelular($linha['CELULAR']),
      'EMAIL' => mascararEmail($linha['EMAIL']),
      'CAD_ANTECIPADO' => $linha['CAD_ANTECIPADO'],
      'CARGO' => $linha['CARGO'],
      'ORGAO' => $linha['ORGAO']
    ];
    array_push($lista,$newdata);
  }

  return $lista;

}

