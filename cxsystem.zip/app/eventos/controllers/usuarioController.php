<?php

/**
 * Esse é o arquivo com as regras de negócios a serem utilizadas no arquivos principais.
 * Aqui é bem sim, são apenas funções com as regras de negócios. Essas funções instanciam o DAO (Data Acess Object),
 * objeto que possui as regras para buscar as informações no banco de dados;
 * 
 * (ver daos/orcamentoDao.php)
 */
require_once(__DIR__ .'/../daos/acoesDao.php');

/** */

// function buscaMunicipiorPorSeg($codSeg)
// {
//   $dao = new acoesDAO();
//   return $dao-> buscaListaMunicipiorPorSeg($codSeg);
// }
