<?php

require_once(__DIR__ . '/../../eventos/daos/municipiosEventoDao.php');

$dao = new municipiosEventoDao();

// Função para verificar e decidir qual valor salvar
function verificarCampo($original, $mascarado) {
    // Se o campo original for nulo ou estiver mascarado (contém *), retorna o original (se existir)
    // Caso contrário, retorna o mascarado (supondo que foi alterado pelo usuário)
    return ($original === null || strpos($mascarado, '*') !== false) ? ($original !== null ? $original : null) : $mascarado;
}


// // Recebe os dados do formulário
// $dataAcao = isset($_POST['dataAcaoADD']) ? $_POST['dataAcaoADD'] : null;

// Contato 1
$nomeCont1 = isset($_POST['nomeCont1']) ? $_POST['nomeCont1'] : null;
$cpfCont1 = isset($_POST['cpfCont1']) ? $_POST['cpfCont1'] : null;
$celularCont1 = isset($_POST['celularCont1']) ? $_POST['celularCont1'] : null;
$emailCont1 = isset($_POST['emailCont1']) ? $_POST['emailCont1'] : null;

$nomeCont1_masc = isset($_POST['nomeCont1_masc']) ? $_POST['nomeCont1_masc'] : null;
$cpfCont1_masc = isset($_POST['cpfCont1_masc']) ? $_POST['cpfCont1_masc'] : null;
$celularCont1_masc = isset($_POST['celularCont1_masc']) ? $_POST['celularCont1_masc'] : null;
$emailCont1_masc = isset($_POST['emailCont1_masc']) ? $_POST['emailCont1_masc'] : null;

// Contato 2
$nomeCont2 = isset($_POST['nomeCont2']) ? $_POST['nomeCont2'] : null;
$cpfCont2 = isset($_POST['cpfCont2']) ? $_POST['cpfCont2'] : null;
$celularCont2 = isset($_POST['celularCont2']) ? $_POST['celularCont2'] : null;
$emailCont2 = isset($_POST['emailCont2']) ? $_POST['emailCont2'] : null;

$nomeCont2_masc = isset($_POST['nomeCont2_masc']) ? $_POST['nomeCont2_masc'] : null;
$cpfCont2_masc = isset($_POST['cpfCont2_masc']) ? $_POST['cpfCont2_masc'] : null;
$celularCont2_masc = isset($_POST['celularCont2_masc']) ? $_POST['celularCont2_masc'] : null;
$emailCont2_masc = isset($_POST['emailCont2_masc']) ? $_POST['emailCont2_masc'] : null;

// Matrícula, CNPJ e idEvento
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
$idEvento = isset($_POST['idEvento']) ? $_POST['idEvento'] : null;

// Formatar a data
// $date = str_replace('/', '-', $dataAcao);
// $dataAcaoInformada = date('Y-m-d', strtotime($date));
$datainsert = new DateTime();

// // Criação do array com os dados
$data = [
    'nomeCont1' => strtoupper(verificarCampo($nomeCont1, $nomeCont1_masc)),
    'cpfCont1' => verificarCampo($cpfCont1, $cpfCont1_masc),
    'celularCont1' => verificarCampo($celularCont1, $celularCont1_masc),
    'emailCont1' => strtoupper(verificarCampo($emailCont1, $emailCont1_masc)),

    'nomeCont2' => strtoupper(verificarCampo($nomeCont2, $nomeCont2_masc)),
    'cpfCont2' => verificarCampo($cpfCont2, $cpfCont2_masc),
    'celularCont2' => verificarCampo($celularCont2, $celularCont2_masc),
    'emailCont2' => strtoupper(verificarCampo($emailCont2, $emailCont2_masc)),

    'matricula' => $matricula,
    'datainsert' => $datainsert->format('Y-m-d H:i:s'),
    'cnpj' => $cnpj,
    'NU_EVENTO' => $idEvento
];

//echo json_encode($data);

// // Verificar se o CNPJ já existe
$existe = $dao->verificarExistenciaCNPJ($cnpj);

if (count($existe)>0) {
    //echo json_encode(['status' => 'atualizar', 'message' => $data ]);
    // Atualizar os contatos existentes
    $result = $dao->atualizarContatosMunicipio($data);
} else {
    //echo json_encode(['status' => 'inserir', 'message' => $data ]);
    // Inserir novos contatos
    $result = $dao->inserirContatosMunicipio($data);
}

// Retorno de sucesso ou erro
if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']);
}








