<?php
  require_once(__DIR__ .'/../daos/planoNegocioDao.php');
  $dao = new planoNegocioDao();

    // Verifique se os parâmetros foram enviados via POST e atribua-os a variáveis 
    $matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
    $cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;

    $analisePlanoGoverno = isset($_POST['txtAnalisePlanoGoverno']) ? $_POST['txtAnalisePlanoGoverno'] : null; 

    $analiseNoticiasGoverno = isset($_POST['txtAnaliseNoticiasGoverno']) ? $_POST['txtAnaliseNoticiasGoverno'] : null; 

    //Folha pagamento
    $folhaRadio = isset($_POST['folhaRadio']) ? $_POST['folhaRadio'] : null; 
    $justificativaFolha = isset($_POST['txtJustificativaFolha']) ? $_POST['txtJustificativaFolha'] : null; 

    //CAIXA Políticas Públicas - CPP
    $cppRadio = isset($_POST['cppRadio']) ? $_POST['cppRadio'] : null; 
    $justificativaCPP = isset($_POST['txtJustificativaCPP']) ? $_POST['txtJustificativaCPP'] : null; 
    $qtdCPP = isset($_POST['txtQtdCPP']) ? $_POST['txtQtdCPP'] : null; 

    //Arrecadação
    $arrecadacaoRadio = isset($_POST['arrecadacaoRadio']) ? $_POST['arrecadacaoRadio'] : null;
    $justificativaArrecadacao = isset($_POST['txtJustificativaArrecadacao']) ? $_POST['txtJustificativaArrecadacao'] : null;  

    //Cobrança
    $cobrancaRadio = isset($_POST['cobrancaRadio']) ? $_POST['cobrancaRadio'] : null; 
    $justificativaCobranca = isset($_POST['txtJustificativaCobranca']) ? $_POST['txtJustificativaCobranca'] : null; 

    //Pagamento a Fornecedor
    $pagFornRadio = isset($_POST['pagFornRadio']) ? $_POST['pagFornRadio'] : null; 
    $justificativapagForn = isset($_POST['txtJustificativapagForn']) ? $_POST['txtJustificativapagForn'] : null; 

    //CONSIGNADO
    $sgrRadio = isset($_POST['sgrRadio']) ? $_POST['sgrRadio'] : null; 
    $justificativaSGR = isset($_POST['txtJustificativaSGR']) ? $_POST['txtJustificativaSGR'] : null; 

    //Esteira
    $financEsteiraRadio = isset($_POST['financEsteiraRadio']) ? $_POST['financEsteiraRadio'] : null; 
    $justificativaFinancEsteira = isset($_POST['txtJustificativaFinancEsteira']) ? $_POST['txtJustificativaFinancEsteira'] : null; 

    // OBRAS PARALIZADAS Financ
    $financObraParalRadio = isset($_POST['FinancObraParalRadio']) ? $_POST['FinancObraParalRadio'] : null; 
    $justificativaFinancObraParal = isset($_POST['txtJustificativaFinancObraParal']) ? $_POST['txtJustificativaFinancObraParal'] : null; 

    // OBRAS PARALIZADAS OGU
    $oguObrasParalRadio = isset($_POST['oguObrasParalRadio']) ? $_POST['oguObrasParalRadio'] : null; 
    $justificativaOguObrasParal = isset($_POST['txtJustificativaOguObrasParal']) ? $_POST['txtJustificativaOguObrasParal'] : null; 

    // Fundos de investimento e CDB
    $fiCDBRadio = isset($_POST['fiCDBRadio']) ? $_POST['fiCDBRadio'] : null; 
    $justificativafiCDB = isset($_POST['txtJustificativafiCDB']) ? $_POST['txtJustificativafiCDB'] : null; 

    // FAF
    $fafRadio = isset($_POST['fafRadio']) ? $_POST['fafRadio'] : null; 
    $justificativaFaf = isset($_POST['txtJustificativaFaf']) ? $_POST['txtJustificativaFaf'] : null; 

    // FUNDEB
    $fundebRadio = isset($_POST['fundebRadio']) ? $_POST['fundebRadio'] : null; 
    $justificativaFundeb = isset($_POST['txtJustificativaFundeb']) ? $_POST['txtJustificativaFundeb'] : null; 

    // QUOTA
    $quotaRadio = isset($_POST['quotaRadio']) ? $_POST['quotaRadio'] : null; 
    $justificativaQuota = isset($_POST['txtJustificativaQuota']) ? $_POST['txtJustificativaQuota'] : null; 

    // Transferências Especiais
    $tranfEspecRadio = isset($_POST['tranfEspecRadio']) ? $_POST['tranfEspecRadio'] : null; 
    $justificativaTranfEspec = isset($_POST['txtJustificativaTranfEspec']) ? $_POST['txtJustificativaTranfEspec'] : null; 

    // Selo
    $seloRadio = isset($_POST['seloRadio']) ? $_POST['seloRadio'] : null; 
    $justificativaSelo = isset($_POST['txtJustificativaSelo']) ? $_POST['txtJustificativaSelo'] : null; 

    // Programas Regionais de Benefício Social
    $benefSocialRadio = isset($_POST['benefSocialRadio']) ? $_POST['benefSocialRadio'] : null; 
    $justificativaBenefSocial = isset($_POST['txtJustificativaBenefSocial']) ? $_POST['txtJustificativaBenefSocial'] : null; 

    // Ação de Normalização 
    $acaoNormRadio = isset($_POST['acaoNormRadio']) ? $_POST['acaoNormRadio'] : null; 
    $justificativaAcaoNorm = isset($_POST['txtJustificativaAcaoNorm']) ? $_POST['txtJustificativaAcaoNorm'] : null; 

    //$date = str_replace('/', '-', $dataAcao);
    //$dataAcaoInformada = date('Y-m-d', strtotime($date));

    //$dataAcaoInformada = new Date($dataAcao);
    $datainsert = new Datetime();
    // Crie um array com os dados
    $data = [
        'matricula' => $matricula,
        'datainsert' => $datainsert->format('Y-m-d H:i:s'),
        'cnpj' => $cnpj,
        'statusPlanoNegocio' => 2,

        'analisePlanoGoverno' => $analisePlanoGoverno,
        'analiseNoticiasGoverno' => $analiseNoticiasGoverno,

        'folhaRadio' => $folhaRadio,
        'justificativaFolha' => $justificativaFolha,

        'cppRadio' => $cppRadio,
        'justificativaCPP' => $justificativaCPP,
        'qtdCPP' =>$qtdCPP,
    
        //Arrecadação
        'arrecadacaoRadio' => $arrecadacaoRadio,
        'justificativaArrecadacao' => $justificativaArrecadacao,
    
        //Cobrança
        'cobrancaRadio' => $cobrancaRadio,
        'justificativaCobranca' => $justificativaCobranca,
    
        //Pagamento a Fornecedor
        'pagFornRadio' => $pagFornRadio,
        'justificativapagForn' => $justificativapagForn,
    
        //CONSIGNADO
        'sgrRadio' => $sgrRadio,
        'justificativaSGR' => $justificativaSGR,
    
        //Esteira
        'financEsteiraRadio' => $financEsteiraRadio,
        'justificativaFinancEsteira' => $justificativaFinancEsteira,
    
        // OBRAS PARALIZADAS Financ
        'financObraParalRadio' => $financObraParalRadio,
        'justificativaFinancObraParal' => $justificativaFinancObraParal,
    
        // OBRAS PARALIZADAS OGU
        'oguObrasParalRadio' => $oguObrasParalRadio,
        'justificativaOguObrasParal' => $justificativaOguObrasParal,
    
        // Fundos de investimento e CDB
        'fiCDBRadio' => $fiCDBRadio,
        'justificativafiCDB' => $justificativafiCDB,
    
        // FAF
        'fafRadio' => $fafRadio,
        'justificativaFaf' => $justificativaFaf,
    
        // FUNDEB
        'fundebRadio' => $fundebRadio,
        'justificativaFundeb' => $justificativaFundeb,
    
        // QUOTA
        'quotaRadio' => $quotaRadio,
        'justificativaQuota' => $justificativaQuota,
    
        // Transferências Especiais
        'tranfEspecRadio' => $tranfEspecRadio,
        'justificativaTranfEspec' => $justificativaTranfEspec,
    
        // Selo
        'seloRadio' => $seloRadio,
        'justificativaSelo' => $justificativaSelo,
    
        // Programas Regionais de Benefício Social
        'benefSocialRadio' => $benefSocialRadio,
        'justificativaBenefSocial' => $justificativaBenefSocial,
    
        // Ação de Normalização 
        'acaoNormRadio' => $acaoNormRadio,
        'justificativaAcaoNorm' => $justificativaAcaoNorm
    ]; 

//echo json_encode(['status' => 'error', 'message' => 'Todos os campos são obrigatórios.', 'campos'=> json_encode($data)]);

// Valide os campos (opcional, já que a validação é feita no frontend) 
// if (!$matricula || !$cnpj || !$analisePlanoGoverno || !$selectQtdParticCaixa || !$selectQtdExterno || !$matricula) {
//     echo json_encode(['status' => 'error', 'message' => 'Todos os campos são obrigatórios.', 'campos'=> json_encode($data)]);
//     exit;
// }

// // Chame a função da DAO para inserir os dados no banco de dados 

 $result = $dao->salvarRascunho($data);

echo json_encode(['sql' => $result]); 

// if ($result) {
//     echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']); 
// } else {
//     echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']); 
// } 








