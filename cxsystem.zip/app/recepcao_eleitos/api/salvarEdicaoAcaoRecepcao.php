<?php
  require_once(__DIR__ .'/../daos/acoesDao.php');
  $dao = new acoesDAO();


// Verifique se os parâmetros foram enviados via POST e atribua-os a variáveis 
$dataAcao = isset($_POST['dataAcaoEdit']) ? $_POST['dataAcaoEdit'] : null; 
$txtAcaoDescricao = isset($_POST['txtAcaoDescricaoEdit']) ? $_POST['txtAcaoDescricaoEdit'] : null;
$txtLinkArquivo1 = isset($_POST['txtLinkArquivo1Edit']) ? $_POST['txtLinkArquivo1Edit'] : null;
$txtLinkArquivo2 = isset($_POST['txtLinkArquivo2Edit']) ? $_POST['txtLinkArquivo2Edit'] : null; 
$selectAcao = isset($_POST['idAcaoEdit']) ? $_POST['idAcaoEdit'] : null; 
$selectQtdParticCaixa = isset($_POST['selectQtdParticCaixaEdit']) ? $_POST['selectQtdParticCaixaEdit'] : null; 
$selectQtdExterno = isset($_POST['selectQtdExternoEdit']) ? $_POST['selectQtdExternoEdit'] : null; 
$matricula = isset($_POST['matriculaEdit']) ? $_POST['matriculaEdit'] : null;
$cnpj = isset($_POST['cnpjEdit']) ? $_POST['cnpjEdit'] : null;
$revisao = isset($_POST['revisao']) ? $_POST['revisao'] : null;

$date = str_replace('/', '-', $dataAcao);
$dataAcaoInformada = date('Y-m-d', strtotime($date));

//$dataAcaoInformada = new Date($dataAcao);
$datainsert = new Datetime();
// Crie um array com os dados
$data = [
    'dataAcao' => $dataAcaoInformada,
    'txtAcaoDescricao' => $txtAcaoDescricao,
    'txtLinkArquivo1' => $txtLinkArquivo1,
    'txtLinkArquivo2' => $txtLinkArquivo2,
    'idAcaoObrigatoria' => $selectAcao,
    'selectQtdParticCaixa' => $selectQtdParticCaixa,
    'selectQtdExterno' => $selectQtdExterno,
    'matricula' => $matricula,
    'datainsert' => $datainsert->format('Y-m-d H:i'),
    'cnpj' => $cnpj,
    'revisao' => $revisao
];

// Valide os campos (opcional, já que a validação é feita no frontend) 
if (!$dataAcao || !$txtAcaoDescricao || !$selectAcao || !$selectQtdParticCaixa || !$selectQtdExterno || !$matricula) {
    echo json_encode(['status' => 'error', 'message' => 'Todos os campos são obrigatórios.', 'campos'=> json_encode($data)]);
    exit;
}

// Chame a função da DAO para inserir os dados no banco de dados 
$result = $dao->inserirAcao($data);

//echo json_encode(['sql' => $result]); 

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']); 
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']); 
} 






