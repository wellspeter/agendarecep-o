<?php

require_once(__DIR__ . '/../../eventos/daos/municipiosEventoDao.php');

$dao = new municipiosEventoDao();

// Recebe os dados do formulário
// Contato 1
$cpfCont1_masc = isset($_POST['cpfCont1_masc']) ? $_POST['cpfCont1_masc'] : null;

// Matrícula, CNPJ e idEvento
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$cnpj = isset($_POST['municipio']) ? $_POST['municipio'] : null;
$idEvento = isset($_POST['idEvento']) ? $_POST['idEvento'] : null;
$tipocontato = isset($_POST['tipocontato']) ? $_POST['tipocontato'] : null;
$datainsert = new DateTime();

$actionType =  isset($_POST['actionType']) ? $_POST['actionType'] : null;

if($actionType === 'register'){

    $nomeCont1_masc = isset($_POST['nomeCont1_masc']) ? $_POST['nomeCont1_masc'] : null;
    $cpfCont1_masc = isset($_POST['cpfCont1_masc']) ? $_POST['cpfCont1_masc'] : null;
    $celularCont1_masc = isset($_POST['celularCont1_masc']) ? $_POST['celularCont1_masc'] : null;
    $emailCont1_masc = isset($_POST['emailCont1_masc']) ? $_POST['emailCont1_masc'] : null;

    $cargoCont1_masc = isset($_POST['cargoCont1_masc']) ? $_POST['cargoCont1_masc'] : null;
    $orgaoVinculadoCont1_masc = isset($_POST['orgaoVinculadoCont1_masc']) ? $_POST['orgaoVinculadoCont1_masc'] : null;

    $data = [
        'nomeCont1' => strtoupper($nomeCont1_masc),
        'cpfCont1' =>  $cpfCont1_masc,
        'celularCont1' => $celularCont1_masc,
        'emailCont1' => strtoupper( $emailCont1_masc),

        'cargoCont1' => strtoupper( $cargoCont1_masc),
        'orgaoVinculadoCont1' => strtoupper( $orgaoVinculadoCont1_masc),
    
        'matricula' => $matricula,
        'datainsert' => $datainsert->format('Y-m-d H:i:s'),
        'cnpj' => $cnpj,
        'NU_EVENTO' => $idEvento
    ];

    $result = $dao->inserirContatosMunicipioNoEvento($data);
    
}else{

    // Criação do array com os dados
    $data = [
        'cpf' => $cpfCont1_masc,
        'matricula_confirmacao_insert' => $matricula,
        'dt_confirmacao' => $datainsert->format('Y-m-d H:i:s'),
        'idEvento' => $idEvento,
        'tipocontato' => $tipocontato
    ];

    // Updade pessoa no evento
    $result = $dao->confirmarPresencaEvento($data);

}

// echo json_encode($data);

// echo $result;
// Retorno de sucesso ou erro
if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']);
}








