<?php
  
require_once(__DIR__ .'/../daos/acoesDao.php');

$dao = new acoesDAO();

// Função para verificar e decidir qual valor salvar
function verificarCampo($original, $mascarado) {
    return ($original === null || strpos($mascarado, '*') !== false) ? ($original !== null ? $original : null) : $mascarado;
}

// Recebe os dados do formulário
$dataAcao = isset($_POST['dataAcaoADD']) ? $_POST['dataAcaoADD'] : null;

// Contato 1
$nomeCont1 = isset($_POST['nomeCont1']) ? $_POST['nomeCont1'] : null;
$cargoCont1 = isset($_POST['cargoCont1']) ? $_POST['cargoCont1'] : null;
$celularCont1 = isset($_POST['celularCont1']) ? $_POST['celularCont1'] : null;
$emailCont1 = isset($_POST['emailCont1']) ? $_POST['emailCont1'] : null;

$nomeCont1_masc = isset($_POST['nomeCont1_masc']) ? $_POST['nomeCont1_masc'] : null;
$cargoCont1_masc = isset($_POST['cargoCont1_masc']) ? $_POST['cargoCont1_masc'] : null;
$celularCont1_masc = isset($_POST['celularCont1_masc']) ? $_POST['celularCont1_masc'] : null;
$emailCont1_masc = isset($_POST['emailCont1_masc']) ? $_POST['emailCont1_masc'] : null;

// Contato 2
$nomeCont2 = isset($_POST['nomeCont2']) ? $_POST['nomeCont2'] : null;
$cargoCont2 = isset($_POST['cargoCont2']) ? $_POST['cargoCont2'] : null;
$celularCont2 = isset($_POST['celularCont2']) ? $_POST['celularCont2'] : null;
$emailCont2 = isset($_POST['emailCont2']) ? $_POST['emailCont2'] : null;

$nomeCont2_masc = isset($_POST['nomeCont2_masc']) ? $_POST['nomeCont2_masc'] : null;
$cargoCont2_masc = isset($_POST['cargoCont2_masc']) ? $_POST['cargoCont2_masc'] : null;
$celularCont2_masc = isset($_POST['celularCont2_masc']) ? $_POST['celularCont2_masc'] : null;
$emailCont2_masc = isset($_POST['emailCont2_masc']) ? $_POST['emailCont2_masc'] : null;

// Contato 3
$nomeCont3 = isset($_POST['nomeCont3']) ? $_POST['nomeCont3'] : null;
$cargoCont3 = isset($_POST['cargoCont3']) ? $_POST['cargoCont3'] : null;
$celularCont3 = isset($_POST['celularCont3']) ? $_POST['celularCont3'] : null;
$emailCont3 = isset($_POST['emailCont3']) ? $_POST['emailCont3'] : null;

$nomeCont3_masc = isset($_POST['nomeCont3_masc']) ? $_POST['nomeCont3_masc'] : null;
$cargoCont3_masc = isset($_POST['cargoCont3_masc']) ? $_POST['cargoCont3_masc'] : null;
$celularCont3_masc = isset($_POST['celularCont3_masc']) ? $_POST['celularCont3_masc'] : null;
$emailCont3_masc = isset($_POST['emailCont3_masc']) ? $_POST['emailCont3_masc'] : null;

// Contato 4
$nomeCont4 = isset($_POST['nomeCont4']) ? $_POST['nomeCont4'] : null;
$cargoCont4 = isset($_POST['cargoCont4']) ? $_POST['cargoCont4'] : null;
$celularCont4 = isset($_POST['celularCont4']) ? $_POST['celularCont4'] : null;
$emailCont4 = isset($_POST['emailCont4']) ? $_POST['emailCont4'] : null;

$nomeCont4_masc = isset($_POST['nomeCont4_masc']) ? $_POST['nomeCont4_masc'] : null;
$cargoCont4_masc = isset($_POST['cargoCont4_masc']) ? $_POST['cargoCont4_masc'] : null;
$celularCont4_masc = isset($_POST['celularCont4_masc']) ? $_POST['celularCont4_masc'] : null;
$emailCont4_masc = isset($_POST['emailCont4_masc']) ? $_POST['emailCont4_masc'] : null;

// Contato 5
$nomeCont5 = isset($_POST['nomeCont5']) ? $_POST['nomeCont5'] : null;
$cargoCont5 = isset($_POST['cargoCont5']) ? $_POST['cargoCont5'] : null;
$celularCont5 = isset($_POST['celularCont5']) ? $_POST['celularCont5'] : null;
$emailCont5 = isset($_POST['emailCont5']) ? $_POST['emailCont5'] : null;

$nomeCont5_masc = isset($_POST['nomeCont5_masc']) ? $_POST['nomeCont5_masc'] : null;
$cargoCont5_masc = isset($_POST['cargoCont5_masc']) ? $_POST['cargoCont5_masc'] : null;
$celularCont5_masc = isset($_POST['celularCont5_masc']) ? $_POST['celularCont5_masc'] : null;
$emailCont5_masc = isset($_POST['emailCont5_masc']) ? $_POST['emailCont5_masc'] : null;

// Verificação e salvamento dos valores mascarados ou alterados
$nomeCont1_salvar = verificarCampo($nomeCont1, $nomeCont1_masc);
$cargoCont1_salvar = verificarCampo($cargoCont1, $cargoCont1_masc);
$celularCont1_salvar = verificarCampo($celularCont1, $celularCont1_masc);
$emailCont1_salvar = verificarCampo($emailCont1, $emailCont1_masc);

$nomeCont2_salvar = verificarCampo($nomeCont2, $nomeCont2_masc);
$cargoCont2_salvar = verificarCampo($cargoCont2, $cargoCont2_masc);
$celularCont2_salvar = verificarCampo($celularCont2, $celularCont2_masc);
$emailCont2_salvar = verificarCampo($emailCont2, $emailCont2_masc);

$nomeCont3_salvar = verificarCampo($nomeCont3, $nomeCont3_masc);
$cargoCont3_salvar = verificarCampo($cargoCont3, $cargoCont3_masc);
$celularCont3_salvar = verificarCampo($celularCont3, $celularCont3_masc);
$emailCont3_salvar = verificarCampo($emailCont3, $emailCont3_masc);

$nomeCont4_salvar = verificarCampo($nomeCont4, $nomeCont4_masc);
$cargoCont4_salvar = verificarCampo($cargoCont4, $cargoCont4_masc);
$celularCont4_salvar = verificarCampo($celularCont4, $celularCont4_masc);
$emailCont4_salvar = verificarCampo($emailCont4, $emailCont4_masc);

$nomeCont5_salvar = verificarCampo($nomeCont5, $nomeCont5_masc);
$cargoCont5_salvar = verificarCampo($cargoCont5, $cargoCont5_masc);
$celularCont5_salvar = verificarCampo($celularCont5, $celularCont5_masc);
$emailCont5_salvar = verificarCampo($emailCont5, $emailCont5_masc);

// Matricula, CNPJ e data
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
$date = str_replace('/', '-', $dataAcao);
$dataAcaoInformada = date('Y-m-d', strtotime($date));
$datainsert = new Datetime();

// Criação do array com os dados
$data = [
    'nomeCont1' =>strtoupper($nomeCont1_salvar),
    'cargoCont1' => strtoupper($cargoCont1_salvar),
    'celularCont1' => $celularCont1_salvar,
    'emailCont1' => strtoupper($emailCont1_salvar),

    'nomeCont2' => strtoupper($nomeCont2_salvar),
    'cargoCont2' => strtoupper($cargoCont2_salvar),
    'celularCont2' => $celularCont2_salvar,
    'emailCont2' => strtoupper($emailCont2_salvar),

    'nomeCont3' => strtoupper($nomeCont3_salvar),
    'cargoCont3' => strtoupper($cargoCont3_salvar),
    'celularCont3' => $celularCont3_salvar,
    'emailCont3' => strtoupper($emailCont3_salvar),

    'nomeCont4' => strtoupper($nomeCont4_salvar),
    'cargoCont4' => strtoupper($cargoCont4_salvar),
    'celularCont4' => $celularCont4_salvar,
    'emailCont4' => strtoupper($emailCont4_salvar),

    'nomeCont5' => strtoupper($nomeCont5_salvar),
    'cargoCont5' => strtoupper($cargoCont5_salvar),
    'celularCont5' => $celularCont5_salvar,
    'emailCont5' => strtoupper($emailCont5_salvar),

    'matricula' => $matricula,
    'datainsert' => $datainsert->format('Y-m-d H:i:s'),
    'cnpj' => $cnpj
];

// Chamada da função DAO para inserir os dados
$result = $dao->inserirContatosMunicipio($data);

// Retorno de sucesso ou erro
if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']);
}









