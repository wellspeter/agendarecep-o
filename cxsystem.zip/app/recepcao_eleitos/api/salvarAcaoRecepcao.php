<?php
  require_once(__DIR__ .'/../daos/acoesDao.php');
  $dao = new acoesDAO();


// Verifique se os parâmetros foram enviados via POST e atribua-os a variáveis 
$dataAcao = isset($_POST['dataAcaoADD']) ? $_POST['dataAcaoADD'] : null; 
$txtAcaoDescricao = isset($_POST['txtAcaoDescricaoADD']) ? $_POST['txtAcaoDescricaoADD'] : null;
$txtLinkArquivo1 = isset($_POST['txtLinkArquivo1ADD']) ? $_POST['txtLinkArquivo1ADD'] : null;
$txtLinkArquivo2 = isset($_POST['txtLinkArquivo2ADD']) ? $_POST['txtLinkArquivo2ADD'] : null; 
$selectAcao = isset($_POST['selectAcaoADD']) ? $_POST['selectAcaoADD'] : null; 
$selectQtdParticCaixa = isset($_POST['selectQtdParticCaixaADD']) ? $_POST['selectQtdParticCaixaADD'] : null; 
$selectQtdExterno = isset($_POST['selectQtdExternoADD']) ? $_POST['selectQtdExternoADD'] : null; 
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$cnpj = isset($_POST['cnpj']) ? $_POST['cnpj'] : null;
$revisao = isset($_POST['revisao']) ? $_POST['revisao'] : null;

$date = str_replace('/', '-', $dataAcao);
$dataAcaoInformada = date('Y-m-d', strtotime($date));
$datainsert = new Datetime();
// Crie um array com os dados
$data = [
    'dataAcao' => $dataAcaoInformada,
    'txtAcaoDescricao' => $txtAcaoDescricao,
    'txtLinkArquivo1' => $txtLinkArquivo1,
    'txtLinkArquivo2' => $txtLinkArquivo2,
    'idAcaoObrigatoria' => $selectAcao,
    'selectQtdParticCaixa' => $selectQtdParticCaixa,
    'selectQtdExterno' => $selectQtdExterno,
    'matricula' => $matricula,
    'datainsert' => $datainsert->format('Y-m-d H:i:s'),
    'cnpj' => $cnpj,
    'revisao' => $revisao
];



// Valide os campos (opcional, já que a validação é feita no frontend) 
if (!$dataAcao || !$txtAcaoDescricao || !$selectAcao || !$selectQtdParticCaixa || !$selectQtdExterno || !$matricula) {
    echo json_encode(['status' => 'error', 'message' => 'Todos os campos são obrigatórios.', 'campos'=> json_encode($data)]);
    exit;
}

// Chame a função da DAO para inserir os dados no banco de dados 

$result = $dao->inserirAcao($data);

echo json_encode(['sql' => $result]); 

// if ($result) {
//     echo json_encode(['status' => 'success', 'message' => 'Dados salvos com sucesso!']); 
// } else {
//     echo json_encode(['status' => 'error', 'message' => 'Erro ao salvar os dados.']); 
// } 








