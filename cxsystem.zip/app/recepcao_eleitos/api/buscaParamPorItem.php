<?php
require_once(__DIR__ . '/../controllers/metasOrcamentoController.php');


//$nu_item = filter_input(INPUT_POST, 'nu_item');

$ctx = buscarParamPorItem();

echo json_encode($ctx);
