<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];
//echo $dadosUsuario['nu_lotacao_fisica'];

$cnpjMunicipio = CxRequest::params('municip');
//$cnpjMunicipio = '18338178000102';
//echo $cnpjMunicipio;

require_once(__DIR__ . '/../daos/acoesDao.php');
$dao = new acoesDAO();

$listaAcoes = $dao->buscaListAcoes();
$dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
$dadosCliente = $dao->buscaDadosCliente($cnpjMunicipio);
$acoesCliente = $dao->buscaAcoesCliente($cnpjMunicipio);
$acoesClienteAgenda = $dao->buscaAcoesClienteAgenda($cnpjMunicipio);
$contatosCliente = $dao->getContatosMinicipios($cnpjMunicipio);

//echo var_dump($acoesCliente);
function verificarStatusItem($dt_realizacao_acao, $dt_inicio_acao, $dt_fim_acao)
{
  $hoje = date('Y-m-d'); // Data de hoje

  if (!is_null($dt_realizacao_acao)) {
    // O item foi realizado
    if ($dt_realizacao_acao >= $dt_inicio_acao && $dt_realizacao_acao <= $dt_fim_acao) {
      return 'Realizada';
    } elseif ($dt_realizacao_acao < $dt_inicio_acao) {
      return 'Realizado Antes do Prazo';
    } else { // $dt_realizacao_acao > $dt_fim_acao
      return 'Realizado Depois do Prazo';
    }
  } else {
    // O item não foi realizado
    if ($hoje < $dt_inicio_acao) {
      return 'Fora do Período para Iniciar';
    } elseif ($hoje >= $dt_inicio_acao && $hoje <= $dt_fim_acao) {
      return 'Dentro do Prazo para Realização';
    } else { // $hoje > $dt_fim_acao
      return 'Ação Atrasada';
    }
  }
}

function verificarStatusIconeItem($dt_realizacao_acao, $dt_inicio_acao, $dt_fim_acao)
{
  $hoje = date('Y-m-d'); // Data de hoje

  if (!is_null($dt_realizacao_acao)) {
    // O item foi realizado
    if ($dt_realizacao_acao >= $dt_inicio_acao && $dt_realizacao_acao <= $dt_fim_acao) {
      return 'timeline-icon-success';
    } elseif ($dt_realizacao_acao < $dt_inicio_acao) {
      return 'timeline-icon-success';
    } else { // $dt_realizacao_acao > $dt_fim_acao
      return ' timeline-icon-success';
    }
  } else {
    // O item não foi realizado
    if ($hoje < $dt_inicio_acao) {
      return 'timeline-icon-primary';
    } elseif ($hoje >= $dt_inicio_acao && $hoje <= $dt_fim_acao) {
      return 'timeline-icon-warning';
    } else { // $hoje > $dt_fim_acao
      return 'timeline-icon-danger';
    }
  }
}
function formatarPeriodo($dt_inicio_acao, $dt_fim_acao)
{
  setlocale(LC_TIME, 'pt_BR.UTF-8');
  // Converte as datas para o formato de timestamp
  $inicio = strtotime($dt_inicio_acao);
  $fim = strtotime($dt_fim_acao);

  // Obtém o mês e o ano das datas
  $mesInicio = utf8_encode(strftime('%B', $inicio)); // Nome completo do mês de início
  $anoInicio = utf8_encode(strftime('%Y', $inicio)); // Ano de início
  $mesFim = utf8_encode(strftime('%B', $fim));       // Nome completo do mês de fim
  $anoFim = utf8_encode(strftime('%Y', $fim));       // Ano de fim

  // Verifica se as datas estão no mesmo mês e ano
  if ($mesInicio === $mesFim && $anoInicio === $anoFim) {
    return "$mesInicio de $anoInicio";
  }
  // Verifica se as datas estão em meses diferentes, mas no mesmo ano
  elseif ($anoInicio === $anoFim) {
    return "$mesInicio à $mesFim de $anoInicio";
  }
  // Se estão em meses e anos diferentes
  else {
    return "$mesInicio de $anoInicio à $mesFim de $anoFim";
  }
}

function js_array($array)
{
  $temp = array_map('js_str', $array);
  return '[' . implode(',', $temp) . ']';
}


?>

<style>
  .linha-baixo {
    border-bottom-style: groove;
    border-bottom-color: #dbdbdb;
    border-bottom-width: 1px;
  }

  .list-group-item-background {
    background: none;

  }

  .list-item-name {
    margin-left: -25px
  }
</style>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class=""></small>Ações da Recepção do Cliente</small> <?php echo $dadosCliente[0]['NOME_MUNICIPIO'] ?>, <?php echo $dadosCliente[0]['sg_uf'] ?></h4>
    </div>
  </div>
  <div class="row">
    <div class="col-6">
      <div class="card">
        <div class="card-header border-bottom d-flex justify-content-between align-items-center">
          <h5 class="card-title"><span class="align-middle">Ações Recepção</span></h5>
          <div class="align-middle">
            <button type="button" class="btn btn-icon btn-primary" data-toggle="modal" data-target="#adicionarContadosModal">
              <i class="bx bxs-user-plus"></i>
              Adicionar Contato
            </button>

            <button type="button" class="btn btn-icon rounded-circle btn-primary" data-toggle="modal" data-target="#adicionarAcoesModal" onclick="popularParametrosModalADD(1);">
              <i class="bx bx-plus"></i>

            </button>
          </div>

        </div>
        <div class="card-body ">
          <div class="">
            <ul class="timeline mb-0 mt-1">
              <?php
              foreach ($acoesCliente as $acoes) {
                if ($acoes['NU_GRUPO'] == 1) {
                  echo '<li class="timeline-item ' . verificarStatusIconeItem($acoes['DT_DA_ACAO'], $acoes['DT_INICIO_ACAO'], $acoes['DT_FIM_ACAO']) . ' pb-0 mb-0 linha-baixo" style="margin-top: -10px">';
                  //verificando se foi realizado ou não               
                  echo '<div class="timeline-time" style="margin-top: 11px;">' . verificarStatusItem($acoes['DT_DA_ACAO'], $acoes['DT_INICIO_ACAO'], $acoes['DT_FIM_ACAO'])  . '</div>';
                  echo '<h6 class="timeline-title" >';
                  if (!is_null($acoes['DT_DA_ACAO'])) {
                    echo '<a href="" data-toggle="modal" onclick="popularParametrosModal(' . $acoes['ID_REALIZADO_ACOES'] . ',1);"  data-target="#editarAcoesModal">';
                    echo $acoes['NO_ACOES'];
                    echo '</a>';
                  } else {
                    echo '<span class="text-muted" >'.$acoes['NO_ACOES'].'</span>';
                  }
                  
                  // 1.	Aguardando Revisão ( Aguardando a revisão do SEG )
                  // 2.	Em Análise ( Revisão ) value 0
                  // 3.	Acatado ( pontuado ) value 1
                  // 4.	Não Acatado ( não pontuado ) value 2
                  // if($acoes['ID_ACOES'] == 5){
                  //   if (!is_null($acoes['DT_DA_ACAO'])) {
                  //     if (is_null($acoes['ACAO_VALIDADA'])) {
                  //       echo '<div class="badge badge-danger d-inline-flex align-items-center ml-2"><span>Período de Revisão Finalizada </span></div>';
                  //     } elseif($acoes['ACAO_VALIDADA'] == 0){
                  //       echo '<div class="badge badge-secondary d-inline-flex align-items-center ml-1"><span>Em Análise</span></div>';
                  //     } elseif($acoes['ACAO_VALIDADA'] == 1){
                  //       echo '<div class="badge badge-success d-inline-flex align-items-center ml-1"><span>revisão: Pontuado</span></div>';
                  //     } elseif($acoes['ACAO_VALIDADA'] == 2){
                  //       echo '<div class="badge badge-secondary d-inline-flex align-items-center ml-1"><span>revisão: Não Pontuado</span></div>';
                  //     }
                  //   }
                  // }

                  if($acoes['ID_ACOES'] == 5 || $acoes['ID_ACOES'] == 14 || $acoes['ID_ACOES'] == 18 ){
                    if (!is_null($acoes['DT_DA_ACAO'])) {
                      if (is_null($acoes['ACAO_VALIDADA'])) {
                        echo '<div class="badge badge-warning d-inline-flex align-items-center ml-2"><span>Aguardando Revisão</span></div>';
                      } elseif($acoes['ACAO_VALIDADA'] == 0){
                        echo '<div class="badge badge-secondary d-inline-flex align-items-center ml-1"><span>Em Análise</span></div>';
                      } elseif($acoes['ACAO_VALIDADA'] == 1){
                        echo '<div class="badge badge-success d-inline-flex align-items-center ml-1"><span>revisão: Pontuado</span></div>';
                      } elseif($acoes['ACAO_VALIDADA'] == 2){
                        echo '<div class="badge badge-secondary d-inline-flex align-items-center ml-1"><span>revisão: Não Pontuado</span></div>';
                      }
                    }
                    
                   // if (CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '116313') {
                      echo '<button type="button" class="btn btn-primary badge badge-primary ml-1" data-toggle="tooltip" data-placement="top" title="'.$acoes['ACAO_VALIDADA_JUST'].'">';
                      echo 'Resultado da análise'; 
                      echo '</button>';
                   // }
                  }

                  
                  echo '</h6>';
                  if (CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '116313') {
                    //echo ''.verificarValidacaoAcao($acoes['ACAO_VALIDADA']).'';
                  }
                 
                  echo '<p class="timeline-text" style="margin-top: -5px;">' . formatarPeriodo($acoes['DT_INICIO_ACAO'], $acoes['DT_FIM_ACAO']) . '</p>';
                  echo '</li>';
                }
              }
              ?>
            </ul>
          </div>
        </div>
      </div>

    </div>
    <div class="col-6">
      <div class="card">
        <div class="card-header border-bottom d-flex justify-content-between align-items-center">
          <h5 class="card-title"><span class="align-middle">Agendas Gov</span></h5>
          <button type="button" class="btn btn-icon rounded-circle btn-success" data-toggle="modal" data-target="#adicionarAcoesModal" onclick="popularParametrosModalADD(2);">
            <i class="bx bx-plus"></i>
          </button>
        </div>
        <div class="card-body ">
          <div class=" mb-2 mt-2">
            <ul class="timeline mb-0" style="margin-top: -20px;">
              <?php
              foreach ($acoesClienteAgenda as $acoes) {
                if ($acoes['NU_GRUPO'] == 3) {
                  echo '<li class="  pb-0 mb-0 linha-baixo" style="margin-top: -10px">';
                  //verificando se foi realizado ou não               
                  echo '<div class="timeline-time" style="margin-top: 11px;"></div>';
                  echo '<h6 class="timeline-title" >';
                  //echo $acoes['NO_ACOES'];
                  // if (!is_null($acoes['DT_DA_ACAO'])) {
                  echo '<a href="" onclick="popularParametrosModal(' . $acoes['ID_REALIZADO_ACOES'] . ',2);" data-toggle="modal" data-target="#editarAcoesModal">';
                  echo $acoes['NO_ACOES'];
                  echo '</a>';
                  // } else {

                  // }
                  echo '</h6>';
                  echo '<p class="timeline-text" style="margin-top: -5px;">Realizado em: 05 de Janeiro</p>';
                  echo '</li>';
                }
              }
              ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->

  <div class="modal fade " id="editarAcoesModal" tabindex="-1" role="dialog" aria-labelledby="editarAcoesModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="form-edicao-acao" method="post" action="javascript:void(0)">
          <div class="modal-header border-bottom">
            <h5 class="modal-title" id="tituloAcaoEditar">Edição da Ação - Parabenização</h5>
            <input type="hidden" id="cnpjEdit" name="cnpjEdit" value="<? echo   $cnpjMunicipio  ?>">
            <input type="hidden" id="matriculaEdit" name="matriculaEdit" value="<? echo   $matricula  ?>">
            <input type="hidden" id="idAcaoEdit" name="idAcaoEdit">
            <input type="hidden" id="tipoModal" name="tipoModal">
            <input type="hidden" id="revisao" name="revisao" value="0">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="bx bx-x"></i>
            </button>
          </div>

          <div class="modal-body" style="padding:0px; margin-top:10px">
            <!-- <form action="#" class=""> -->
            <div class="row">
              <div class="col-5 ml-2">
                <div class="form-group">
                  <label>Data da realização da ação *</label>
                  <fieldset class="form-group position-relative has-icon-left">
                    <input type="text" class="form-control pickadate-data-hoje" id="dataAcaoEdit" name="dataAcaoEdit">
                    <div class="form-control-position">
                      <i class='bx bx-calendar-check'></i>
                    </div>
                  </fieldset>
                </div>
              </div>
              <div class="col-sm-3 ml-2">
                <div class="form-group">
                  <label>Participantes CAIXA *</label>
                  <select class="form-control" id="selectQtdParticCaixaEdit" name="selectQtdParticCaixaEdit">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group">
                  <label>Participantes Externos *</label>
                  <select class="form-control" id="selectQtdExternoEdit" name="selectQtdExternoEdit">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12 ml-2 mr-4">
                <fieldset class="form-group">
                  <label>Informe toda interação ocorrida *</label>
                  <textarea class="form-control" style="width:95%" id="txtAcaoDescricaoEdit" name="txtAcaoDescricaoEdit" rows="5" placeholder=""></textarea>
                </fieldset>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-12 ml-2 mr-6">
                <label class="mb-2">A imagem referente a Ação, deve ser armazenada no SharePoint <a target="_blank" href="https://caixa.sharepoint.com/sites/Arquivos5131/Recepo%20aos%20Eleitos%20%20Eleies%202024/Forms/AllItems.aspx">(AQUI)</a>, após isso, deve copiar o link do arquivo e colar no campo a baixo. *</label>
                <div class="row ">
                  <div class="col-md-11 col-1 form-group d-flex align-items-center">
                    <input type="text" class="form-control" id="txtLinkArquivo1Edit" name="txtLinkArquivo1Edit" placeholder="Link">
                  </div>
                  <div class="col-md-11 col-1 form-group d-flex align-items-center">
                    <input type="text" class="form-control" id="txtLinkArquivo2Edit" name="txtLinkArquivo2Edit" placeholder="Link">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
              <i class="bx bx-x d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Cancelar</span>
            </button>
            <button type="button" class="btn btn-primary ml-1" id="submitEdit" name="submitEdit" value="submitEdit">
              <i class="bx bx-check d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Salvar Edição</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- 
------------------------------------ MODAL ADD AÇÃO RECEPÇÃO ---------------------------------------------------
-->
  <div class="modal fade " id="adicionarAcoesModal" tabindex="-1" role="dialog" aria-labelledby="adicionarAcoesModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="form-cadastro-acao" method="post" action="javascript:void(0)">
          <input type="hidden" id="cnpj" name="cnpj" value="<? echo   $cnpjMunicipio  ?>">
          <input type="hidden" id="matricula" name="matricula" value="<? echo   $matricula  ?>">
          <input type="hidden" id="tipoModal" name="tipoModal">
          <input type="hidden" id="revisao" name="revisao" value="0">
          <div class="modal-header border-bottom">
            <h5 class="modal-title" id="tituloAcaoADD">Adicionar Ação</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="bx bx-x"></i>
            </button>
          </div>

          <div class="modal-body" style="padding:0px; margin-top:10px">
            <div class="row">
              <div class="col ml-2 mr-2">
                <div class="alert alert-danger " role="alert">
                  Ao informar essa ação, será considerada como realizada. <br>
                  NÃO INFORMAR A NÃO REALIZAÇÃO DESSA AÇÃO!
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-7 ml-2">
                <div class="form-group">
                  <label>Ação de Recepção *</label>
                  <select class=" form-control" id="selectAcaoADD" name="selectAcaoADD" data-dist="selectAcaoADD">
                    <option value="" disabled selected>Selecione a Ação</option>
                    <?php
                    // foreach ($acoesCliente as $acoes) {
                    //   if (is_null($acoes['DT_DA_ACAO'])) {
                    //     echo '<option value="' . $acoes['ID_ACOES'] . '">' . $acoes['NO_ACOES'] . '</option>';
                    //   }
                    // }
                    ?>
                  </select>
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>Data da Ação *</label>
                  <fieldset class="form-group position-relative has-icon-left">
                    <input type="text" class="form-control pickadate-data-hoje" id="dataAcaoADD" name="dataAcaoADD" placeholder="Informe a Data">

                    <div class="form-control-position">
                      <i class='bx bx-calendar-check'></i>
                    </div>
                  </fieldset>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-3  ml-2">
                <div class="form-group">
                  <label>Participantes CAIXA *</label>
                  <select class="form-control select2" id="selectQtdParticCaixaADD" name="selectQtdParticCaixaADD">
                    <option value="1" selected>1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>
                </div>
              </div>
              <div class="col-3">
                <div class="form-group">
                  <label>Participantes Externos *</label>
                  <select class="form-control select2" id="selectQtdExternoADD" name="selectQtdExternoADD">
                    <option value="1" selected>1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12 ml-2 mr-4">
                <fieldset class="form-group">
                  <label>Informe toda interação ocorrida *</label>
                  <textarea class="form-control" style="width:95%" id="txtAcaoDescricaoADD" name="txtAcaoDescricaoADD" rows="5" placeholder=""></textarea>
                </fieldset>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-12 ml-2 mr-6">
                <label class="mb-2">A imagem referente a Ação, deve ser armazenada no SharePoint <a target="_blank" href="https://caixa.sharepoint.com/sites/Arquivos5131/Recepo%20aos%20Eleitos%20%20Eleies%202024/Forms/AllItems.aspx">(AQUI)</a>, após isso, deve copiar o link do arquivo e colar no campo a baixo. *</label>
                <div class="row ">
                  <div class="col-md-11 col-1 form-group d-flex align-items-center">
                    <input type="text" class="form-control" id="txtLinkArquivo1ADD" name="txtLinkArquivo1ADD" placeholder="Link">
                  </div>
                  <div class="col-md-11 col-1 form-group d-flex align-items-center">
                    <input type="text" class="form-control" id="txtLinkArquivo2ADD" name="txtLinkArquivo2ADD" placeholder="Link">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
              <i class="bx bx-x d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Cancelar</span>
            </button>
            <button type="button" class="btn btn-primary ml-1" id="submiADD" value="SubmitADD">
              <i class="bx bx-check d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Salvar</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- 
------------------------------------ MODAL ADD CONTATOS MUNICIPIOS ---------------------------------------------------
-->


  <div class="modal fade " id="adicionarContadosModal" tabindex="-1" role="dialog" aria-labelledby="adicionarContadosModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="form-cadastro-contato" method="post" action="javascript:void(0)">
          <input type="hidden" id="cnpj" name="cnpj" value="<? echo   $cnpjMunicipio  ?>">
          <input type="hidden" id="matricula" name="matricula" value="<? echo   $matricula  ?>">
          <input type="hidden" id="tipoModal" name="tipoModal">
          <div class="modal-header border-bottom">
            <h5 class="modal-title" id="tituloAcaoADD">Adicionar Contatos do Município</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="bx bx-x"></i>
            </button>
          </div>

          <div class="modal-body" style="padding:0px; margin-top:10px">
            <div class="col">
              <div class="row">
                <div class="col-3 ">
                  <div class="form-group">
                    <label>Nome do Contato</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="nomeCont1_masc" name="nomeCont1_masc" placeholder="Prefeito(a)" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                            echo $contatosCliente[0]['nomeCont1'];
                                                                                                                                          } ?>">
                      <input type="hidden" id="nomeCont1" name="nomeCont1" value="<? if (count($contatosCliente) > 0) {
                                                                                    echo $contatosCliente[0]['nomeCont1'];
                                                                                  } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Cargo</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="cargoCont1_masc" name="cargoCont1_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['cargoCont1'];
                                                                                                                  } ?>">
                      <input type="hidden" id="cargoCont1" name="cargoCont1" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['cargoCont1'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-building-house'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>

                <div class="col-3">
                  <div class="form-group">
                    <label>Celular</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="celularCont1_masc" name="celularCont1_masc" maxlenght="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                                                                        echo $contatosCliente[0]['celularCont1'];
                                                                                                                                                                                                      } ?>">
                      <input type="hidden" id="celularCont1" name="celularCont1" value="<? if (count($contatosCliente) > 0) {
                                                                                          echo $contatosCliente[0]['celularCont1'];
                                                                                        } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-phone'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Email</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="emailCont1_masc" name="emailCont1_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['emailCont1'];
                                                                                                                  } ?>">
                      <input type="hidden" id="emailCont1" name="emailCont1" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['emailCont1'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>
                    </fieldset>
                  </div>
                </div>
              </div>
              <hr>
            </div>

            <div class="col">
              <div class="row">
                <div class="col-3 ">
                  <div class="form-group">
                    <label>Nome do Contato</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="nomeCont2_masc" name="nomeCont2_masc" placeholder="Vice Prefeito(a)" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                echo $contatosCliente[0]['nomeCont2'];
                                                                                                                                              } ?>">
                      <input type="hidden" id="nomeCont2" name="nomeCont2" value="<? if (count($contatosCliente) > 0) {
                                                                                    echo $contatosCliente[0]['nomeCont2'];
                                                                                  } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Cargo</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="cargoCont2_masc" name="cargoCont2_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['cargoCont2'];
                                                                                                                  } ?>">
                      <input type="hidden" id="cargoCont2" name="cargoCont2" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['cargoCont2'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-building-house'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>

                <div class="col-3">
                  <div class="form-group">
                    <label>Celular</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="celularCont2_masc" name="celularCont2_masc" maxlenght="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                                                                        echo $contatosCliente[0]['celularCont2'];
                                                                                                                                                                                                      } ?>">
                      <input type="hidden" id="celularCont2" name="celularCont2" value="<? if (count($contatosCliente) > 0) {
                                                                                          echo $contatosCliente[0]['celularCont2'];
                                                                                        } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-phone'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Email</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="emailCont2_masc" name="emailCont2_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['emailCont2'];
                                                                                                                  } ?>">
                      <input type="hidden" id="emailCont2" name="emailCont2" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['emailCont2'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>

                      </div>
                    </fieldset>
                  </div>
                </div>
              </div>
              <hr>
            </div>

            <div class="col">
              <div class="row">
                <div class="col-3 ">
                  <div class="form-group">
                    <label>Nome do Contato</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="nomeCont3_masc" name="nomeCont3_masc" placeholder="Outros" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                      echo $contatosCliente[0]['nomeCont3'];
                                                                                                                                    } ?>">
                      <input type="hidden" id="nomeCont3" name="nomeCont3" value="<? if (count($contatosCliente) > 0) {
                                                                                    echo $contatosCliente[0]['nomeCont3'];
                                                                                  } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Cargo</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="cargoCont3_masc" name="cargoCont3_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['cargoCont3'];
                                                                                                                  } ?>">
                      <input type="hidden" id="cargoCont3" name="cargoCont3" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['cargoCont3'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-building-house'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>

                <div class="col-3">
                  <div class="form-group">
                    <label>Celular</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="celularCont3_masc" name="celularCont3_masc" maxlenght="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                                                                        echo $contatosCliente[0]['celularCont3'];
                                                                                                                                                                                                      } ?>">
                      <input type="hidden" id="celularCont3" name="celularCont3" value="<? if (count($contatosCliente) > 0) {
                                                                                          echo $contatosCliente[0]['celularCont3'];
                                                                                        } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-phone'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Email</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="emailCont3_masc" name="emailCont3_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['emailCont3'];
                                                                                                                  } ?>">
                      <input type="hidden" id="emailCont3" name="emailCont3" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['emailCont3'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>

                      </div>
                    </fieldset>
                  </div>
                </div>
              </div>
              <hr>
            </div>

            <div class="col">
              <div class="row">
                <div class="col-3 ">
                  <div class="form-group">
                    <label>Nome do Contato</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="nomeCont4_masc" name="nomeCont4_masc" placeholder="Outros" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                      echo $contatosCliente[0]['nomeCont4'];
                                                                                                                                    } ?>">
                      <input type="hidden" id="nomeCont4" name="nomeCont4" value="<? if (count($contatosCliente) > 0) {
                                                                                    echo $contatosCliente[0]['nomeCont4'];
                                                                                  } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Cargo</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="cargoCont4_masc" name="cargoCont4_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['cargoCont4'];
                                                                                                                  } ?>">
                      <input type="hidden" id="cargoCont4" name="cargoCont4" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['cargoCont4'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-building-house'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>

                <div class="col-3">
                  <div class="form-group">
                    <label>Celular</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="celularCont4_masc" name="celularCont4_masc" maxlenght="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                                                                        echo $contatosCliente[0]['celularCont4'];
                                                                                                                                                                                                      } ?>">
                      <input type="hidden" id="celularCont4" name="celularCont4" value="<? if (count($contatosCliente) > 0) {
                                                                                          echo $contatosCliente[0]['celularCont4'];
                                                                                        } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-phone'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Email</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="emailCont1_masc" name="emailCont4_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['emailCont4'];
                                                                                                                  } ?>">
                      <input type="hidden" id="emailCont4" name="emailCont4" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['emailCont4'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>

                      </div>
                    </fieldset>
                  </div>
                </div>
              </div>
              <hr>
            </div>
            <div class="col">
              <div class="row">
                <div class="col-3 ">
                  <div class="form-group">
                    <label>Nome do Contato</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="nomeCont5" name="nomeCont5" placeholder="Outros" value="<? if (count($contatosCliente) > 0) {
                                                                                                                            echo $contatosCliente[0]['nomeCont5'];
                                                                                                                          } ?>">
                      <input type="hidden" id="nomeCont5" name="nomeCont5" value="<? if (count($contatosCliente) > 0) {
                                                                                    echo $contatosCliente[0]['nomeCont5'];
                                                                                  } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Cargo</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="cargoCont5_masc" name="cargoCont5_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['cargoCont5'];
                                                                                                                  } ?>">
                      <input type="hidden" id="cargoCont5" name="cargoCont5" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['cargoCont5'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-building-house'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>

                <div class="col-3">
                  <div class="form-group">
                    <label>Celular</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="celularCont5_masc" name="celularCont5_masc" maxlenght="11" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<? if (count($contatosCliente) > 0) {
                                                                                                                                                                                                        echo $contatosCliente[0]['celularCont5'];
                                                                                                                                                                                                      } ?>">
                      <input type="hidden" id="celularCont5" name="celularCont5" value="<? if (count($contatosCliente) > 0) {
                                                                                          echo $contatosCliente[0]['celularCont5'];
                                                                                        } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-phone'></i>
                      </div>

                    </fieldset>
                  </div>
                </div>
                <div class="col-3">
                  <div class="form-group">
                    <label>Email</label>
                    <fieldset class="form-group position-relative has-icon-left">
                      <input type="text" class="form-control" id="emailCont5_masc" name="emailCont5_masc" value="<? if (count($contatosCliente) > 0) {
                                                                                                                    echo $contatosCliente[0]['emailCont5'];
                                                                                                                  } ?>">
                      <input type="hidden" id="emailCont5" name="emailCont5" value="<? if (count($contatosCliente) > 0) {
                                                                                      echo $contatosCliente[0]['emailCont5'];
                                                                                    } ?>">
                      <div class="form-control-position">
                        <i class='bx bxs-user'></i>

                      </div>
                    </fieldset>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-light-secondary" data-dismiss="modal">
              <i class="bx bx-x d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Cancelar</span>
            </button>
            <button type="button" class="btn btn-primary ml-1" id="submiContatoADD" value="submiContatoADD">
              <i class="bx bx-check d-block d-sm-none"></i>
              <span class="d-none d-sm-block">Salvar</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-------------------------------------------------------------------------------------------------------------- 
----------------------------------------------- script ---------------------------------------------------------
---------------------------------------------------------------------------------------------------------------->

  <script>
    <? echo 'const acoes_banco_cliente = ' . json_encode($acoesCliente, JSON_UNESCAPED_UNICODE) . ';' ?>

    <? echo 'const acoes_complementar_banco_cliente = ' . json_encode($acoesClienteAgenda, JSON_UNESCAPED_UNICODE) . ';' ?>

    <? echo 'const acoes_lista = ' . json_encode($listaAcoes, JSON_UNESCAPED_UNICODE) . ';' ?>

    <?php echo "const identificacao_unidade = '" . $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] . "';"; ?>
    <?php echo "const nivel_acesso_editar = '" . $dadosArvoreAcesso[0]['NIVEL_ACESSO_EDITAR'] . "';"; ?>
    <?php echo "const nivel_acesso_consultar = '" . $dadosArvoreAcesso[0]['NIVEL_ACESSO_CONSULTAR'] . "';"; ?>

    function ajustarAcesso(nivel_acesso_editar, nivel_acesso_consultar) {
      if (nivel_acesso_consultar === "1") {
        // Seleciona todos os inputs e textareas e os torna somente leitura
        var elementos = document.querySelectorAll('input, textarea');
        elementos.forEach(function(elemento) {
          if (elemento.type === 'radio') {
            elemento.disabled = true; // Desabilita os radio buttons
          } else {
            elemento.readOnly = true; // Torna os demais elementos somente leitura
          }
        });

        // Oculta os botões com IDs 'submitRascunho' e 'submiContatoADD'
        var submiContatoADD = document.getElementById('submiContatoADD');
        var submiADD = document.getElementById('submiADD');
        var submitEdit = document.getElementById('submitEdit');

        if (submiContatoADD) submiContatoADD.style.display = 'none';
        if (submiADD) submiADD.style.display = 'none';
        if (submitEdit) submitEdit.style.display = 'none';
      }
    }

    $(document).ready(function($) {

     // $('[data-toggle="popover"]').popover();

      ajustarAcesso(nivel_acesso_editar, nivel_acesso_consultar);

      $('#selectAcaoADD').on('change', function() {

        const selectAcao = document.getElementById("selectAcaoADD");
        const idsToCheck = ["5", "14", "18"];
        let hideButton = false;

        acoes_lista.forEach((acoes) => {
          if (selectAcao.value == 5) {
            if (acoes.ID_ACOES == selectAcao.value) {
              const endDate = new Date(acoes.DT_FIM_ACAO + 'T23:59:59');
              const nowDate = new Date(); 
              if (endDate <= nowDate) {
                hideButton = true;
              }
            }
          }
        });

        const submitButton = document.getElementById("submiADD");
        // if (hideButton) {
        //   submitButton.style.display = "none";
        // } else {
        //   submitButton.style.display = "block";
        // }
      });


      //salvar edição da ação.
      $('#submitEdit').on('click', function() {
        let isValid = true;
        const dataAcao = document.getElementById("dataAcaoEdit");
        const txtAcaoDescricao = document.getElementById("txtAcaoDescricaoEdit");
        const txtLinkArquivo1 = document.getElementById("txtLinkArquivo1Edit");

        const selectQtdParticCaixa = document.getElementById("selectQtdParticCaixaEdit");
        const selectQtdExterno = document.getElementById("selectQtdExternoEdit");
        const tipoModal = document.getElementById("tipoModal");
        const idAcaoEdit = document.getElementById("idAcaoEdit");

        const submitEdit = document.getElementById("submitEdit");

        if (dataAcao.value === '' || dataAcao.value === null) {
          isValid = false;
        }
        if (txtAcaoDescricao.value === '' || txtAcaoDescricao.value === null) {
          isValid = false;
        }

        if (tipoModal.value == 1) {
          if (txtLinkArquivo1.value === '' || txtLinkArquivo1.value === null) {
            isValid = false;
          }
          // if(!isValidURL(txtLinkArquivo1.value)){
          //       isValid = false;
          //     } 
        }

        if (tipoModal.value == 1) {
          if (!(idAcaoEdit.value == 1 || idAcaoEdit.value == 2 || idAcaoEdit.value == 3 || idAcaoEdit.value == 4 || idAcaoEdit.value == 5)) {
            if (txtLinkArquivo1.value === '' || txtLinkArquivo1.value === null) {
              isValid = false;
            } else {
              if (!isValidURL(txtLinkArquivo1.value)) {
                isValid = false;
              }
            }
          }
        }

        if (selectQtdParticCaixa.value === '' || selectQtdParticCaixa.value === null) {
          isValid = false;
        }
        if (selectQtdExterno.value === '' || selectQtdExterno.value === null) {
          isValid = false;
        }

        // Se tudo não estiver preenchido, será gera um alerta
        if (!isValid) {
          Swal.fire({
            title: "Atenção!",
            text: "Por favor, preencha todos os campos.",
            icon: "warning",
            confirmButtonClass: 'btn btn-primary',
            buttonsStyling: false,
          });
          return false;
        }

        // Se tudo estiver preenchido, você pode continuar com o processo de envio via AJAX
        if (isValid) {

          console.log("validado");
          submitEdit.disabled = true;
          // chamada AJAX para enviar os dados ao servidor
          $.ajax({
            type: 'POST',
            url: '<? echo CxUrl::site('rep_eleitos:api:salvarEdicaoAcaoRecepcao') ?>',
            data: $('#form-edicao-acao').serialize(),
            success: function(response) {

              alert('Dados salvos com sucesso!');
              window.location.reload();
              // Limpa o formulário
              //$('#form-cadastro-acao')[0].reset();
              // Fecha o modal
              //$('#adicionarAcoesModal').modal('hide');
            },
            error: function() {
              alert('Ocorreu um erro ao salvar os dados.');
            }
          });
        }
      });

      //ação de salvar quando é adicionado uma nova ação ao componente
      $('#submiADD').on('click', function() {
        let isValid = true;
        let isValidText = '';
        const matriculaAcessante = <? echo $matricula ?>;
        const dataAcao = document.getElementById("dataAcaoADD");
        const txtAcaoDescricao = document.getElementById("txtAcaoDescricaoADD");
        const txtLinkArquivo1 = document.getElementById("txtLinkArquivo1ADD");

        const selectAcao = document.getElementById("selectAcaoADD");
        const selectQtdParticCaixa = document.getElementById("selectQtdParticCaixaADD");
        const selectQtdExterno = document.getElementById("selectQtdExternoADD");
        const tipoModal = document.getElementById("tipoModal");

        const submiADD = document.getElementById("submiADD");

        console.log(selectAcao.value);

        if (dataAcao.value === '' || dataAcao.value === null) {
          isValid = false;
        }
        if (txtAcaoDescricao.value === '' || txtAcaoDescricao.value === null) {
          isValid = false;
        }
        if (tipoModal.value == 1) {
          if (!(selectAcao.value == 1 || selectAcao.value == 2 || selectAcao.value == 3 || selectAcao.value == 4)) {
            if (txtLinkArquivo1.value === '' || txtLinkArquivo1.value === null) {
              isValid = false;
            } else {
              if (!isValidURL(txtLinkArquivo1.value)) {
                isValid = false;
              }
            }
          }
        }


        if (selectAcao.value === '' || selectAcao.value === null) {
          isValid = false;
        }
        if (selectQtdParticCaixa.value === '' || selectQtdParticCaixa.value === null) {
          isValid = false;
        }
        if (selectQtdExterno.value === '' || selectQtdExterno.value === null) {
          isValid = false;
        }

        // Se tudo não estiver preenchido, será gera um alerta
        if (!isValid) {
          Swal.fire({
            title: "Atenção!",
            text: "Por favor, preencha todos os campos.",
            icon: "warning",
            confirmButtonClass: 'btn btn-primary',
            buttonsStyling: false,
          });
          return false;
        }

        // Se tudo estiver preenchido, você pode continuar com o processo de envio via AJAX
        if (isValid) {
          //verifica a ação, se for as que tem relacionamento com o resultado.caixa, sera alertada
          if ((selectAcao.value == 5 || selectAcao.value == 14 || selectAcao.value == 18)) {
            Swal.fire({
              title: 'Você confirma a realização da Ação?',
              text: "Essa ação será validada pela equipe da GEEGO",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim, Realizei!',
              confirmButtonClass: 'btn btn-warning',
              cancelButtonClass: 'btn btn-danger ml-1',
              buttonsStyling: false,
            }).then(function(result) {
              if (result.value) {
                salvarAcao(2)
              } else if (result.dismiss === Swal.DismissReason.cancel) {
                Swal.fire({
                  title: 'Cancelado',
                  text: 'Ação cancelada',
                  icon: 'error',
                  confirmButtonClass: 'btn btn-success',
                }).then(function(result) {
                  if (result.value) {
                    window.location.reload();
                  }
                })
              }
            })
          }else{
            salvarAcao(1);
          } 
        }
      });

      function salvarAcao(tipo) {
        console.log("validado");
        submiADD.disabled = true;
        // chamada AJAX para enviar os dados ao servidor
        $.ajax({
          type: 'POST',
          url: '<? echo CxUrl::site('rep_eleitos:api:salvarAcaoRecepcao') ?>',
          data: $('#form-cadastro-acao').serialize(),
          success: function(response) {
            if (tipo == 1) {
              Swal.fire({
                icon: "success",
                title: 'Sucesso!',
                text: 'Contatos salvos com sucesso.',
                confirmButtonClass: 'btn btn-success',
              }).then(function(result) {
                if (result.value) {
                  window.location.reload();
                }
              })
            } else {
              Swal.fire({
                icon: "success",
                title: 'Confirmado Realização!',
                text: 'Ela será considerada para o resultado.caixa após validação.',
                confirmButtonClass: 'btn btn-success',
              }).then(function(result) {
                if (result.value) {
                  window.location.reload();
                }
              })
            }
          },
          error: function() {
            alert('Ocorreu um erro ao salvar os dados.');
          }
        });
      }

      //ação de salvar quando é adicionado uma nova ação ao componente
      $('#submiContatoADD').on('click', function() {
        const submiContatoADD = document.getElementById("submiContatoADD");
        submiContatoADD.disabled = true;
        // chamada AJAX para enviar os dados ao servidor
        $.ajax({
          type: 'POST',
          url: '<? echo CxUrl::site('rep_eleitos:api:salvarContatosRecepcao') ?>',
          data: $('#form-cadastro-contato').serialize(),
          success: function(response) {
            Swal.fire({
              icon: "success",
              title: 'Sucesso!',
              text: 'Contatos salvos com sucesso.',
              confirmButtonClass: 'btn btn-success',
            }).then(function(result) {
              if (result.value) {
                window.location.reload();
              }
            })

          },
          error: function() {
            Swal.fire({
              title: 'Error',
              text: 'Tente novamente, pois não conseguimos salvar enviar.',
              icon: 'error',
              confirmButtonClass: 'btn btn-success',
            })
          }
        });
      });

    });

    /**
     *  POPULAR COMBO BOX DO MODAL ADD DE ACORDO COM O TIPO DE AÇÃO PARA INSERT
     */
    function popularParametrosModalADD(idTipoAcao) {

      //form-edicao-acao
      const acoesSelect = document.getElementById("selectAcaoADD");
      // Zerando todo conteudo do select
      acoesSelect.options.length = 0;

      // Popular o Select de Ações
      acoes_lista.forEach((acoes) => {

        if (idTipoAcao == 1 && acoes.NU_GRUPO == 1) {
          // Verificar se a ação já foi inserida no acoes_banco_cliente
          const acaoJaRealizada = acoes_banco_cliente.some((acaoBanco) => {
            return acaoBanco.ID_ACOES === acoes.ID_ACOES && acaoBanco.DT_INSERT_ACAO !== null;
          });

          // Se a ação não foi realizada, adiciona ao dropdown
          if (!acaoJaRealizada) {
            const option = new Option(acoes.NO_ACOES.toLowerCase(), acoes.ID_ACOES);
            acoesSelect.options[acoesSelect.options.length] = option;
          }
        }

        // Popula o select com todas ações do grupo 3, sem restrição
        if (idTipoAcao == 2 && acoes.NU_GRUPO == 3) {
          const option = new Option(acoes.NO_ACOES.toLowerCase(), acoes.ID_ACOES);
          acoesSelect.options[acoesSelect.options.length] = option;
        }

        // Popula o select com todas ações do grupo 3, sem restrição
        let hideButton = false;
        const submitButton = document.getElementById("submiContatoADD");

        if (idTipoAcao == 5 && acoes.NU_GRUPO == 1) {
          hideButton = true;
             
          if (hideButton) {
            submitButton.style.display = "none";
          } else {
            submitButton.style.display = "block";
          }

        }
      });

      tipoModal = document.getElementById("tipoModal");
      tipoModal.value = idTipoAcao;
    }


    /**
     *  Abrir o modal de EDIÇÃO E ADICIONAR O PARAMENTROS DE ACORDO COM A SELEÇÃO
     */
    function popularParametrosModal(idAcaoEditar, idTipoAcao) {
      //busca realizada na listagem de parametros que vem do banco de acordo com o que foi clicado    
      var parametro;
      var titulo;

      dataAcaoEdit = document.getElementById('dataAcaoEdit');
      txtAcaoDescricaoEdit = document.getElementById('txtAcaoDescricaoEdit');
      txtLinkArquivo1Edit = document.getElementById('txtLinkArquivo1Edit');
      txtLinkArquivo2Edit = document.getElementById('txtLinkArquivo2Edit');
      selectQtdParticCaixaEdit = document.getElementById("selectQtdParticCaixaEdit");
      selectQtdExternoEdit = document.getElementById("selectQtdExternoEdit");
      idAcaoEdit = document.getElementById("idAcaoEdit");
      tipoModal = document.getElementById("tipoModal");
      tipoModal.value = idTipoAcao;

      if (idTipoAcao == 1) {
        parametro = acoes_banco_cliente.find(p => p.ID_REALIZADO_ACOES === idAcaoEditar.toString());
        titulo = "Edição da Ação de Recepção - ";

        // dataAcaoEdit.disabled = false;
        // txtAcaoDescricaoEdit.disabled = false;
        // txtLinkArquivo1Edit.disabled = false;
        // txtLinkArquivo2Edit.disabled = false;
        // selectQtdParticCaixaEdit.disabled = false;
        // selectQtdExternoEdit.disabled = false;
        // idAcaoEdit.disabled = false;
      } else {
        parametro = acoes_complementar_banco_cliente.find(p => p.ID_REALIZADO_ACOES === idAcaoEditar.toString());
        titulo = "Edição da Agenda GOV - ";


      }

      //de acordo com a busca, preencho os detalhes do parametro no task
      if (parametro) {
        $("#tituloAcaoEditar")[0].innerText = titulo + parametro.NO_ACOES;
        dataAcaoEdit.value = converterData(parametro.DT_DA_ACAO);
        txtAcaoDescricaoEdit.value = parametro.DE_INTERACAO_OCORRIDA;
        txtLinkArquivo1Edit.value = parametro.LINK_1;
        txtLinkArquivo2Edit.value = parametro.LINK_2;
        selectQtdParticCaixaEdit.value = parametro.NU_PARTIC_CAIXA;
        selectQtdExternoEdit.value = parametro.NU_PARTIC_EXTERNO;
        idAcaoEdit.value = parametro.ID_ACOES;

        let hideButton = false;
        if(parametro.ID_ACOES == 5 ){
          hideButton = true;
        }

        const submitButton = document.getElementById("submitEdit");
        if (hideButton) {
          submitButton.style.display = "none";
        } else {
          submitButton.style.display = "block";
        }

      }


      // const selectAcao = document.getElementById("submitEdit");
      // const idsToCheck = ["5", "14", "18"];
      // let hideButton = false;

      // acoes_lista.forEach((acoes) => {
      //   if (selectAcao.value == 5) {
      //     if (acoes.ID_ACOES == selectAcao.value) {
      //       const endDate = new Date(acoes.DT_FIM_ACAO + 'T23:59:59');
      //       const nowDate = new Date(); 
      //       if (endDate <= nowDate) {
      //         hideButton = true;
      //       }
      //     }
      //   }
      // });

      // const submitButton = document.getElementById("submitEdit");
      // if (hideButton) {
      //   submitButton.style.display = "none";
      // } else {
      //   submitButton.style.display = "block";
      // }
    }

    function converterData(dataString) {
      // Dividir a string na data original pelo delimitador "-"
      let partes = dataString.split("-");
      // Reorganizar as partes para o formato dd/mm/yyyy
      let dataConvertida = partes[2] + "/" + partes[1] + "/" + partes[0];
      return dataConvertida;
    }

    function isValidURL(url) {
      // var pattern = new RegExp('((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domínio
      //   '((\\d{1,3}\\.){3}\\d{1,3}))' + // ou endereço IP (v4)
      //   '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // porta e caminho
      //   '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
      //   '(\\#[-a-z\\d_]*)?$', 'i'); // fragmento 
      // return !!pattern.test(url);
      return true;
    }
  </script>