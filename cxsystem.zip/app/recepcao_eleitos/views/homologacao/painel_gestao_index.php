<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ .'/../daos/indexDao.php');
$dao = new indexDAO();

$dadosArvoreAcesso = $dao -> buscaArvoreAcesso($matricula);
//echo var_dump($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE']);
//$listaMuncSeg = $dao-> buscaListaMunicipiorPorSeg($dadosArvoreAcesso[0]['NU_UNIDADE']);

 if($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == "S"){
   $listaMuncSeg = $dao-> buscaListaMunicipiorPorSeg($dadosArvoreAcesso[0]['NU_UNIDADE']);
 }else{
   $listaMuncSeg = $dao-> buscaListaMunicipiorPorGigov($dadosArvoreAcesso[0]['NU_UNIDADE']);
 }


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Acompanhamento das Ações da Recepção</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title "><?php echo $dadosArvoreAcesso[0]['NO_UNIDADE']?></h4>
        </div>
      
        <div class="card-body ">
          <div class="table-responsive">
            <table id="table-extended-success" class="table mb-0">
                <thead>
                    <tr>
                        <th>Prior.</th>
                        <th>Cliente</th>
                        <th>Segmento </th>
                        <?php  if($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == 'S'){
                          echo '<th>GIGOV</th>';
                        }else{
                          echo '<th>SEG</th>';
                        } ?>
                        <th class="text-center">Última Ação de Relacionamento</th>
                        <th>Qtd de Ações</th>
                        <th>Plano de Negócios</th>
                        <th>Capacitação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                  <?php foreach ($listaMuncSeg as $resultado) {
                          echo "<tr>";
                          if( $resultado['MUNICIPIO_PRIORITARIO'] == 0){
                            echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle danger font-small-1 ml-1 '></i></td>";
                          }else{
                            echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle success font-small-1 ml-1' style='margin-top: 5px;'></i></td>";
                          }
                            echo "<td class='text-bold-600 pr-0'>".$resultado['NOME_MUNICIPIO']."</td>";
                            echo "<td>".$resultado['NOME_SEGMENTO']."</td>";

                          if($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == 'S'){
                            echo "<td>".$resultado['NOME_GIGOV']."</td>";
                          }else{
                            echo "<td>".$resultado['NOME_SEG']."</td>";
                          }

                            echo "<td class='text-bold-600 text-center'><span>".$resultado['ULTIMA_ACOES_OBRIGATORIA']."</span></td>";
                            echo "<td><p class='ml-1'>".$resultado['QTD_ACOES_REALIZADAS']." - 13</p></td>";
                          if( $resultado['PLANO_NEGOCIO'] == 0){
                            echo " <td class='text-danger'><i class='bx bx-error-circle ml-3'></i></td>";
                          }else{
                            echo " <td class='text-success'><i class='bx bxs-check-circle ml-3'></i></td>";
                          }

                          if( $resultado['CAPTACAO'] == 0){
                            echo " <td class='text-danger'><i class='bx bx-error-circle ml-3'></i></td>";
                          }else{
                            echo " <td class='text-success'><i class='bx bxs-check-circle ml-3'></i></td>";
                          }
                            echo ("<td>
                                    <div class='dropdown'>
                                      <span class='bx bx-dots-vertical-rounded font-medium-3 dropdown-toggle nav-hide-arrow cursor-pointer ml-1' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false' role='menu'></span>
                                      <div class='dropdown-menu dropdown-menu-right'>
                                        <a class='dropdown-item' href='".CxUrl::site('rep_eleitos:acoes_relac', ['municip' => $resultado['CNPJ']]) ."'><i class='bx bx-edit-alt mr-1'></i> Ação de Obrigatórioas</a>
                                        <a class='dropdown-item' href='javascript:void(0);'><i class='bx bx-book-reader mr-1'></i> Agenda Gov</a>
                                        <a class='dropdown-item' href='javascript:void(0);'><i class='bx bx-file mr-1'></i> Plano de Negócio</a>
                                        <a class='dropdown-item' href='javascript:void(0);'><i class='bx bx-book-content mr-1'></i> Capacitação</a>
                                      </div>
                                    </div>
                                  </td>");
                            echo "</tr>";
                        
                      } ?>              
                </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>