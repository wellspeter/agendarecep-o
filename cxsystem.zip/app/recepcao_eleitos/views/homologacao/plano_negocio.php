<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];
//echo $dadosUsuario['nu_lotacao_fisica'];

$cnpjMunicipio = CxRequest::params('municip');
//$cnpjMunicipio = '18338178000102';
//echo $cnpjMunicipio;

require_once(__DIR__ . '/../daos/planoNegocioDao.php');
require_once(__DIR__ . '../../../../lib/funcoes/funcoes.php');

$dao = new planoNegocioDao();

$dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
$dadosCliente = $dao->buscaDadosClientePlanoNegocio($cnpjMunicipio);
$dadosOportunidadeCliente = $dao->buscaDadosOportunidadeCliente($cnpjMunicipio);

$planoNegocio = $dao->getPlanoNegocio($cnpjMunicipio);

//echo var_dump($planoNegocio);



?>

<style>
    .card-no-fundo {
        border: 1px solid #DFE3E7;
        border-radius: 0.267rem;
        background: #fff;
    }

    .table-padrao,
    .table-bancos,
    .table-caixa,
    .table-regiao,
    .table-segmento {
        width: 100%;
        margin: 10px 0;
    }

    .table-padrao tr,
    .table-bancos tr,
    .table-caixa tr,
    .table-regiao tr,
    .table-segmento tr {
        border-bottom: 1px solid rgba(0, 0, 0, 0.125);
        white-space: nowrap;
    }

    .table-caixa td:nth-child(2) {
        text-align: right;
    }

    .table-caixa td,
    .table-bancos td:nth-child(2),
    .table-bancos td:nth-child(4) {
        padding: 2px 10px;
    }

    .table-padrao td:first-child,
    .table-bancos td:first-child,
    .table-bancos td:nth-child(3),
    .table-caixa td:first-child,
    .table-regiao td:first-child,
    .table-segmento td:first-child {
        font-weight: bold;
    }

    .data-referencia {
        position: absolute;
        right: 25px;
        bottom: 15px;
        font-size: 10px;
        color: #6c757d !important;
        cursor: pointer;
    }

    .boder-vertical {
        border-left: 1px solid #DFDFDF;
    }
</style>

<div class="container-fluid">
    <div class="row mb-1">
        <div class="col-9">
            <h4 class=""></small>Plano de Negócios - </small> <?php echo $dadosCliente[0]['no_municipio'] ?>, <?php echo $dadosCliente[0]['sg_uf'] ?></h4>
        </div>
        <div class="col-3 ">
            <div class="justify-content-end">
                <? if (count($planoNegocio) > 0) {
                    if ($planoNegocio[0]['STATUS'] != '2') {
                        echo '<button class="btn btn-warning mr-1" type="button" id="submitRascunho" name="submitRascunho">Salvar Rascunho</button>';
                        echo '<button class="btn btn-primary" type="button" id="submitEnviar" name="submitEnviar" disabled>Enviar</button>';
                    }
                } else {
                    echo '<button class="btn btn-warning mr-1" type="button" id="submitRascunho" name="submitRascunho">Salvar Rascunho</button>';
                    echo '<button class="btn btn-primary" type="button" id="submitEnviar" name="submitEnviar" disabled>Enviar</button>';
                }
                ?>
            </div>
        </div>
    </div>
    <!-- ################################################################################## -->
    <!-- ########################### CONTEÚDO (ÁREA DOS CARDS) ############################ -->
    <!-- ################################################################################## -->
    <hr>
    <!-- ########################################################################### -->
    <!-- ########################### INFORMAÇÕES GERAIS ############################ -->
    <!-- ########################################################################### -->
    <div class="row">
        <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
        <h5 class="ml-1">Informações Gerais</h5>
    </div>
    <div class="row">
        <div class="col-12">
            <div class=" row">
                <div class="col-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">CNPJ's</h6>
                                <h2 class="ff-secondary fw-semibold">
                                    <span class="subtitle-card"><? echo formatar_cnpj($dadosCliente[0]['CO_CNPJ'])  ?></span>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Prefeito(a) reeleito(a) em 2020</h6>
                                <h2 class="ff-secondary fw-semibold">
                                    <span id="qt_cnpjs" class="subtitle-card"><? echo $dadosCliente[0]['REELEITO'] ?></span>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Segmento</h6>
                                <h2 class="ff-secondary fw-semibold">
                                    <span id="qt_cnpjs"></span>
                                    <span class="subtitle-card"><? echo $dadosCliente[0]['NO_SEGMENTO'] ?></span>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-9">
            <!--------------->
            <!-- POPULAÇÃO -->
            <!--------------->

            <div class=" row">
                <!-------------->
                <!-- QT CNPJS -->
                <!-------------->
                <div class="col-3 pr-0" data-id="qt-cnpjs" id="qt-cnpjs">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">Qtd. CNPJ's</h6>
                                    <h2 class="ff-secondary fw-semibold">
                                        <span id="qt_cnpjs">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['CNPJ_VINCULADOS'] ?></span>
                                        </span>
                                        <span class="subtitle-card">cliente(s)</span>
                                    </h2>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="bx bxs-group"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--------------->
                <!-- POPULAÇÃO -->
                <!--------------->
                <div class="col-3 pr-0" data-id="populacao" id="populacao">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">População</h6>
                                    <p class="subtitle-card text-muted mb-0">(Quantidade)</p>
                                    <h2 class="ff-secondary fw-semibold">
                                        <span id="vr_populacao">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QT_POPULACAO_IBGE'] ?></span>
                                        </span>
                                        <span class="subtitle-card">pessoas</span>
                                    </h2>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-people-group"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_populacao"><? echo $dadosCliente[0]['AA_POPULACAO_IBGE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!---------------->
                <!-- SERVIDORES -->
                <!---------------->
                <div class="col-3 pr-0" data-id="servidores" id="servidores">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral col">
                                    <h6 class="title-card mb-0">Servidores</h6>
                                    <p class="subtitle-card text-muted mb-0">(Quantidade)</p>
                                    <table class="table-padrao table-folha">
                                        <tr>
                                            <td>Adm Direta:</td>
                                            <td>
                                                <span id="vr_servidores_direta">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status">-</span>
                                                </span>
                                            </td>
                                            <td id="pt_servidores_direta">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"></span>
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Adm Indireta:</td>
                                            <td>
                                                <span id="vr_servidores_indireta">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status">-</span>
                                                </span>
                                            </td>
                                            <td id="pt_servidores_indireta">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Totais:</td>
                                            <td>
                                                <span id="vr_servidores">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QTD_SERVIDORES'] ?></span>
                                                </span>
                                            </td>
                                            <td id="pt_servidores">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                            </td>
                                            <td>

                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-users-rectangle"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_servidores"><? echo $dadosCliente[0]['REF_SERVIDORES'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
                <!--------------->
                <!----- CAPAG STN ----->
                <!--------------->
                <div class="col-3 pr-0" data-id="ing" id="ing">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">CAPAG STN</h6>
                                    <h2 class="ff-secondary fw-semibold mb-1">
                                        <span id="vr_ing">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['IC_CAPAG'] ?></span>
                                        </span>
                                        <span class="subtitle-card"></span>
                                        <!-- <p class="subtitle-card text-muted mb-0" style="font-size: .45em;">Vencimento: 01/08/2025</p> -->
                                    </h2>
                                    <!-- <p class="subtitle-card text-muted mb-0" style="font-size: .85em; text-decoration:underline">Referências</p>
                                    <p class="subtitle-card text-muted mb-0" style="font-size: .85em;">Pontuação Mínima: 1</p>
                                    <p class="subtitle-card text-muted mb-0 mb-2" style="font-size: .85em;">Pontuação Máxima: 5</p> -->
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-trophy"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!--------------->
                <!-- ICO MÉDIO -->
                <!--------------->
                <div class="col-3 pr-0" data-id="ico" id="ico">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">ICO</h6>
                                    <h2 class="ff-secondary fw-semibold mb-1">
                                        <span id="vr_ico_medio">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['NU_PONTUACAO_ICO'] ?></span>
                                        </span>
                                        <span class="subtitle-card">pontos</span>
                                    </h2>
                                    <p class="subtitle-card text-muted mb-0" style="font-size: .85em; text-decoration:underline">Referências</p>
                                    <p class="subtitle-card text-muted mb-0" style="font-size: .85em;">Pontuação Mínima: 0</p>
                                    <p class="subtitle-card text-muted mb-0 mb-2" style="font-size: .85em;">Pontuação Máxima: 135</p>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="bx bxs-trophy"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
                <!--------->
                <!-- ROA -->
                <!--------->
                <div class="col-3 pr-0" data-id="roa" id="roa">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">ROA</h6>
                                    <h2 class="ff-secondary fw-semibold">
                                        <span class="subtitle-card">R$</span>
                                        <span id="vr_roa">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_ROA_RECIPROCIDADE'] ?></span>
                                        </span>

                                    </h2>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="bx money-withdraw"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
                <!--------------------------------->
                <!-- MC - MARGEM DE CONTRIBUIÇÃO -->
                <!--------------------------------->
                <div class="col-3 pr-0" data-id="MC" id="MC">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">Margem Contribuição</h6>
                                    <p class="subtitle-card text-muted mb-0">(Realizado 12 Meses)</p>
                                    <h2 class="ff-secondary fw-semibold">
                                        <span class="subtitle-card">R$</span>
                                        <span id="vr_mc">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_MC_ANUALIZADO_SIRCL'] ?></span>
                                        </span>

                                    </h2>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="bx trending-up"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
                <!--------->
                <!-- RPS -->
                <!--------->
                <div class="col-3 pr-0" data-id="MC" id="MC">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">RPS</h6>
                                    <p class="subtitle-card text-muted mb-0">(Realizado 12 Meses)</p>
                                    <h2 class="ff-secondary fw-semibold">
                                        <span class="subtitle-card">R$</span>
                                        <span id="vr_mc">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_RPS_ANUALIZADO_SIRCL'] ?></span>
                                        </span>

                                    </h2>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="bx trending-up"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
            </div>

            <div class=" row">

                <!-- ------------>
                <!-- ING -->
                <!--------------->
                <div class="col-3 pr-0" data-id="ing" id="ing">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">ING</h6>
                                    <h2 class="ff-secondary fw-semibold mb-1">
                                        <span id="vr_ing">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_ING'] ?></span>
                                        </span>
                                        <span class="subtitle-card"></span>
                                        <p class="subtitle-card text-muted mb-0" style="font-size: .45em;"><? echo $dadosCliente[0]['NU_FAIXA_ING'] ?> pontos</p>
                                    </h2>
                                    <p class="subtitle-card text-muted mb-0" style="font-size: .85em; text-decoration:underline">Referências</p>
                                    <p class="subtitle-card text-muted mb-0" style="font-size: .85em;">Pontuação Mínima: 1</p>
                                    <p class="subtitle-card text-muted mb-0 mb-2" style="font-size: .85em;">Pontuação Máxima: 5</p>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-trophy"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_ico_medio"><? echo $dadosCliente[0]['DH_ATUALIZACAO_ICO'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!------------------>
                <!-- RATING CAIXA -->
                <!------------------>
                <div class="col-3 pr-0" data-id="ing" id="ing">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral">
                                    <h6 class="title-card mb-0">RATING CAIXA</h6>

                                    <h2 class="title-card mt-0 mb-0">
                                        <span id="vr_ing">
                                            <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['CO_RATING_CAIXA'] ?>
                                                <label class="subtitle-card text-bold-300 ">(Nota)</label>
                                            </span>
                                        </span>
                                    </h2>
                                    <span class="subtitle-card">Vencimento: <label> <? echo $dadosCliente[0]['DT_VALIDADE_AVALIACAO_RISCO'] ?> </label></span>

                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-trophy"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_ico_medio"><? echo $dadosCliente[0]['DH_ATUALIZACAO_ICO'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>


                <!------------------------->
                <!-- REDE DE ATENDIMENTO -->
                <!------------------------->
                <div class="col-6 pr-0" data-id="rede_atendimento" id="rede_atendimento">
                    <div class="card-no-fundo card-animate" style="height: 95%">
                        <div class="card-body">
                            <div class="d-flex justify-content-between body">
                                <div class="body-geral col">
                                    <h6 class="title-card mb-0">Rede de Atendimento</h6>
                                    <table class="table-padrao table-folha">
                                        <tr>
                                            <td>SR</td>
                                            <td>
                                                <span id="vr_sr">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_sr'] ?> -
                                                        <? echo $dadosCliente[0]['no_sr'] ?>
                                                    </span>
                                                </span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>SEG:</td>
                                            <td>
                                                <span id="vr_seg">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_seg'] ?> -
                                                        <? echo $dadosCliente[0]['no_seg'] ?>
                                                    </span>
                                                </span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>SEH:</td>
                                            <td>
                                                <span id="vr_seg">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_seh'] ?> -
                                                        <? echo $dadosCliente[0]['no_seh'] ?>
                                                    </span>
                                                </span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>SEV:</td>
                                            <td>
                                                <span id="vr_ag">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_sev'] ?> -
                                                        <? echo $dadosCliente[0]['no_sev'] ?>
                                                    </span>
                                                </span>
                                            </td>


                                        </tr>
                                        <tr>
                                            <td>Ag:</td>
                                            <td>
                                                <span id="vr_ag">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_pv'] ?> -
                                                        <? echo $dadosCliente[0]['no_pv'] ?>
                                                    </span>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>GIGOV</td>
                                            <td>
                                                <span id="vr_gigov">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_gigov'] ?> -
                                                        <? echo $dadosCliente[0]['no_gigov'] ?>
                                                    </span>
                                                </span>
                                            </td>
                                        </tr>
                                        <!-- <tr>
                                            <td>GIHAB</td>
                                            <td>
                                                <span id="vr_gigov">
                                                    <span class="text-secondary" role="status">
                                                        <? echo $dadosCliente[0]['co_gigov'] ?> -
                                                        <? echo $dadosCliente[0]['no_gigov'] ?>
                                                    </span>
                                                </span>
                                            </td>
                                        </tr> -->
                                    </table>
                                </div>
                                <div class="avatar-card">
                                    <span class="avatar-title">
                                        <i class="fa-solid fa-users-rectangle"></i>
                                    </span>
                                </div>
                                <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end card-->
            </div>
        </div>
        <div class="col-3 pr-0">
            <div class="card-no-fundo card-animate" style="height: 97%" data-id="rede-bancaria" id="rede-bancaria">
                <div class="card-body">
                    <div class=" justify-content-between body">
                        <div class="body-geral">
                            <h6 class="title-card mb-0">Rede Bancária</h6>
                            <p class="subtitle-card text-muted mb-0">(CAIXA)</p>
                            <div class="row">
                                <div class="col">
                                    <table class="table-caixa">
                                        <tr>
                                            <td>Agências CAIXA:</td>
                                            <td id="qt_ag_caixa">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_CAIXA'] ?></span>
                                            </td>
                                        <tr>
                                            <td>Lotéricas:</td>
                                            <td id="qt_lotericas">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"> - </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>CCA's:</td>
                                            <td id="qt_cca">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"> - </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <p class="subtitle-card text-muted mb-0">(Outros Bancos)</p>
                                    <table class="table-bancos">
                                        <tr>
                                            <td>
                                                <i class="fa-regular fa-building" style="color:red;"></i>
                                                Santander:
                                            </td>
                                            <td id="qt_santander">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_SANTANDER'] ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <i class="fa-regular fa-building" style="color:#ffc800;"></i>
                                                BB:
                                            </td>
                                            <td id="qt_bb">
                                                <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_BB'] ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <i class="fa-regular fa-building" style="color:#f39200;"></i>
                                                Itaú:
                                            </td>
                                            <td id="qt_itau">
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_ITAU'] ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <i class="fa-regular fa-building" style="color:#c30000;"></i>
                                                Bradesco:
                                            </td>
                                            <td id="qt_bradesco">
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_BRADESCO'] ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <i class="fa-regular fa-building" style="color:#999;"></i>
                                                Outros:
                                            </td>
                                            <td id="qt_outros">

                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_AGENCIA_OUTROS_BANCOS'] ?></span>
                                            </td>
                                        </tr>
                                    </table>
                                    <span class="data-referencia" id="dt_rede_bancaria_concorrencia"></span>
                                </div>
                            </div>
                        </div>
                        <div class="avatar-card">
                            <span class="avatar-title">
                                <i class="fa-solid fa-building-user"></i>
                            </span>
                        </div>
                        <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>



                    </div>
                </div>
            </div>
        </div>
    </div>
    <!----------------------------------------------------------------------------------------------------->
    <!------------------------------------ Campos para serem preenchidos ---------------------------------->
    <!----------------------------------------------------------------------------------------------------->
    <hr>
    <form id="form-cadastro-plano-negocio" method="post" action="javascript:void(0)">
        <input type="hidden" id="cnpj" name="cnpj" value="<? echo   $cnpjMunicipio  ?>">
        <input type="hidden" id="matricula" name="matricula" value="<? echo   $matricula  ?>">
        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">Estudos</h5>
        </div>
        <div class="row">
            <!-------------------------------------->
            <!-- Necessidades do Plano de Governo -->
            <!-------------------------------------->
            <div class="col-6  pr-0">
                <div class="card card-animate mt-0 mb-0" style="height: 90%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0" style="font-weight: 700;">Plano de Governo * </h6>
                                <div class="col card-2-valores">

                                    <fieldset class="form-group">
                                        <label>Quais necessidades encontradas no plano de Governo analisado. </label>
                                        <textarea class="form-control" id="txtAnalisePlanoGoverno" name="txtAnalisePlanoGoverno" rows="11" placeholder=""><?php if (count($planoNegocio) > 0) {
                                                                                                                                                                echo $planoNegocio[0]['ANALISE_PLANO_GOVERNO'];
                                                                                                                                                            } ?>
                                        </textarea>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-earth-americas"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 0%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>

                    </div>
                </div>
            </div>
            <!------------------------>
            <!-- Notícias e Debates -->
            <!------------------------>
            <div class="col-6  pr-0">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0" style="font-weight: 700;">Notícias e Debates</h6>
                                <div class="col card-2-valores">

                                    <fieldset class="form-group">
                                        <label>Quais necessidades encontradas após analisar as Notícias e Debates. </label>
                                        <textarea class="form-control" id="txtAnaliseNoticiasGoverno" name="txtAnaliseNoticiasGoverno" rows="10" placeholder="">
                                            <?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['ANALISE_NOTICIA_DEBATE'];
                                            } ?>
                                        </textarea>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-earth-americas"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 0%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <hr>
        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">Serviços</h5>
        </div>
        <div class="row">
            <!--------------------->
            <!-- Folha pagamento -->
            <!--------------------->
            <div class="col-6 pr-0" data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Folha de Pagamento do Ente Principal</h6>
                                <div class="row">
                                    <div class="col-6 mt-1">
                                        <div class="row mb-0">
                                            <div class="col">
                                                <h2 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['NO_BANCO'] ?></span>
                                                    </span>
                                                </h2>
                                            </div>
                                        </div>
                                        <table class="table-caixa mt-0">
                                            <tr>
                                                <td>Folha Bruta:</td>
                                                <td id="qt_ag_caixa">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status">R$ <? echo $dadosCliente[0]['VR_FOLHA_BRUTA'] ?> </span>
                                                </td>
                                            <tr>
                                                <td>Vencimento:</td>
                                                <td id="qt_lotericas">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VENCIMENTO_FOLHA'] ?></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Forma de Aquisição:</td>
                                                <td id="qt_cca">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"><? echo $dadosCliente[0]['NO_FORMA_AQUISICAO'] ?></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Valor Venda Folha:</td>
                                                <td id="qt_cca">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['VR_VENDA_FOLHA'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Folha Prioritária:</td>
                                                <td id="qt_cca">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['PRIORITARIO_FOLHA'] ?> </span>
                                                </td>
                                            </tr>
                                        </table>


                                    </div>
                                    <div class="col-6 boder-vertical">
                                        <div class="body-geral">
                                            <div class="row mb-0">
                                                <div class="col">
                                                    Expectativa:
                                                    <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                        <span id="vr_ing">
                                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                            <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FOLHA_PLANO'] ?></span>
                                                        </span>
                                                    </h6>
                                                </div>
                                            </div>
                                            <h6 class="title-card mt-1">Ação de Negociação</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="folhaRadio" id="folhaRadio1" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FOLHA_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['FOLHA_NEGOCIACAO_ACAO'] == "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="folhaRadio1">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="folhaRadio" id="folhaRadio2" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FOLHA_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['FOLHA_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="folhaRadio2">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaFolha" name="txtJustificativaFolha" rows="9" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FOLHA_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['FOLHA_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-scale-balanced"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!-------------------------------------->
            <!--- CAIXA Políticas Públicas - CPP ---->
            <!--------------------------------------->
            <div class="col-6 pr-0 " data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">CAIXA Políticas Públicas - CPP</h6>
                                <div class="row mt-1">
                                    <div class="col-6 ">
                                        <table class="table-caixa">
                                            <tr>
                                                <td>Valor de contratos ativos:</td>
                                                <td id="qt_ag_caixa">
                                                    <span class="text-secondary" role="status">R$ <? echo $dadosCliente[0]['VR_INVESTIMENTO_CPP'] ?> </span>
                                                </td>
                                            <tr>
                                                <td>Valor de executado:</td>
                                                <td id="qt_lotericas">

                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['VR_EXECUTADO_CPP'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Quantidade de contratos ativos:</td>
                                                <td id="qt_cca">

                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_CONTRATO_CPP'] ?> </span>
                                                </td>
                                            </tr>
                                        </table>
                                        <div class="mt-2 mb-0">
                                            <span class="subtitle-card">Próximo CPP a vencer </span>
                                            <table class="table-caixa">
                                                <tr>
                                                    <td>Proposta:</td>
                                                    <td id="qt_ag_caixa">

                                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['PROPOSTA_COM_VENCIMENTO_PRÓXIMO'] ?> </span>
                                                    </td>
                                                <tr>
                                                    <td>Descrição:</td>
                                                    <td id="qt_lotericas">

                                                        <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['DESCRICAO_DA_PROPOSTA'] ?></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Data vencimento:</td>
                                                    <td id="qt_cca">
                                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['DATA_VENCIMENTO_CPP'] ?> </span>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_CPP_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <div class="body-geral">
                                            <h6 class="title-card mt-1">Ação de Negociação</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="cppRadio" id="cppRadioSim" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CPP_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['CPP_NEGOCIACAO_ACAO'] === "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="cppRadioSim">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="cppRadio" id="cppRadioNao" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CPP_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['CPP_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="cppRadioNao">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaCPP" name="txtJustificativaCPP" rows="7" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CPP_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['CPP_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                            <div class="mt-2">
                                                <fieldset class="form-label-group">
                                                    <input type="text" class="form-control" id="txtQtdCPP" name="txtQtdCPP"
                                                        placeholder="Informe a qtd de contratos que vai realizar."
                                                        <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CPP_ACOMP'] == 0) {
                                                            echo 'disabled';
                                                        } ?>
                                                        value="<?php if (count($planoNegocio) > 0) {
                                                                    echo $planoNegocio[0]['CPP_NEGOCIACAO_QTD'];
                                                                } ?>" />
                                                    <label for="txtQtdCPP">Informe a qtd de contratos que vai realizar.</label>
                                                </fieldset>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

        </div>
        <div class="row">
            <!----------------->
            <!-- ARRECADAÇÃO -->
            <!----------------->
            <div class="col-6 pr-0" data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Arrecadação</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="row">
                                            <div class="col">
                                                <h2 class="title-card mt-1 mb-0">R$
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status">-</span>
                                                    </span>
                                                </h2>
                                                <span class="subtitle-card mt-0">(Valor último 12 meses)</span></br>
                                                <span class="subtitle-card mt-0">(Ente principal e vinculados)</span>
                                            </div>
                                        </div>
                                        <table class="table-caixa">
                                            <tr>
                                                <td>Qtd de Títulos 2023:</td>
                                                <td id="qt_lotericas">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_ARREC_ANUALIZADA_2023'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Qtd de Títulos 2024:</td>
                                                <td id="qt_cca">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_ARREC_ANUALIZADA_2024'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Comp Ano Anterior:</td>
                                                <td id="qt_ag_caixa">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['COMPARATIVO_ARRECADAÇÃO'] ?></span>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_ARREC_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <div class="body-geral">
                                            <h6 class="title-card mt-1">Ação de Negociação</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="arrecadacaoRadio" id="arrecadacaoRadioSim" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_ARREC_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['ARREC_NEGOCIACAO_ACAO'] === "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="arrecadacaoRadioSim">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="arrecadacaoRadio" id="arrecadacaoRadioNao" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_ARREC_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['ARREC_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="arrecadacaoRadioNao">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaArrecadacao" name="txtJustificativaArrecadacao" rows="7" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_ARREC_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['ARREC_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!------------------>
            <!---- Cobrança ---->
            <!------------------>
            <div class="col-6" data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Cobrança</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="row">
                                            <div class="col">
                                                <h2 class="title-card mt-1 mb-0">R$
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QT_COBRANCA_ICO'] ?></span>
                                                    </span>
                                                </h2>
                                                <span class="subtitle-card mt-0">(Valor último 12 meses)</span></br>
                                                <span class="subtitle-card mt-0">(Ente principal e vinculados)</span>
                                            </div>
                                        </div>
                                        <table class="table-caixa">
                                            <tr>
                                                <td>Qtd de Títulos 2023:</td>
                                                <td id="qt_lotericas">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_COBRANCA_ANUALIZADA_MAI_2023'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Qtd de Títulos 2024:</td>
                                                <td id="qt_cca">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_COBRANCA_ANUALIZADA_MAI_2024'] ?> </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Comp Ano Anterior:</td>
                                                <td id="qt_ag_caixa">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['COMPARATIVO_COBRANCA'] ?> %</span>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_COB_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <div class="body-geral">
                                            <h6 class="title-card mt-1">Ação de Negociação</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="cobrancaRadio" id="cobrancaRadioSim" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_COB_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }

                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['COB_NEGOCIACAO_ACAO'] === "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="cobrancaRadioSim">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="cobrancaRadio" id="cobrancaRadioNao" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_COB_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['COB_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="cobrancaRadioNao">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaCobranca" name="txtJustificativaCobranca" rows="7" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_COB_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['COB_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
        </div>

        <div class="row">
            <!------------------------------->
            <!--- Pagamento a Fornecedor ---->
            <!------------------------------->
            <div class="col-6 pr-0 " data-id="roa" id="roa">
                <div class="card card-animate " style="height: 90%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Pagamento a Fornecedor</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <h2 class="title-card mt-1 mb-0">
                                            <span id="vr_ing">
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_CREDITO_PAGAMENTO_FORNECEDOR_ICO'] ?> </span>
                                            </span>
                                        </h2>
                                        <span class="subtitle-card mt-0">(Quantidade)</span>
                                    </div>
                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_PAG_FOR_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <h6 class="title-card mt-1">Ação de Negociação</h6>
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-inline-block mr-2 mb-1">
                                                <fieldset>
                                                    <div class="radio">
                                                        <input type="radio" name="pagFornRadio" id="pagFornRadioSim" value="1"
                                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_PAG_FOR_ACOMP'] == 0) {
                                                                echo 'disabled';
                                                            }
                                                            if (count($planoNegocio) > 0) {
                                                                if ($planoNegocio[0]['PAG_FOR_NEGOCIACAO_ACAO'] === "1") {
                                                                    echo "checked";
                                                                }
                                                            }
                                                            ?>>
                                                        <label for="pagFornRadioSim">Sim</label>
                                                    </div>
                                                </fieldset>
                                            </li>
                                            <li class="d-inline-block mr-2 mb-1">
                                                <fieldset>
                                                    <div class="radio">
                                                        <input type="radio" name="pagFornRadio" id="pagFornRadioNao" value="0"
                                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_PAG_FOR_ACOMP'] == 0) {
                                                                echo 'disabled';
                                                            }
                                                            if (count($planoNegocio) > 0) {
                                                                if ($planoNegocio[0]['PAG_FOR_NEGOCIACAO_ACAO'] === "0") {
                                                                    echo "checked";
                                                                }
                                                            }
                                                            ?>>
                                                        <label for="pagFornRadioNao">Não</label>
                                                    </div>
                                                </fieldset>
                                            </li>
                                        </ul>
                                        <textarea class="form-control" id="txtJustificativapagForn" name="txtJustificativapagForn" rows="4" placeholder=""
                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_PAG_FOR_ACOMP'] == 0) {
                                                echo 'disabled';
                                            } ?>><?php if (count($planoNegocio) > 0) {
                                                        echo $planoNegocio[0]['PAG_FOR_NEGOCIACAO_DESC'];
                                                    } ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 2%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!---------------->
            <!-- CONSIGNADO -->
            <!---------------->
            <div class="col-6 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 90%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Consignado (SGR)</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_SGR_CONSIGNADO_ATIVO_ICO'] ?></span>
                                    </span>
                                    <!-- <h6 class="text-muted m-0" style="font-weight: 300;">(Valor)</h6> -->
                                    <h6 class="ff-secondary fw-semibold">
                                        <span id="qt_consignado">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QTD_CONSIGNADO'] ?> </span>
                                        </span>
                                        <span class="subtitle-card">contratos</span>
                                    </h6>
                                </h2>
                            </div>
                            <div class="col-6 boder-vertical">
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_CONSIG_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="sgrRadio" id="sgrRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CONSIG_CTPF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['CONSIG_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="sgrRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="sgrRadio" id="sgrRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CONSIG_CTPF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['CONSIG_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    } ?>>
                                                <label for="sgrRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                </ul>
                                <textarea class="form-control" id="txtJustificativaSGR" name="txtJustificativaSGR" rows="4" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_CONSIG_CTPF_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['CONSIG_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
        </div>

        <hr>
        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">Financiamento</h5>
        </div>
        <div class="row">
            <div class="col-6 pr-0 " data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Esteira</h6>
                                <div class="row">
                                    <div class="col-6">
                                        <table class="table-caixa mt-2">
                                            <tr>
                                                <td>Valor:</td>
                                                <td id="qt_ag_caixa">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status">R$ <? echo $dadosCliente[0]['VR_ESTEIRA_CREDITO'] ?> </span>
                                                </td>
                                            <tr>
                                                <td>Quantidade:</td>
                                                <td id="qt_lotericas">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_ESTEIRA_CREDITO'] ?> </span>
                                                </td>
                                            </tr>
                                        </table>
                                        <div class="mt-2 mb-0">
                                            <span class="subtitle-card mt-4">Carteira Ativa</span>
                                            <table class="table-caixa ">
                                                <tr>
                                                    <td>Valor:</td>
                                                    <td id="qt_ag_caixa">
                                                        <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                        <span class="text-secondary" role="status">R$ - </span>
                                                    </td>
                                                <tr>
                                                    <td>Quantidade:</td>
                                                    <td id="qt_lotericas">
                                                        <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_OPERACOES_CREDITO'] ?> </span>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FINANC_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <div class="body-geral">
                                            <h6 class="title-card mt-1">Ação de Negociação</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="financEsteiraRadio" id="financEsteiraRadioSim" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FINANC_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['ESTEIRA_NEGOCIACAO_ACAO'] === "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="financEsteiraRadioSim">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="financEsteiraRadio" id="financEsteiraRadioNao" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FINANC_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['ESTEIRA_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                } ?>>
                                                            <label for="financEsteiraRadioNao">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaFinancEsteira" name="txtJustificativaFinancEsteira" rows="10" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FINANC_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['ESTEIRA_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>

            <!-------------------------------------->
            <!--- OBRAS PARALIZADAS ---->
            <!--------------------------------------->
            <div class="col-3 pr-0" data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Obras Paralisadas</h6>
                                <div class="row">
                                    <div class="col">
                                        <h2 class="title-card mt-1 mb-0"> R$
                                            <span id="vr_ing">
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['VR_PARALISADAS_FINANCIAMENTO'] ?>
                                                    <label class="subtitle-card text-bold-300 ">(Valor)</label>
                                                </span>
                                            </span>
                                        </h2>
                                        <span class="subtitle-card">Quantidade: <label> <? echo $dadosCliente[0]['QT_PARALISADAS_FINANCIAMENTO'] ?> </label></span>
                                        <hr>
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FIN_PARALIZADOS_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <h6 class="title-card mt-1">Ação de Retomada</h6>
                                        <ul class="list-unstyled mb-0">
                                            <li class="d-inline-block mr-2 mb-1">
                                                <fieldset>
                                                    <div class="radio">
                                                        <input type="radio" name="FinancObraParalRadio" id="FinancObraParalRadioSim" value="1"
                                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FIN_PARALIZADOS_ACOMP'] == 0) {
                                                                echo 'disabled';
                                                            }
                                                            if (count($planoNegocio) > 0) {
                                                                if ($planoNegocio[0]['FIN_PARALIZADOS_NEGOCIACAO_ACAO'] === "1") {
                                                                    echo "checked";
                                                                }
                                                            }
                                                            ?>>
                                                        <label for="FinancObraParalRadioSim">Sim</label>
                                                    </div>
                                                </fieldset>
                                            </li>
                                            <li class="d-inline-block mr-2 mb-1">
                                                <fieldset>
                                                    <div class="radio">
                                                        <input type="radio" name="FinancObraParalRadio" id="FinancObraParalRadioNao" value="0"
                                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FIN_PARALIZADOS_ACOMP'] == 0) {
                                                                echo 'disabled';
                                                            }
                                                            if (count($planoNegocio) > 0) {
                                                                if ($planoNegocio[0]['FIN_PARALIZADOS_NEGOCIACAO_ACAO'] === "0") {
                                                                    echo "checked";
                                                                }
                                                            }
                                                            ?>>
                                                        <label for="FinancObraParalRadioNao">Não</label>
                                                    </div>
                                                </fieldset>
                                            </li>
                                        </ul>
                                        <textarea class="form-control" id="txtJustificativaFinancObraParal" name="txtJustificativaFinancObraParal" rows="6" placeholder=""
                                            <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FIN_PARALIZADOS_ACOMP'] == 0) {
                                                echo 'disabled';
                                            } ?>><?php if (count($planoNegocio) > 0) {
                                                        echo $planoNegocio[0]['FIN_PARALIZADOS_NEGOCIACAO_DESC'];
                                                    } ?></textarea>
                                    </div>

                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 2%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!------------------>
            <!-- RAting CAIXA -->
            <!------------------>
            <!-- <div class="col-3 pr-0" data-id="capag" id="capag">
            <div class="card card-animate" style="height: 95%">
                <div class="card-body">
                    <div class="d-flex justify-content-between body">
                        <div class="body-geral col">
                            <p class="title-card mb-0">RATING CAIXA</p>
                            <h2 class="title-card mt-0 mb-0">
                                <span id="vr_ing">
                                    
                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['CO_RATING_CAIXA'] ?>
                                        <label class="subtitle-card text-bold-300 ">(Nota)</label>
                                    </span>
                                </span>
                            </h2>
                            <span class="subtitle-card">Vencimento: <label> <? echo $dadosCliente[0]['DT_VALIDADE_AVALIACAO_RISCO'] ?> </label></span>
                            <hr>
                            <div class="row mb-0">
                                <div class="col">
                                    Expectativa:
                                    <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                        <span id="vr_ing">
                                           
                                            <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_RATING_PLANO'] ?></span>
                                        </span>
                                    </h6>
                                </div>
                            </div>
                            <h6 class="title-card mt-1">Ação</h6>
                            <ul class="list-unstyled mb-0">
                                <li class="d-inline-block mr-2 mb-1">
                                    <fieldset>
                                        <div class="radio">
                                            <input type="radio" name="ratingRadio" id="ratingRadioSim" value="1"
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_RATING_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>
                                            >
                                            <label for="ratingRadioSim">Sim</label>
                                        </div>
                                    </fieldset>
                                </li>
                                <li class="d-inline-block mr-2 mb-1">
                                    <fieldset>
                                        <div class="radio">
                                            <input type="radio" name="ratingRadio" id="ratingRadioNao" value="0"
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_RATING_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>
                                            >
                                            <label for="ratingRadioNao">Não</label>
                                        </div>
                                    </fieldset>
                                </li>
                            </ul>
                            <textarea class="form-control mt-0" id="txtJustificativaRating" name="txtJustificativaRating" rows="6" placeholder=""
                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_RATING_ACOMP'] == 0) {
                                    echo 'disabled';
                                } ?>
                            ></textarea>
                        </div>

                        <div class="avatar-card">
                            <span class="avatar-title">
                                <i class="fa-solid fa-ranking-star"></i>
                            </span>
                        </div>
                        <span class="data-referencia mt-2" id="dt_capag">Ago/2024</span>
                    </div>
                </div>
            </div>
        </div> -->
            <!-- end card-->
        </div>

        <hr>

        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">OGU</h5>
        </div>

        <div class="row">
            <!--------------------------------------->
            <!---------- OBRAS PARALIZADAS ---------->
            <!--------------------------------------->
            <div class="col-6 " data-id="roa" id="roa">
                <div class="card card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Obras Paralisadas</h6>

                                <div class="row">
                                    <div class="col-6">
                                        <h2 class="title-card mt-1 mb-0"> R$
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_PARALISADAS_FINANCIAMENTO'] ?> </span>
                                            </span>
                                        </h2>
                                        <span class="subtitle-card mt-0">(Valor)</span>
                                        <table class="table-caixa">
                                            <tr>
                                                <td>Quantidade:</td>
                                                <td id="qt_lotericas">
                                                    <!-- <span class="spinner-border text-secondary spinner-sm" role="status"></span> -->
                                                    <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QT_PARALISADAS_OGU'] ?> </span>
                                                </td>
                                            </tr>

                                        </table>
                                    </div>

                                    <div class="col-6 boder-vertical">
                                        <div class="row mb-0">
                                            <div class="col">
                                                Expectativa:
                                                <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                                    <span id="vr_ing">
                                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                        <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_OGU_PARALIZADOS_PLANO'] ?></span>
                                                    </span>
                                                </h6>
                                            </div>
                                        </div>
                                        <div class="body-geral">
                                            <h6 class="title-card mt-1">Ação de Retomada</h6>
                                            <ul class="list-unstyled mb-0">
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="oguObrasParalRadio" id="oguObrasParalRadioSim" value="1"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_OGU_PARALIZADOS_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['OGU_PARALIZADOS_NEGOCIACAO_ACAO'] === "1") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="oguObrasParalRadioSim">Sim</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                                <li class="d-inline-block mr-2 mb-1">
                                                    <fieldset>
                                                        <div class="radio">
                                                            <input type="radio" name="oguObrasParalRadio" id="oguObrasParalRadioNao" value="0"
                                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_OGU_PARALIZADOS_ACOMP'] == 0) {
                                                                    echo 'disabled';
                                                                }
                                                                if (count($planoNegocio) > 0) {
                                                                    if ($planoNegocio[0]['OGU_PARALIZADOS_NEGOCIACAO_ACAO'] === "0") {
                                                                        echo "checked";
                                                                    }
                                                                }
                                                                ?>>
                                                            <label for="oguObrasParalRadioNao">Não</label>
                                                        </div>
                                                    </fieldset>
                                                </li>
                                            </ul>
                                            <textarea class="form-control" id="txtJustificativaOguObrasParal" name="txtJustificativaOguObrasParal" rows="6" placeholder=""
                                                <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_OGU_PARALIZADOS_ACOMP'] == 0) {
                                                    echo 'disabled';
                                                } ?>><?php if (count($planoNegocio) > 0) {
                                                            echo $planoNegocio[0]['OGU_PARALIZADOS_NEGOCIACAO_DESC'];
                                                        } ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <!-- <i class="bx bxs-badge-dollarr"></i> -->
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

        </div>

        <hr>
        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">Investimento</h5>
        </div>
        <div class="row">
            <!---------------------------------->
            <!-- Fundos de investimento e CDB -->
            <!---------------------------------->
            <div class="col-4 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Fundos de investimento e CDB</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status">
                                            <?
                                            $valorFI1 = intval(str_replace('.', '', strstr($dadosCliente[0]['VR_FI_EXCETO_OGU'], ',', true)));
                                            $valorFI2 = intval(str_replace('.', '', strstr($dadosCliente[0]['VR_CDB'], ',', true)));
                                            $soma = $valorFI1 + $valorFI2;
                                            echo formatarNumero($soma);

                                            //echo ($dadosCliente[0]['VR_FI_EXCETO_OGU']) 
                                            //$valorasdf = strstr($dadosCliente[0]['VR_FI_EXCETO_OGU'],',',true);
                                            //echo intval(str_replace('.','',$valorasdf));
                                            ?>
                                        </span>
                                    </span>
                                    <!-- <h6 class="text-muted m-0" style="font-weight: 300;">(Valor)</h6> -->
                                    <h6 class="ff-secondary fw-semibold">
                                    </h6>
                                    <span class="text-secondary" role="status"> FUNDOS: R$ <? echo $dadosCliente[0]['VR_FI_EXCETO_OGU'] ?> *</span></br>
                                    <span class="text-secondary" role="status"> CDB: R$ <? echo $dadosCliente[0]['VR_CDB'] ?> *</span>
                                    <p class="text-secondary">* Exceto FIC Transf Vol</p>
                                </h2>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <!-- <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FI_CDB_PLANO'] ?></span> -->
                                                <span class="text-secondary" role="status"> <? echo 'Aumento de 5%. Esperado para dez/2025 é de R$' . formatarNumero($soma + ($soma * 0.05))  ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fiCDBRadio" id="fiCDBRadio0" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FI_CDB_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FI_CDB_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fiCDBRadio0">0</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fiCDBRadio" id="fiCDBRadio1" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FI_CDB_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FI_CDB_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fiCDBRadio1">1% a 5%</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fiCDBRadio" id="fiCDBRadio2" value="2"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FI_CDB_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }

                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FI_CDB_NEGOCIACAO_ACAO'] === "2") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fiCDBRadio2">maior 5%</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                </ul>
                                <textarea class="form-control" id="txtJustificativafiCDB" name="txtJustificativafiCDB" rows="6" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FI_CDB_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['FI_CDB_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

            <!---------------->
            <!-- Fundos a Fundo Saúde - FAF -->
            <!---------------->
            <div class="col-4 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Fundos a Fundo Saúde - FAF</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status">175,6 Mi</span>
                                        <h6 class="text-muted m-0" style="font-weight: 300;">(Valor últimos 12 meses)</h6>
                                    </span>

                                    <h6 class="ff-secondary fw-semibold mt-0">
                                        <span id="qt_consignado ">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['FAF_BANCO'] ?></span>
                                        </span>
                                    </h6>
                                </h2>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Valor Últimos 12 meses: </span>R$ <? echo $dadosCliente[0]['FAF_12_MESES'] ?></h6>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Vencimento: </span><? echo $dadosCliente[0]['FAF_VENCIMENTO'] ?></h6>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FAF_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fafRadio" id="fafRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FAF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FAF_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fafRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fafRadio" id="fafRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FAF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FAF_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fafRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaFaf" name="txtJustificativaFaf" rows="6" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FAF_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['FAF_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 2%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

            <!---------------->
            <!-- FUNDEB -->
            <!---------------->
            <div class="col-4 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">FUNDEB</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['FUNDEB_12_MESES'] ?></span>
                                        <h6 class="text-muted m-0" style="font-weight: 300;">(Valor últimos 12 meses)</h6>
                                    </span>

                                    <h6 class="ff-secondary fw-semibold mt-0">
                                        <span id="qt_consignado ">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['FUNDEB_BANCO'] ?></span>
                                        </span>
                                    </h6>
                                </h2>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_FUNDEB_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fundebRadio" id="fundebRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FUNDEB_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FUNDEB_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fundebRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="fundebRadio" id="fundebRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FUNDEB_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['FUNDEB_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="fundebRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaFundeb" name="txtJustificativaFundeb" rows="8" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_FUNDEB_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['FUNDEB_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

            <!---------------->
            <!-- QUOTA Educação -->
            <!---------------->
            <div class="col-4 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Quota Educação</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QUOTA_12_MESES'] ?></span>
                                        <h6 class="text-muted m-0" style="font-weight: 300;">(Valor últimos 12 meses)</h6>
                                    </span>

                                    <h6 class="ff-secondary fw-semibold mt-0">
                                        <span id="qt_consignado ">
                                            <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QUOTA_BANCO'] ?></span>
                                        </span>
                                    </h6>
                                </h2>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_QUOTA_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="quotaRadio" id="quotaRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_QUOTA_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['QUOTA_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="quotaRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="quotaRadio" id="quotaRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_QUOTA_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['QUOTA_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="quotaRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaQuota" name="txtJustificativaQuota" rows="6" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_QUOTA_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['QUOTA_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 2%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

            <!------------------------------>
            <!-- Transferências Especiais -->
            <!------------------------------>
            <div class="col-4 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Transferências Especiais</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card">R$</span>
                                    <span id="vr_consignado">
                                        <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['VR_TRANSF'] ?></span>
                                        <h6 class="text-muted m-0 font-small-2" style="font-weight: 300; ">(Valor últimos 12 meses)</h6>
                                    </span>
                                </h2>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Valor na CAIXA: R$</span> <? echo $dadosCliente[0]['VR_TRANSF_CAIXA'] ?></h6>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Marketshare : </span> <? echo $dadosCliente[0]['PERC_TRANSF_ESPECIAL_2024'] ?></h6>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_TRANSF_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="tranfEspecRadio" id="tranfEspecRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_TRANSF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['TRANSF_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="tranfEspecRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="tranfEspecRadio" id="tranfEspecRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_TRANSF_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['TRANSF_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="tranfEspecRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaTranfEspec" name="txtJustificativaTranfEspec" rows="4" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_TRANSF_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['TRANSF_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_rede_bancaria" style=" bottom: 5%;"><? echo $dadosCliente[0]['DATA_BASE_RECIPROCIDADE'] ?></span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->

        </div>

        <hr>
        <div class="row">
            <i class="bx bxs-tag-alt ml-1" style="margin-top:2px; color:#ed8c05"></i>
            <h5 class="ml-1">SOCIOAMBIENTAL E HABITAÇÃO</h5>
        </div>
        <div class="row">
            <!------------------------------->
            <!--- Pagamento a Fornecedor ---->
            <!------------------------------->
            <div class="col-3 pr-0 " data-id="roa" id="roa">
                <div class="card-animate " style="height: 95%">
                    <div class="card-body">
                        <div class=" justify-content-between body">
                            <div class="body-geral">
                                <h6 class="title-card mb-0">Habitação</h6>
                                <div class="row">
                                    <div class="col">
                                        <h2 class="title-card mt-1 mb-0"> <? echo $dadosCliente[0]['QTD_HABITACAO_TOTAL'] ?>
                                            <span id="vr_ing">
                                                <span class="text-secondary" role="status"> </span>
                                            </span>
                                        </h2>
                                        <span class="subtitle-card mt-0">(Total Empreendimentos)</span>
                                    </div>
                                </div>
                                <table class="table-caixa">
                                    <tr>
                                        <td>Total de Unidades Habitacionais :</td>
                                        <td id="qt_ag_caixa">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['UH_HABITACAO_TOTAL'] ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Empreendimentos MCMV :</td>
                                        <td id="qt_ag_caixa">
                                            <span class="text-secondary" role="status"> <? echo $dadosCliente[0]['QTD_MCMV_ATIVOS'] ?> </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>UH MCMV :</td>
                                        <td id="qt_cca">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['UH_MCMV_ATIVOS'] ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Empreendimentos PNHR :</td>
                                        <td id="qt_lotericas">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QTD_PNHR_ATIVOS'] ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>UH PNHR : </td>
                                        <td id="qt_cca">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['UH_PNHR_ATIVOS'] ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Empreendimentos Entidades : </td>
                                        <td id="qt_cca">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QTD_ENTIDADES_ATIVOS'] ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>UH Entidades : </td>
                                        <td id="qt_cca">
                                            <span class="text-secondary" role="status"><? echo $dadosCliente[0]['UH_ENTIDADES_ATIVOS'] ?></span>
                                        </td>
                                    </tr>

                                </table>
                            </div>
                        </div>
                        <div class="avatar-card">
                            <span class="avatar-title">
                                <!-- <i class="bx bxs-badge-dollarr"></i> -->
                            </span>
                        </div>
                        <span class="data-referencia" id="dt_cap_liq_dj">AGO/2024</span>
                    </div>
                    <p class="mb-0 card-info"></p>
                </div>
            </div>
            <!-- end card-->
            <!---------------->
            <!----- Selo ----->
            <!---------------->
            <div class="col-3 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Selo</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card"></span>
                                    <span id="vr_consignado">
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['NO_SELO'] ?></span>
                                    </span>
                                </h2>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Data Certificado: </span> <? echo $dadosCliente[0]['DT_CERTIFICADO'] ?></h6>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Vencimento : </span><? echo $dadosCliente[0]['DT_FIM_CERTIFICADO'] ?></h6>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_SELO_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="seloRadio" id="seloRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SELO_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['SELO_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="seloRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="seloRadio" id="seloRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SELO_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['SELO_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="seloRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaSelo" name="txtJustificativaSelo" rows="6" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SELO_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['SELO_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_consignado">AGO/2024</span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!--------------------------------------------------->
            <!----- Programas Regionais de Benefício Social ----->
            <!--------------------------------------------------->
            <div class="col-3 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Programas Regionais de Benefício Social</h6>
                                <h2 class="ff-secondary fw-semibold mt-1">
                                    <span class="subtitle-card"></span>
                                    <span id="vr_consignado">
                                        <span class="text-secondary" role="status"><? echo $dadosCliente[0]['QT_CONTRATO_PROGRAMA_REGIONAL_BENEFICIO_SOCIAIL_ICO'] ?></span>
                                    </span>

                                </h2>
                                <h6 class="subtitle-card mt-0">(Contratos)</h6>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">Possui Programa de Benefício Social no Selo : </span><? echo $dadosCliente[0]['SELO_SOCIAL'] ?></h6>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_SOCIAL_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="benefSocialRadio" id="benefSocialRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SOCIAL_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['SOCIAL_NEGOCIACAO_ACAO'] === "0") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="benefSocialRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="benefSocialRadio" id="benefSocialRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SOCIAL_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['SOCIAL_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="benefSocialRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaBenefSocial" name="txtJustificativaBenefSocial" rows="4" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_SOCIAL_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['SOCIAL_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_consignado">AGO/2024</span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
            <!-------------------------->
            <!-- Ação de Normalização -->
            <!-------------------------->
            <div class="col-3 pr-0" data-id="consignado" id="consignado">
                <div class="card card-animate" style="height: 95%">
                    <div class="card-body">
                        <div class="d-flex justify-content-between body">
                            <div class="body-geral col">
                                <h6 class="title-card mb-0">Ação de Normalização</h6>

                                <h6 class="subtitle-card mt-1"><span class="text-bold-300">Empreendimentos Críticos : </span> <? echo $dadosCliente[0]['QTD_HABITACAO_CRITICO'] ?></h6>
                                <h6 class="subtitle-card mt-0"><span class="text-bold-300">UH Críticos : </span><? echo $dadosCliente[0]['UH_HABITACAO_CRITICO'] ?></h6>
                                <hr>
                                <div class="row mb-0">
                                    <div class="col">
                                        Expectativa:
                                        <h6 class="ff-secondary fw-semibold mb-1 mt-0">
                                            <span id="vr_ing">
                                                <!-- <span class="spinner-border text-secondary" role="status"></span> -->
                                                <span class="text-secondary" role="status"> <? echo $dadosOportunidadeCliente[0]['OPORTUNIDADE_HABITACAO_CRIT_PLANO'] ?></span>
                                            </span>
                                        </h6>
                                    </div>
                                </div>
                                <h6 class="title-card mt-1">Ação de Negociação</h6>
                                <ul class="list-unstyled mb-0">
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="acaoNormRadio" id="acaoNormRadioSim" value="1"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_HABITACAO_CRIT_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['HABITACAO_CRIT_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    }
                                                    ?>>
                                                <label for="acaoNormRadioSim">Sim</label>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2 mb-1">
                                        <fieldset>
                                            <div class="radio">
                                                <input type="radio" name="acaoNormRadio" id="acaoNormRadioNao" value="0"
                                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_HABITACAO_CRIT_ACOMP'] == 0) {
                                                        echo 'disabled';
                                                    }
                                                    if (count($planoNegocio) > 0) {
                                                        if ($planoNegocio[0]['HABITACAO_CRIT_NEGOCIACAO_ACAO'] === "1") {
                                                            echo "checked";
                                                        }
                                                    } ?>>
                                                <label for="acaoNormRadioNao">Não</label>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>
                                <textarea class="form-control" id="txtJustificativaAcaoNorm" name="txtJustificativaAcaoNorm" rows="8" placeholder=""
                                    <? if ($dadosOportunidadeCliente[0]['OPORTUNIDADE_HABITACAO_CRIT_ACOMP'] == 0) {
                                        echo 'disabled';
                                    } ?>><?php if (count($planoNegocio) > 0) {
                                                echo $planoNegocio[0]['HABITACAO_CRIT_NEGOCIACAO_DESC'];
                                            } ?></textarea>
                            </div>
                            <div class="avatar-card">
                                <span class="avatar-title">
                                    <i class="fa-solid fa-donate"></i>
                                </span>
                            </div>
                            <span class="data-referencia" id="dt_consignado">AGO/2024</span>
                        </div>
                        <p class="mb-0 card-info"></p>
                    </div>
                </div>
            </div>
            <!-- end card-->
        </div>
    </form>
</div>



<script>
    $(document).ready(function() {


        // Seleciona todos os radio buttons na página
        const radioButtons = document.querySelectorAll('input[type="radio"]');

        const form = document.getElementById('form-cadastro-plano-negocio');
        const sendButton = document.getElementById('submitEnviar');

        // Função para verificar se todos os campos habilitados estão preenchidos
        function validarFormulario() {
            const inputsHabilitados = form.querySelectorAll('textarea:enabled, input:enabled[type="radio"]:checked');
            let preenchido = true;

            inputsHabilitados.forEach(input => {
                if (input.type === "radio") {
                    const radios = form.querySelectorAll(`input[name="${input.name}"]:enabled`);
                    const algumMarcado = Array.from(radios).some(radio => radio.checked);
                    if (!algumMarcado) {
                        preenchido = false;
                    }
                } else if (input.value.trim() === '') {
                    preenchido = false;
                }
            });

            // Habilita ou desabilita o botão de envio
            sendButton.disabled = !preenchido;
        }

        // Escuta mudanças nos campos do formulário
        form.addEventListener('input', validarFormulario);
        form.addEventListener('change', validarFormulario);

        // Chama a validação inicial para desabilitar o botão, se necessário
        validarFormulario();

        //Adiciona evento de mudança a todos os radio buttons
        radioButtons.forEach(function(radio) {
            radio.addEventListener('change', function() {
                updatePlaceholder(radio);
            });
        });

        // $('#submitEnviar').on('click', function() {
        //     console.log("validado");
        //     sendButton.disabled = true;
        //     // chamada AJAX para enviar os dados ao servidor
        //     $.ajax({
        //         type: 'POST',
        //         url: '<? echo CxUrl::site('rep_eleitos:api:enviarPlanoNegocio') ?>',
        //         data: $('#form-cadastro-plano-negocio').serialize(),
        //         success: function(response) {

        //             alert('Dados salvos com sucesso!');
        //             window.location.reload();
        //         },
        //         error: function() {
        //             alert('Ocorreu um erro ao salvar os dados.');
        //         }
        //     });
        // });

        //ação de salvar quando é adicionado uma nova ação ao componente
        $('#submitRascunho').on('click', function() {
            const submiADD = document.getElementById("submitRascunho");

            console.log("validado");
            submiADD.disabled = true;
            // chamada AJAX para enviar os dados ao servidor
            $.ajax({
                type: 'POST',
                url: '<? echo CxUrl::site('rep_eleitos:api:salvarPlanoNegocio') ?>',
                data: $('#form-cadastro-plano-negocio').serialize(),
                success: function(response) {

                    Swal.fire({
                        icon: "success",
                        title: 'Sucesso!',
                        text: 'Foi salvo o Rascunho do Plano de Negócio.',
                        confirmButtonClass: 'btn btn-success',
                    }).then(function(result) {
                        if (result.value) {
                            window.location.reload();
                        }
                    })


                },
                error: function() {
                    alert('Ocorreu um erro ao salvar os dados.');
                }
            });
        });

        $('#submitEnviar').on('click', function() {
            Swal.fire({
                title: 'Deseja Enviar?',
                text: "Depois de enviar, não poderá ser editado!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Enviar!',
                confirmButtonClass: 'btn btn-primary',
                cancelButtonClass: 'btn btn-danger ml-1',
                buttonsStyling: false,
            }).then(function(result) {
                if (result.value) {
                    sendButton.disabled = true;
                    // chamada AJAX para enviar os dados ao servidor
                    $.ajax({
                        type: 'POST',
                        url: '<? echo CxUrl::site('rep_eleitos:api:enviarPlanoNegocio') ?>',
                        data: $('#form-cadastro-plano-negocio').serialize(),
                        success: function(response) {
                            Swal.fire({
                                icon: "success",
                                title: 'Enviado!',
                                text: 'Foi salvo o Plano de Negócio.',
                                confirmButtonClass: 'btn btn-success',
                            }).then(function(result) {
                                if (result.value) {
                                    window.location.href = "<?php echo CxUrl::site('rep_eleitos:acao_index') ?>";
                                }
                            })

                        },
                        error: function() {
                            Swal.fire({
                                title: 'Error',
                                text: 'Tente novamente, pois não conseguimos salvar enviar.',
                                icon: 'error',
                                confirmButtonClass: 'btn btn-success',
                            })
                        }
                    });
                }
            })
        });
    });


    // Função que atualiza o placeholder do textarea com base na escolha
    function updatePlaceholder(radioBtn) {
        const group = radioBtn.closest('.card'); // Obtém o grupo da pergunta atual
        const textarea = group.querySelector('textarea'); // Encontra o textarea correspondente

        if (radioBtn.value === "0") {
            textarea.placeholder = "Justificativa para a não realização dessa ação.";
        } else if (radioBtn.value === "1") {
            textarea.placeholder = "Descreva de como será essa ação de negociação.";
        }
    }
</script>