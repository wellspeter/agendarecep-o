<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];

// if($matricula == '145234'){
//   $lotacao_fisica =  6753;
// }

//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . ' ../../../daos/indexDao.php');
$dao = new indexDAO();

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula_homol($matricula,$dataEnvio);

//echo $acessoUsuarioPorMatricula;

if(count($acessoUsuarioPorMatricula) > 0){
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
}else{
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}


//echo var_dump($acessoUsuarioPorMatricula);

if(count($dadosArvoreAcesso) > 0){
  $listaMuncSeg = $dao->buscaListaMunicipio($dadosArvoreAcesso[0]['NU_UNIDADE'],$dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO']);
  //echo var_dump($listaMuncSeg);

  if(count($listaMuncSeg) > 0){

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Acompanhamento da Recepção</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title "><?php echo $dadosArvoreAcesso[0]['NO_UNIDADE'] ?></h4>
        </div>

        <div class="card-body ">
          <div class="table-responsive">
            <table id="table-municipios" class="table zero-configuration mb-0">
              <thead>
                <tr>
                  <th>Prior.</th>
                  <th>Cliente</th>
                  <th>Segmento </th> 
                  <th>UNIDADE</th>
                  <th class="text-center">Última Ação de Relacionamento</th>
                  <th>Qtd de Ações Rec</th>
                  <th>Plano de Negócios</th>
                  <!-- <th>Capacitação</th> -->
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($listaMuncSeg as $resultado) {
                  echo "<tr>";
                  if ($resultado['MUNICIPIO_PRIORITARIO'] == 0) {
                    echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle danger font-small-1 ml-1 '></i></td>";
                  } else {
                    echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle success font-small-1 ml-1' style='margin-top: 5px;'></i></td>";
                  }
                  echo "<td class='text-bold-600 pr-0'>" . $resultado['NOME_MUNICIPIO'] . "</td>";
                  echo "<td>" . $resultado['NOME_SEGMENTO'] . "</td>"; // verificar

                  if ($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE']  == 'S') {
                    echo "<td>" . $resultado['NOME_GIGOV'] . "</td>";
                  } else {
                    echo "<td>" . $resultado['NOME_SEG'] . "</td>";
                  }

                  echo "<td class='text-bold-600 text-center'><span>" . $resultado['ULTIMA_ACOES'] . "</span></td>";
                  echo "<td><p class=''>" . $resultado['QTD_ACOES_REALIZADAS'] . " - 11</p></td>";
                  if ($resultado['MUNICIPIO_PRIORITARIO'] == 1) {
                    if ($resultado['PLANO_NEGOCIO'] == 0) {
                      echo " <td class='text-danger'><i class='bx bx-error-circle ml-3'></i></td>";
                    }else if($resultado['PLANO_NEGOCIO'] == 1) {
                        echo " <td class='text-warning'><i class='bx bxs-check-circle ml-3'></i></td>";
                    }else{
                      echo " <td class='text-success'><i class='bx bxs-check-circle ml-3'></i></td>";
                    };
                  } else {
                    echo " <td></td>";
                  }

                 // echo " <td class=''><p class='ml-2'>" . $resultado['QTD_ACOES_CAPACITACOES_REALIZADAS'] . " - 3</p></td>";
                  echo ("<td>
                                  <div class='dropdown'>
                                    <span class='bx bx-dots-vertical-rounded font-medium-3 dropdown-toggle nav-hide-arrow cursor-pointer ml-1' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false' role='menu'></span>
                                    <div class='dropdown-menu dropdown-menu-right'>
                                      <a class='dropdown-item' href='" . CxUrl::site('rep_eleitos:acoes_relac', ['municip' => $resultado['CNPJ']]) . "'><i class='bx bx-edit-alt mr-1'></i> Ações de Relacionamento</a>");
                  if ($resultado['MUNICIPIO_PRIORITARIO'] > 0) {
                    echo "<a class='dropdown-item' href='" . CxUrl::site('rep_eleitos:plano_negocio', ['municip' => $resultado['CNPJ']]) . "'><i class='bx bx-file mr-1'></i> Plano de Negócio</a>";
                  }
                  echo ("  </div>
                                  </div>
                                </td>");
                  echo "</tr>";
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- 
-------------------------------------- MODAL DAS AÇÕES DE RECEPÇÃO PARA EDIÇÃO --------------------------------------------------
 -->
<div class="modal fade" id="recepcaoModal" tabindex="-1" role="dialog" aria-labelledby="editarAcoesModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form id="form-edicao-acao" method="post" action="javascript:void(0)">
        <div class="modal-header border-bottom">
          <h5 class="modal-title" id="tituloAcaoEditar">Bem vindo a Recepção de Eleitos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <i class="bx bx-x"></i>
          </button>
        </div>
        <div class="modal-body" style="padding:0px;">
          <div class="">
            <div id="carousel-example-card" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carousel-example-card" data-slide-to="0" class="active" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="1" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="2" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="3" style="color: #000000;"></li>
                <li data-target="#carousel-example-card" data-slide-to="4" style="color: #000000;"></li>
              </ol>
              <div class="carousel-inner rounded-0" role="listbox">
                <div class="carousel-item active">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem1.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem2.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem3.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem4.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="<?php echo CxUrl::statics() ?>/app-assets/images/recepcao_eleitos/acoes/Imagem5.png" class="d-block w-100" alt="">
                </div>
              </div>
              <a class="carousel-control-prev" href="#carousel-example-card" role="button" data-slide="prev">
                <span class="bx bx-chevron-left icon-prev" aria-hidden="true" style="color: #000000;"></span>
                <span class="sr-only">Voltar</span>
              </a>
              <a class="carousel-control-next" href="#carousel-example-card" role="button" data-slide="next">
                <span class="bx bx-chevron-right icon-next" aria-hidden="true" style="color: #000000;"></span>
                <span class="sr-only">Próximo</span>
              </a>
            </div>
            <div class="card-body">
              <div class="checkbox checkbox-primary checkbox-shadow">
                <input type="checkbox" id="checkboxNaoVerModal" onchange="atualizarVisualizacaoModalInicial();">
                <label for="checkboxNaoVerModal">Não ver mais essa mensagem</label>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>


<script>
  function verificaLocalstorage() {
    // //verificando se existe o elemento no localStorage
    let checkExist;
    checkExist = localStorage.getItem("naoVerModalBemVindoAcoes");

    if (!checkExist) {
      console.log("não tem dados");
      localStorage.setItem("naoVerModalBemVindoAcoes", 1);
      return 1;
    }

    return checkExist;
  }

  function atualizarVisualizacaoModalInicial() {
    // Verifica se tem ou nao o elemento no localstorage
    verificaLocalstorage();
    // verifica o valor retornado, se o valor vier comom 0, o cliente ja informou que nao quer ver mais o modal
    if (verificaLocalstorage() == 1) {
      // abre o modal
      $('#recepcaoModal').modal('show');
      // pega o evento do click do check para adicionar o valor para o 
      const checkNaoVerMaisModal = document.getElementById("checkboxNaoVerModal");
      if (this.checkNaoVerMaisModal) {
        localStorage.setItem("naoVerModalBemVindoAcoes", 1);
      } else {
        localStorage.setItem("naoVerModalBemVindoAcoes", 0);
      }

    }
  }

  $(document).ready(function() {
    verificaLocalstorage();
    if (verificaLocalstorage() == 1) {
      // abre o modal
      $('#recepcaoModal').modal('show');
    }


    /****************************************
     *       js of zero configuration        *
     ****************************************/

    $('.zero-configuration').DataTable();

    /********************************************
     *        js of Order by the grouping        *
     ********************************************/

    var groupingTable = $('.row-grouping').DataTable({
      "columnDefs": [{
        "visible": false,
        "targets": 2
      }],
      "order": [
        [2, 'asc']
      ],
      "displayLength": 10,
      "drawCallback": function(settings) {
        var api = this.api();
        var rows = api.rows({
          page: 'current'
        }).nodes();
        var last = null;

        api.column(2, {
          page: 'current'
        }).data().each(function(group, i) {
          if (last !== group) {
            $(rows).eq(i).before(
              '<tr class="group"><td colspan="5">' + group + '</td></tr>'
            );

            last = group;
          }
        });
      }
    });

    $('.row-grouping tbody').on('click', 'tr.group', function() {
      var currentOrder = groupingTable.order()[0];
      if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
        groupingTable.order([2, 'desc']).draw();
      } else {
        groupingTable.order([2, 'asc']).draw();
      }
    });

    /*************************************
     *       js of complex headers        *
     *************************************/

    $('.complex-headers').DataTable();


    /*****************************
     *       js of Add Row        *
     ******************************/

    var t = $('.add-rows').DataTable();
    var counter = 2;

    $('#addRow').on('click', function() {
      t.row.add([
        counter + '.1',
        counter + '.2',
        counter + '.3',
        counter + '.4',
        counter + '.5'
      ]).draw(false);

      counter++;
    });


    /**************************************************************
     * js of Tab for COLUMN SELECTORS WITH EXPORT AND PRINT OPTIONS *
     ***************************************************************/

    $('.dataex-html5-selectors').DataTable({
      dom: 'Bfrtip',
      buttons: [{
          extend: 'copyHtml5',
          exportOptions: {
            columns: [0, ':visible']
          }
        },
        {
          extend: 'pdfHtml5',
          exportOptions: {
            columns: ':visible'
          }
        },
        {
          text: 'JSON',
          action: function(e, dt, button, config) {
            var data = dt.buttons.exportData();

            $.fn.dataTable.fileSave(
              new Blob([JSON.stringify(data)]),
              'Export.json'
            );
          }
        },
        {
          extend: 'print',
          exportOptions: {
            columns: ':visible'
          }
        }
      ]
    });

    /**************************************************
     *       js of scroll horizontal & vertical        *
     **************************************************/

    $('.scroll-horizontal-vertical').DataTable({
      "scrollY": 200,
      "scrollX": true
    });
  });
</script>

<?
}}else{

  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo Contém Permissão para essa Página!</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';


}


?>