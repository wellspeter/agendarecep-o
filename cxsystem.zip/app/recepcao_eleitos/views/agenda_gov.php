<?php

  $dadosUsuario =   CxSession::get('usuario');
  $matricula = $dadosUsuario['nu_matricula'];
  //echo $dadosUsuario['nu_lotacao_fisica'];

  $cnpjMunicipio = CxRequest::params('municip');
  //$cnpjMunicipio = '18338178000102';
  //echo $cnpjMunicipio;

  require_once(__DIR__ .'/../daos/acoesDao.php');
  $dao = new acoesDAO();

  $buscaArvoreAcesso = $dao -> buscaArvoreAcesso($matricula);
  $dadosCliente = $dao -> buscaDadosCliente($cnpjMunicipio);
?>

<style>
</style> 

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class=""></small>Agenda GOV - </small> <?php echo $dadosCliente[0]['NOME_MUNICIPIO']?>, <?php echo $dadosCliente[0]['sg_uf']?></h4>
    </div>
  </div>
</div> 
<script>
 
 <? echo 'const acoes_banco_cliente = '.json_encode($acoesCliente,JSON_UNESCAPED_UNICODE).';' ?>

  $(document).ready(function($) {

   
  });

</script>