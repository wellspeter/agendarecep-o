<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ .'/../daos/indexDao.php');
$dao = new indexDAO();

$dadosArvoreAcesso = $dao -> buscaArvoreAcesso($matricula);
//echo var_dump($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE']);
//$listaMuncSeg = $dao-> buscaListaMunicipiorPorSeg($dadosArvoreAcesso[0]['NU_UNIDADE']);

 if($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == "S"){
   $listaMuncSeg = $dao-> buscaListaMunicipiorPorSeg($dadosArvoreAcesso[0]['NU_UNIDADE']);
 }else{
   $listaMuncSeg = $dao-> buscaListaMunicipiorPorGigov($dadosArvoreAcesso[0]['NU_UNIDADE']);
 }


//echo var_dump($listaMuncSeg);

?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Agenda GOV</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title "><?php echo $dadosArvoreAcesso[0]['NO_UNIDADE']?></h4>
        </div>
      </div>
    </div>
  </div>
</div>