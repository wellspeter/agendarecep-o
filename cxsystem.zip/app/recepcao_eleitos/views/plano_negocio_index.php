<?php

$dadosUsuario =   CxSession::get('usuario');
$matricula = $dadosUsuario['nu_matricula'];
$lotacao_fisica = $dadosUsuario['nu_lotacao_fisica'];
//echo $matricula;
//echo $dadosUsuario['nu_lotacao_fisica'];font-small

require_once(__DIR__ . '/../daos/indexDao.php');
$dao = new indexDAO();

$datainsert = new Datetime();
$dataEnvio = $datainsert->format('Y-m-d');
$acessoUsuarioPorMatricula = $dao->buscaArvoreAcessoPorMatricula($matricula,$dataEnvio);

if(count($acessoUsuarioPorMatricula) > 0){
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($acessoUsuarioPorMatricula[0]['NU_UNIDADE']);
}else{
  $dadosArvoreAcesso = $dao->buscaArvoreAcessoPorUnidade($lotacao_fisica);
}

$listaMuncSeg = $dao->buscaListaMunicipio($dadosArvoreAcesso[0]['NU_UNIDADE'], $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO']);
//echo var_dump($listaMuncSeg);
if($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'GEEGO' || 
    $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'SEG' || 
    $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'SR' ||
    $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'SEV' ||
    $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'GIGOV' ||
    $dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE_TIPO'] == 'SEH' ){

    if(count($listaMuncSeg) > 0){  
?>

<div class="container-fluid">
  <div class="row align-items-center  mb-2">
    <div class="col-12">
      <h4 class="">Acompanhamento da Recepção</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title "><?php echo $dadosArvoreAcesso[0]['NO_UNIDADE'] ?></h4>
        </div>

        <div class="card-body ">
          <div class="table-responsive">
            <table id="table-extended-success" class="table zero-configuration mb-0">
              <thead>
                <tr>
                  <th>Prior.</th>
                  <th>Cliente</th>
                  <th>Segmento </th>
                  <?php if ($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == 'S') {
                    echo '<th>GIGOV</th>';
                  } else {
                    echo '<th>SEG</th>';
                  } ?>
                  <th>Plano de Negócios</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($listaMuncSeg as $resultado) {

                  if ($resultado['MUNICIPIO_PRIORITARIO'] == 1) {
                    echo "<tr>";
                    if ($resultado['MUNICIPIO_PRIORITARIO'] == 0) {
                      echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle danger font-small-1 ml-1 '></i></td>";
                    } else {
                      echo "<td class='text-bold-600 pr-0'><i class='bx bxs-circle success font-small-1 ml-1' style='margin-top: 5px;'></i></td>";
                    }
                    echo "<td class='text-bold-600 pr-0'>" . $resultado['NOME_MUNICIPIO'] . "</td>";
                    echo "<td>" . $resultado['NOME_SEGMENTO'] . "</td>";


                    if ($dadosArvoreAcesso[0]['IDENTIFICACAO_UNIDADE'] == 'S') {
                      echo "<td>" . $resultado['NOME_GIGOV'] . "</td>";
                    } else {
                      echo "<td>" . $resultado['NOME_SEG'] . "</td>";
                    }


                    if ($resultado['PLANO_NEGOCIO'] == 0) {
                      echo " <td class='text-danger'><i class='bx bx-error-circle ml-3'></i></td>";
                    } else if ($resultado['PLANO_NEGOCIO'] == 1) {
                      echo " <td class='text-warning'><i class='bx bxs-check-circle ml-3'></i></td>";
                    } else {
                      echo " <td class='text-success'><i class='bx bxs-check-circle ml-3'></i></td>";
                    };


                    echo '<td><a href="' . CxUrl::site('rep_eleitos:plano_negocio', ['municip' => $resultado['CNPJ']]) . '"><i class="badge-circle badge-circle-light-secondary bx bx-right-arrow-alt font-medium-1"></i></a></td>';
                  }
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>

</script>

<?
}else{
  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo Contém municípios vinculados!</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}


}else{
  echo '<div class="container-fluid">';
  echo '<div class="row align-items-center  mb-2">';
  echo '<div class="col-12">';
  echo '<h4 class="">Nâo Contém Permissão para essa Página!</h4>';
  echo '</div>';
  echo '</div>';
  echo '</div>';
}

?>