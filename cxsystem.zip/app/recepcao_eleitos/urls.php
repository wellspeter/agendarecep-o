<?php

/**********************Principal Recepção Eleitos *********************** */
CxRouter::addUrl(
  'recepcao_eleitos', 
  'recepcao_eleitos/views/index.php', 
  $name = 'rep_eleitos:index'
);

/********************** Ação *********************** */
CxRouter::addUrl(
    'recepcao_eleitos/acoes_relacionamento', 
    'recepcao_eleitos/views/acoes_index.php', 
    $name = 'rep_eleitos:acao_index'
);

CxRouter::addUrl(
    'recepcao_eleitos/acoes_relacionamento/<municip>', 
    'recepcao_eleitos/views/acoes_relacionamento.php', 
    $name = 'rep_eleitos:acoes_relac'
);

// Relatorios

CxRouter::addUrl(
  'recepcao_eleitos/acoes_acompanhamento', 
  'recepcao_eleitos/views/acoes_acompanhamento_rel.php', 
  $name = 'rep_eleitos:acoes_acompanhamento_rel'
);



// HOMOLOGACAO
CxRouter::addUrl(
  'recepcao_eleitos/acoes_relacionamento_homol', 
  'recepcao_eleitos/views/homologacao/acoes_index.php', 
  $name = 'rep_eleitos:acao_index_homol'
);

CxRouter::addUrl(
  'recepcao_eleitos/acoes_relacionamento_homol/<municip>', 
  'recepcao_eleitos/views/homologacao/acoes_relacionamento.php', 
  $name = 'rep_eleitos:acoes_relac_homol'
);




/********************** Plano de negocio *********************** */
CxRouter::addUrl(
  'recepcao_eleitos/plano_negocio', 
  'recepcao_eleitos/views/plano_negocio_index.php', 
  $name = 'rep_eleitos:plano_negocio_index'
);

CxRouter::addUrl(
  'recepcao_eleitos/plano_negocio/<municip>', 
  'recepcao_eleitos/views/plano_negocio.php', 
  $name = 'rep_eleitos:plano_negocio'
);

//HOMOLOGACAO
CxRouter::addUrl(
  'recepcao_eleitos/plano_negocio_homol', 
  'recepcao_eleitos/views/homologacao/plano_negocio_index.php', 
  $name = 'rep_eleitos:plano_negocio_index_homol'
);

CxRouter::addUrl(
  'recepcao_eleitos/plano_negocio_homol/<municip>', 
  'recepcao_eleitos/views/homologacao/plano_negocio.php', 
  $name = 'rep_eleitos:plano_negocio_homol'
);

/********************** Agenda gov *********************** */
CxRouter::addUrl(
  'recepcao_eleitos/agenda_gov', 
  'recepcao_eleitos/views/agenda_gov_index.php', 
  $name = 'rep_eleitos:agenda_gov_index'
);

CxRouter::addUrl(
  'recepcao_eleitos/agenda_gov/<municip>', 
  'recepcao_eleitos/views/agenda_gov.php', 
  $name = 'rep_eleitos:agenda_gov'
);

/********************** Painel de Gestão e Acompanhamento *********************** */
CxRouter::addUrl(
  'recepcao_eleitos/painel_gestao_acompanhamento', 
  'recepcao_eleitos/views/painel_gestao_index.php', 
  $name = 'rep_eleitos:painel_gestao_index'
);



/*******************************
 * 
 * Chamadas de API
 * 
 ******************************/

 CxRouter::addApiUrl(
    'recepcao_eleitos/inseriracao', 
    'recepcao_eleitos/api/salvarAcaoRecepcao.php', 
    $name = 'rep_eleitos:api:salvarAcaoRecepcao'
  );

  CxRouter::addApiUrl(
    'recepcao_eleitos/edicaoAcaoRecepcao', 
    'recepcao_eleitos/api/salvarEdicaoAcaoRecepcao.php', 
    $name = 'rep_eleitos:api:salvarEdicaoAcaoRecepcao'
  );

  CxRouter::addApiUrl(
    'recepcao_eleitos/salvar-Contatos-Recepcao', 
    'recepcao_eleitos/api/salvarContatosRecepcao.php', 
    $name = 'rep_eleitos:api:salvarContatosRecepcao'
  );


  //API PLANO DE NEGOCIOS

  CxRouter::addApiUrl(
    'recepcao_eleitos/inserir-plano-negocio', 
    'recepcao_eleitos/api/salvarPlanoNegocio.php', 
    $name = 'rep_eleitos:api:salvarPlanoNegocio'
  );

  CxRouter::addApiUrl(
    'recepcao_eleitos/enviar-plano-negocio', 
    'recepcao_eleitos/api/enviarPlanoNegocio.php', 
    $name = 'rep_eleitos:api:enviarPlanoNegocio'
  );
//-----------------
  CxRouter::addApiUrl(
    'eventos/salvarContEvento', 
    'recepcao_eleitos/api/salvarContEvento.php', 
    $name = 'rep_eleitos:api:salvarContEvento'
  );
  CxRouter::addApiUrl(
    'eventos/confirmarContEvento', 
    'recepcao_eleitos/api/confirmarContEvento.php', 
    $name = 'rep_eleitos:api:confirmarContEvento'
  );






  


  




  