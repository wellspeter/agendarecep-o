<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class acoesDAO extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }
    
    public function buscaArvoreAcessoPorMatricula($matricula,$data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = ".$matricula."
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '".$data."'
	            AND DT_FIM_ACESSO > '".$data."'
        ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorUnidade($unidade)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                WHERE NU_UNIDADE = :unidade AND DT_FIM_ACESSO IS NULL AND [ID_TIPO_ACESSO] = 'U'
                GROUP BY 
                     [NU_MATRICULA]
                    ,[NU_UNIDADE]
                    ,[NO_UNIDADE]
                    ,[DT_INICIO_ACESSO]
                    ,[DT_FIM_ACESSO]
                    ,[IDENTIFICACAO_UNIDADE]
                    ,[IDENTIFICACAO_UNIDADE_TIPO]
                    ,[DT_INSERT]
                    ,[ID_TIPO_ACESSO]
                    ,[NIVEL_ACESSO_EDITAR]
                    ,[NIVEL_ACESSO_CONSULTAR]";
        return $this->buscar_lista($sql, array(':unidade' => $unidade));
    }

    

    public function buscaListAcoes()
    {
        $sql = "SELECT * FROM [DB5131_GOV].[recepcao].[T001_ACOES]";
        return $this->buscar_lista($sql,array());
    }

    public function buscaDadosCliente($cnpj)
    {
        $sql = "SELECT 
                    cc.[co_cnpj] AS CNPJ
                    ,cc.[no_municipio] AS NOME_MUNICIPIO
                    ,cc.[sg_uf]
                FROM 
                    [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as CC
                WHERE 
                    cc.CO_CNPJ = :cnpj
        ";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    } 

    public function buscaAcoesCliente($cnpj)
    {
        $sql = "with cte as ( 
                    SELECT 
                        cc.[co_cnpj] AS CNPJ
                        ,cc.[no_municipio] AS NOME_MUNICIPIO
                        ,cc.[sg_uf]
                    FROM 
                        [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as CC
                    WHERE 
                        cc.CO_CNPJ = :cnpj
                    ), cte_ultima_acoes as  (
                        SELECT
                            cte.*
                            ,CASE
                                    WHEN a.NO_ACOES IS NULL THEN '-'
                                    ELSE a.NO_ACOES
                                END AS ULTIMA_ACOES
                            ,r.[ID_REALIZADO_ACOES]
                            ,r.[ID_ACOES]
                            ,r.[DT_DA_ACAO]
                            ,r.[NU_PARTIC_CAIXA]
                            ,r.[NU_PARTIC_EXTERNO]
                            ,r.[DE_INTERACAO_OCORRIDA]
                            ,r.[LINK_1]
                            ,r.[LINK_2]
                            ,r.[DT_INSERT_ACAO]
                            ,r.[NU_MATRICULA_INSERT]
                            ,r.[ACAO_VALIDADA]
                            ,r.[ACAO_VALIDADA_JUST]
                            ,ROW_NUMBER() over(PARTITION BY  R.ID_ACOES ORDER BY R.DT_INSERT_ACAO DESC) as ORD_ACOES
                        FROM  cte as cte
                        left join [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] as R on r.co_cnpj = cte.cnpj
                        LEFT join [DB5131_GOV].[recepcao].[T001_ACOES] as a on r.ID_ACOES = a.ID_ACOES
                    ),cte_filtro_acoes as (
                        select 
                            cte.*
                        from 
                            cte_ultima_acoes as cte 
                        WHERE 
                            ORD_ACOES = 1
                    )

                select 
                    a.[ID_ACOES]
                    ,a.[NO_ACOES]
                    ,a.[DT_INICIO_ACAO]
                    ,a.[DT_FIM_ACAO]
                    ,a.[NO_GRUPO]
                    ,a.[NU_GRUPO]
                    ,cte.[ID_REALIZADO_ACOES]
                    ,cte.[DT_DA_ACAO]
                    ,cte.[NU_PARTIC_CAIXA]
                    ,cte.[NU_PARTIC_EXTERNO]
                    ,cte.[DE_INTERACAO_OCORRIDA]
                    ,cte.[LINK_1]
                    ,cte.[LINK_2]
                    ,cte.[DT_INSERT_ACAO]
                    ,cte.[NU_MATRICULA_INSERT] 
                    ,cte.[ACAO_VALIDADA]
                    ,cte.[ACAO_VALIDADA_JUST]
                FRom  
                    [DB5131_GOV].[recepcao].[T001_ACOES] as a
                    left join cte_filtro_acoes as cte on cte.[ID_ACOES] = a.[ID_ACOES]
                order by 
                    a.NU_GRUPO, A.DT_INICIO_ACAO, A.DT_FIM_ACAO ";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    }

    
    public function buscaAcoesClienteAgenda($cnpj)
    {
        $sql = "SELECT TOP (1000) 
                    ra.*
                    ,a.[NO_ACOES]
                    ,a.[DT_INICIO_ACAO]
                    ,a.[DT_FIM_ACAO]
                    ,a.[NO_GRUPO]
                ,[NU_GRUPO]
                FROM 
                    [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] as ra
                    inner join [DB5131_GOV].[recepcao].[T001_ACOES] as a on ra.ID_ACOES = a.ID_ACOES
                where 
                    a.NU_GRUPO = 3
                    and ra.co_cnpj = :cnpj ";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    }

    // Função para salvar a nova ação
    public function inserirAcao($data) {

        $sql = "INSERT INTO [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                    ([ID_ACOES]
                    ,[CO_CNPJ]
                    ,[DT_DA_ACAO]
                    ,[NU_PARTIC_CAIXA]
                    ,[NU_PARTIC_EXTERNO]
                    ,[DE_INTERACAO_OCORRIDA]
                    ,[LINK_1]
                    ,[LINK_2]
                    ,[DT_INSERT_ACAO]
                    ,[NU_MATRICULA_INSERT]
                    ,[ACAO_VALIDADA])
                VALUES 
                    (".$data['idAcaoObrigatoria'].",
                    '".$data['cnpj']."',
                    '".$data['dataAcao']."', 
                    ".$data['selectQtdParticCaixa'].", 
                    ".$data['selectQtdExterno'].", 
                    '".$data['txtAcaoDescricao']."', 
                    '". $data['txtLinkArquivo1']."', 
                    '". $data['txtLinkArquivo2']."', 
                    '".$data['datainsert']."',
                    ".$data['matricula'].",".$data['revisao'].")";

        // Retornando true se a inserção foi bem-sucedida
        $this-> inserir($sql,array());
        return  true ;

        //return $sql;
    }


    // Função para salvar a nova ação
    public function inserirContatosMunicipio($data) {

        $sql = "INSERT INTO [DB5131_GOV].[recepcao].[T009_CONTATOS_MUNICIPIOS]
                    ([CO_CNPJ]
                    ,[nomeCont1]
                    ,[cargoCont1]
                    ,[celularCont1]
                    ,[emailCont1]
                    ,[nomeCont2]
                    ,[cargoCont2]
                    ,[celularCont2]
                    ,[emailCont2]
                    ,[nomeCont3]
                    ,[cargoCont3]
                    ,[celularCont3]
                    ,[emailCont3]
                    ,[nomeCont4]
                    ,[cargoCont4]
                    ,[celularCont4]
                    ,[emailCont4]
                    ,[nomeCont5]
                    ,[cargoCont5]
                    ,[celularCont5]
                    ,[emailCont5]
                    ,[DT_INSERT]
                    ,[NU_MATRICULA_INSERT])
                VALUES
                    (:cnpj
                    ,:nomeCont1
                    ,:cargoCont1
                    ,:celularCont1
                    ,:emailCont1
                    ,:nomeCont2
                    ,:cargoCont2
                    ,:celularCont2
                    ,:emailCont2
                    ,:nomeCont3
                    ,:cargoCont3
                    ,:celularCont3
                    ,:emailCont3
                    ,:nomeCont4
                    ,:cargoCont4
                    ,:celularCont4
                    ,:emailCont4
                    ,:nomeCont5
                    ,:cargoCont5
                    ,:celularCont5
                    ,:emailCont5
                    ,:DT_INSERT
                    ,:NU_MATRICULA_INSERT)";

        // Retornando true se a inserção foi bem-sucedida
        return $this-> inserir($sql,array(
            ':cnpj' => $data['cnpj']

            ,':nomeCont1' => $data['nomeCont1']
            ,':cargoCont1' => $data['cargoCont1']
            ,':celularCont1' => $data['celularCont1']
            ,':emailCont1' => $data['emailCont1']

            ,':nomeCont2' => $data['nomeCont2']
            ,':cargoCont2' => $data['cargoCont2']
            ,':celularCont2' => $data['celularCont2']
            ,':emailCont2' => $data['emailCont2']

            ,':nomeCont3' => $data['nomeCont3']
            ,':cargoCont3' => $data['cargoCont3']
            ,':celularCont3' => $data['celularCont3']
            ,':emailCont3' => $data['emailCont3']

            ,':nomeCont4' => $data['nomeCont4']
            ,':cargoCont4' => $data['cargoCont4']
            ,':celularCont4' => $data['celularCont4']
            ,':emailCont4' => $data['emailCont4']

            ,':nomeCont5' => $data['nomeCont5']
            ,':cargoCont5' => $data['cargoCont5']
            ,':celularCont5' => $data['celularCont5']
            ,':emailCont5' => $data['emailCont5']

            ,':DT_INSERT' => $data['datainsert']
            ,':NU_MATRICULA_INSERT' => $data['matricula']
        ));

        //return  true ;

        //return $sql;
    }

    public function getContatosMinicipios($cnpj)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T009_CONTATOS_MUNICIPIOS]
                where 
                co_cnpj = :cnpj1 
                and dt_insert = (
                    SELECT max(dt_insert)
                    FROM [DB5131_GOV].[recepcao].[T009_CONTATOS_MUNICIPIOS]
                    where co_cnpj = :cnpj2)
                ";
        return $this->buscar_lista($sql,array(':cnpj1' => $cnpj,':cnpj2' => $cnpj));
    } 








}

