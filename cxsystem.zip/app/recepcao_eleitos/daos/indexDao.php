<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class indexDAO extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }

    public function buscaArvoreAcessoPorMatricula($matricula,$data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = ".$matricula."
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '".$data."'
	            AND DT_FIM_ACESSO > '".$data."'
        ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorMatricula_homol($matricula, $data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = ".$matricula."
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '".$data."'
	            AND DT_FIM_ACESSO > '".$data."'
        ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }

    public function buscaArvoreAcessoPorUnidade($unidade)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                WHERE 
                    NU_UNIDADE = :unidade 
                    AND DT_FIM_ACESSO IS NULL 
                    AND [ID_TIPO_ACESSO] = 'U'
                GROUP BY 
                     [NU_MATRICULA]
                    ,[NU_UNIDADE]
                    ,[NO_UNIDADE]
                    ,[DT_INICIO_ACESSO]
                    ,[DT_FIM_ACESSO]
                    ,[IDENTIFICACAO_UNIDADE]
                    ,[IDENTIFICACAO_UNIDADE_TIPO]
                    ,[DT_INSERT]
                    ,[ID_TIPO_ACESSO]
                    ,[NIVEL_ACESSO_EDITAR]
                    ,[NIVEL_ACESSO_CONSULTAR]";
        return $this->buscar_lista($sql, array(':unidade' => $unidade));
    }



    public function buscaListaMunicipio($nu_unidade, $tipo_unidade)
    {
        $sql = "WITH cte AS (
                    SELECT
                        cc.[co_cnpj] AS CNPJ
                        ,cc.[no_cliente] AS NOME_MUNICIPIO
                        ,cc.[no_segmento_curto] AS NOME_SEGMENTO
                        ,cc.[no_gigov] AS NOME_GIGOV
                        ,cc.no_seg AS NOME_SEG
                        ,cc.no_sr AS NOME_SR
                        ,CASE
                            WHEN mp.co_cnpj IS NULL THEN 0
                            ELSE 1
                        END AS MUNICIPIO_PRIORITARIO
                    FROM
                        [DB5131_GOV].[dbo].[T002_CLIENTE_MINIC_ESTADO] AS CC
                        LEFT JOIN [DB5131_GOV].[recepcao].[T003_MUNICIPIOS_PRIORITARIOS] AS MP 
                            ON MP.co_cnpj = cc.co_cnpj
                    WHERE
                        ic_tipo = 'M' ";

        if ($nu_unidade != 5131 || $nu_unidade != 5130 || $nu_unidade != 5247) {
            // GETAT = 5130
            // GESUN = 5247
            if ($tipo_unidade == 'SEG') {
                $sql = $sql . " and cc.co_seg = " . $nu_unidade;
            } elseif ($tipo_unidade == 'SR') {
                $sql = $sql . " and cc.co_sr = " . $nu_unidade;
            } elseif ($tipo_unidade == 'GIGOV') {
                $sql = $sql . " and cc.co_gigov = " . $nu_unidade;
            } elseif ($tipo_unidade == 'SEV') {
                $sql = $sql . " and cc.co_sev = " . $nu_unidade;
            } elseif ($tipo_unidade == 'PV') {
                $sql = $sql . " and cc.co_pv = " . $nu_unidade;
            } elseif ($tipo_unidade == 'SEH') {
                $sql = $sql . " and cc.co_seh = " . $nu_unidade;
            } elseif ($tipo_unidade == 'SUV') {
                $sql = $sql . " and cc.co_suv = " . $nu_unidade;
            }
        }

        $sql = $sql . "    ), cte_ultima_acoes as  (
                SELECT
                    cte.*
                    ,CASE 
                        WHEN a.NO_ACOES IS NULL THEN '-' 
                        ELSE a.NO_ACOES 
                    END AS ULTIMA_ACOES
                    ,R.ACAO_VALIDADA
                    ,ROW_NUMBER() OVER(PARTITION BY cte.cnpj ORDER BY R.DT_INSERT_ACAO DESC) AS ORD_ACOES
                FROM 
                    cte
                    LEFT JOIN [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] AS R 
                        ON R.co_cnpj = cte.cnpj
                    LEFT JOIN [DB5131_GOV].[recepcao].[T001_ACOES] AS A 
                        ON R.ID_ACOES = A.ID_ACOES           

                ),cte_filtro_acoes as (

                    select 
                        cte.CNPJ
                        ,cte.NOME_MUNICIPIO
                        ,cte.NOME_SEGMENTO
                        ,cte.NOME_GIGOV
                        ,cte.NOME_SR
                        ,cte.MUNICIPIO_PRIORITARIO
                        ,cte.ULTIMA_ACOES
                        ,cte.NOME_SEG
                        ,cte.ACAO_VALIDADA
                    from 
                        cte_ultima_acoes as cte 
                    WHERE 
                        ORD_ACOES = 1
                ),cte_qtd_acoes as ( 
                    select 
                        cte.CNPJ 
                        ,cte.NOME_MUNICIPIO 
                        ,cte.NOME_SEGMENTO 
                        ,cte.NOME_GIGOV 
                        ,cte.NOME_SEG 
                        ,cte.NOME_SR 
                        ,cte.MUNICIPIO_PRIORITARIO 
                        ,cte.ULTIMA_ACOES 
                        ,cte.ACAO_VALIDADA
                        ,0 as CAPTACAO 
                        ,CASE 
                            WHEN r.contador IS NULL THEN 0 ELSE r.contador 
                            END AS QTD_ACOES_REALIZADAS 
                    from 
                        cte_filtro_acoes as cte 
                        left join ( 
                            SELECT 
                                [CO_CNPJ] 
                                ,count(RA.ID_ACOES) OVER (PARTITION BY [CO_CNPJ]) as contador 
                            FROM 
                                [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] as RA
                                inner join [DB5131_GOV].[recepcao].[T001_ACOES] AS A ON RA.ID_ACOES = A.ID_ACOES
                            where 
                                A.NU_GRUPO = 1
                            group by [CO_CNPJ],RA.ID_ACOES
                        ) as R on r.co_cnpj = cte.cnpj 
                    group by 
                        cte.CNPJ 
                        ,cte.NOME_MUNICIPIO 
                        ,cte.NOME_SEGMENTO 
                        ,cte.NOME_GIGOV 
                        ,cte.NOME_SEG 
                        ,cte.NOME_SR 
                        ,cte.MUNICIPIO_PRIORITARIO 
                        ,cte.ULTIMA_ACOES 
                        ,cte.ACAO_VALIDADA
                        ,r.contador 
                        ,r.CO_CNPJ 
                ),cte_plano_negocio as (
                    SELECT 
                        cte.*
                        ,ROW_NUMBER() over(PARTITION BY  cte.cnpj ORDER BY PN.dt_insert DESC ) as ORD_PN
                        ,PN.DT_INSERT
                        ,CASE 
                            WHEN pn.STATUS is null  THEN 0 
                            ELSE pn.STATUS
                            END AS PLANO_NEGOCIO
                        FROM 
                            cte_qtd_acoes as cte
                            left join [DB5131_GOV].[recepcao].[T008_PLANO_NEGOCIO] AS PN ON CTE.CNPJ = PN.CO_CNPJ
                ),cte_filtro_plano_negocio AS (
                    select 
                        cte.CNPJ 
                        ,cte.NOME_MUNICIPIO 
                        ,cte.NOME_SEGMENTO 
                        ,cte.NOME_GIGOV 
                        ,cte.NOME_SEG 
                        ,cte.NOME_SR 
                        ,cte.MUNICIPIO_PRIORITARIO 
                        ,cte.ULTIMA_ACOES 
                        ,cte.CAPTACAO 
                        ,cte.QTD_ACOES_REALIZADAS 
                        ,cte.PLANO_NEGOCIO
                        ,cte.ACAO_VALIDADA

                    FROM cte_plano_negocio AS cte
                    where ORD_PN = 1

                ),

                -- CTE para agregar as ações 5, 14 e 18 e descobrir seu status de validação
                cte_acoes_validada AS (
                    SELECT
                        ra.co_cnpj,
                        -- Se a ACAO_VALIDADA for NULL, significa que não foi feita; se = 0 ou 1, ele registra
                        MAX(CASE WHEN ra.ID_ACOES = 5  THEN ra.ACAO_VALIDADA END) AS acao_5,
                        MAX(CASE WHEN ra.ID_ACOES = 14 THEN ra.ACAO_VALIDADA END) AS acao_14,
                        MAX(CASE WHEN ra.ID_ACOES = 18 THEN ra.ACAO_VALIDADA END) AS acao_18
                    FROM
                        [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] ra
                    GROUP BY
                        ra.co_cnpj
                )
                    SELECT
                        cte.*,
                        ----------------------------------------------------------------------------
                        -- (7) CASE para definir a nova coluna ACAO_VALIDADA conforme sua regra:
                        --     - 0 se todas as 3 ações são NULL (Aguardando Revisão ( Aguardando a revisão do SEG ))
                        --     - 2 se todas são 1 (todas validadas)
                        --     - 1 em qualquer outro cenário (parcial)
                        ----------------------------------------------------------------------------
                        CASE
                        WHEN acv.acao_5   = 0 
                            AND acv.acao_14 = 0
                            AND acv.acao_18 = 0 
                        THEN 0
                        
                        WHEN acv.acao_5 = 1
                            AND acv.acao_14 = 1
                            AND acv.acao_18 = 1
                        THEN 2
                        
                        ELSE 1
                        END AS ACAO_VALIDADA,

                        ----------------------------------------------------------------------------
                        -- A contagem de “capacitacoes” (ID_ACOES IN (10,12,13)) continua igual
                        ----------------------------------------------------------------------------
                        CASE
                        WHEN r.contador IS NULL THEN 0
                        ELSE r.contador
                        END AS QTD_ACOES_CAPACITACOES_REALIZADAS

                    FROM
                        cte_filtro_plano_negocio AS cte

                        -- (8) JOIN para contar quantas ações estão em (10,12,13)
                        LEFT JOIN (
                            SELECT
                                [CO_CNPJ],
                                COUNT(ID_ACOES) OVER (PARTITION BY [CO_CNPJ]) AS contador
                            FROM
                                [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                            WHERE
                                ID_ACOES IN (10, 12, 13)
                            GROUP BY
                                [CO_CNPJ], 
                                ID_ACOES
                        ) AS R
                            ON R.co_cnpj = cte.cnpj

                        -- (9) JOIN com o CTE que mapeia as 3 ações (5,14,18)
                        LEFT JOIN cte_acoes_validada acv
                            ON acv.co_cnpj = cte.cnpj

                    ORDER BY
                        cte.MUNICIPIO_PRIORITARIO DESC

        ";
        return $this->buscar_lista($sql, array());
        //return $sql;
    }

    public function buscaListaMunicipiorPorSeg($seg)
    {
        $sql = "
            with cte as ( SELECT 
                cc.[co_cnpj] AS CNPJ1
                ,cc.[no_municipio] AS NOME_MUNICIPIO
                ,cc.[no_segmento_curto] AS NOME_SEGMENTO
                ,cc.[sg_gigov] AS NOME_GIGOV
                ,cc.no_seg as NOME_SEG
                ,CASE
                    WHEN mp.co_cnpj IS NULL THEN 0
                    ELSE 1
                END AS MUNICIPIO_PRIORITARIO
            FROM 
                [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as CC
                left join [DB5131_GOV].[recepcao].[T003_MUNICIPIOS_PRIORITARIOS] as MP on MP.co_cnpj = cc.co_cnpj
            WHERE 
                cc.CO_CNPJ = cc.co_cnpj_meta_principal
                and cc.co_seg = :cod_seg
            )
            , cte_ultima_acoes as  (
                SELECT
                    cte.*
                    ,CASE
                            WHEN a.NO_ACOES IS NULL THEN '-'
                            ELSE a.NO_ACOES
                        END AS ULTIMA_ACOES
                    ,ROW_NUMBER() over(PARTITION BY  cte.cnpj ORDER BY R.ID_ACOES desc) as ORD_ACOES
                    ,r.ID_ACOES
                FROM  cte as cte
                left join [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] as R on r.co_cnpj = cte.cnpj
                LEFT join [DB5131_GOV].[recepcao].[T001_ACOES] as a on r.ID_ACOES = a.ID_ACOES
                
            )
            --select * from cte_ultima_acoes
            ,cte_filtro_acoes as (

                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.NOME_SEG
                from 
                    cte_ultima_acoes as cte 
                WHERE 
                    ORD_ACOES = 1
            )
            ,cte_qtd_acoes as (
                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                
                    ,CASE
                        WHEN r.contador IS NULL THEN 0
                        ELSE r.contador
                    END AS QTD_ACOES_REALIZADAS
                from 
                    cte_filtro_acoes as cte 
                    left join (
                        SELECT 
                            [CO_CNPJ]
                            ,count(ID_ACOES) OVER (PARTITION BY [CO_CNPJ])  as contador
                        FROM [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                        group by [CO_CNPJ],ID_ACOES
                    ) as R on r.co_cnpj = cte.cnpj
                group by 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,r.contador
                    ,r.CO_CNPJ
            )
                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.QTD_ACOES_REALIZADAS
                    ,CASE
                        WHEN r.contador IS NULL THEN 0
                        ELSE r.contador
                    END AS QTD_ACOES_CAPACITACOES_REALIZADAS
                    ,0 as PLANO_NEGOCIO
                from 
                    cte_qtd_acoes as cte 
                    left join (
                        SELECT 
                            [CO_CNPJ]
                            ,count(ID_ACOES) OVER (PARTITION BY [CO_CNPJ])  as contador
                        FROM [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                        where ID_ACOES in (10,12,13)
                        group by [CO_CNPJ],ID_ACOES
                    ) as R on r.co_cnpj = cte.cnpj
                group by 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.QTD_ACOES_REALIZADAS
                    ,r.contador
                    ,r.CO_CNPJ
                ORDER BY cte.MUNICIPIO_PRIORITARIO DESC

        ";
        //return $this->buscar_lista($sql,array());
        return $this->buscar_lista($sql, array(':cod_seg' => $seg));
        // $listaTeste = array(
        //     array("CODIGO"=>"431","NOME"=>"Selo CAIXA Gestão Sustentável"),
        //     array("CODIGO"=>"267","NOME"=>"Folha Gratuita"),
        //     array("CODIGO"=>"413","NOME"=>"Quota - Salário Educação")
        //  );
    }

    public function buscaListaMunicipiorPorGigov($nu_gigov)
    {
    
        $sql = "
            with cte as ( SELECT 
                cc.[co_cnpj] AS CNPJ
                ,cc.[no_municipio] AS NOME_MUNICIPIO
                ,cc.[no_segmento_curto] AS NOME_SEGMENTO
                ,cc.[sg_gigov] AS NOME_GIGOV
                ,cc.no_seg as NOME_SEG
                ,CASE
                    WHEN mp.co_cnpj IS NULL THEN 0
                    ELSE 1
                END AS MUNICIPIO_PRIORITARIO
            FROM 
                [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as CC
                left join [DB5131_GOV].[recepcao].[T003_MUNICIPIOS_PRIORITARIOS] as MP on MP.co_cnpj = cc.co_cnpj
            WHERE 
                cc.CO_CNPJ = cc.co_cnpj_meta_principal
                and co_gigov = :cod_gigov

            )
            , cte_ultima_acoes as  (
                SELECT
                    cte.*
                    ,CASE
                            WHEN a.NO_ACOES IS NULL THEN '-'
                            ELSE a.NO_ACOES
                        END AS ULTIMA_ACOES
                    ,ROW_NUMBER() over(PARTITION BY  cte.cnpj ORDER BY R.ID_ACOES desc) as ORD_ACOES
                    ,r.ID_ACOES
                FROM  cte as cte
                left join [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES] as R on r.co_cnpj = cte.cnpj
                LEFT join [DB5131_GOV].[recepcao].[T001_ACOES] as a on r.ID_ACOES = a.ID_ACOES
                
            )
            --select * from cte_ultima_acoes
            ,cte_filtro_acoes as (

                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.NOME_SEG
                from 
                    cte_ultima_acoes as cte 
                WHERE 
                    ORD_ACOES = 1
            )
            ,cte_qtd_acoes as (
                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                
                    ,CASE
                        WHEN r.contador IS NULL THEN 0
                        ELSE r.contador
                    END AS QTD_ACOES_REALIZADAS
                from 
                    cte_filtro_acoes as cte 
                    left join (
                        SELECT 
                            [CO_CNPJ]
                            ,count(ID_ACOES) OVER (PARTITION BY [CO_CNPJ])  as contador
                        FROM [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                        group by [CO_CNPJ],ID_ACOES
                    ) as R on r.co_cnpj = cte.cnpj
                group by 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,r.contador
                    ,r.CO_CNPJ
            )
                select 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.QTD_ACOES_REALIZADAS
                    ,CASE
                        WHEN r.contador IS NULL THEN 0
                        ELSE r.contador
                    END AS QTD_ACOES_CAPACITACOES_REALIZADAS
                    ,0 as PLANO_NEGOCIO
                from 
                    cte_qtd_acoes as cte 
                    left join (
                        SELECT 
                            [CO_CNPJ]
                            ,count(ID_ACOES) OVER (PARTITION BY [CO_CNPJ])  as contador
                        FROM [DB5131_GOV].[recepcao].[T002_REALIZADO_ACOES]
                        where ID_ACOES in (10,12,13)
                        group by [CO_CNPJ],ID_ACOES
                    ) as R on r.co_cnpj = cte.cnpj
                group by 
                    cte.CNPJ
                    ,cte.NOME_MUNICIPIO
                    ,cte.NOME_SEGMENTO
                    ,cte.NOME_GIGOV
                    ,cte.NOME_SEG
                    ,cte.MUNICIPIO_PRIORITARIO
                    ,cte.ULTIMA_ACOES
                    ,cte.QTD_ACOES_REALIZADAS
                    ,r.contador
                    ,r.CO_CNPJ
                ORDER BY cte.MUNICIPIO_PRIORITARIO DESC

        ";
        //return $this->buscar_lista($sql,array());
        return $this->buscar_lista($sql, array(':cod_gigov' => $nu_gigov));
        // $listaTeste = array(
        //     array("CODIGO"=>"431","NOME"=>"Selo CAIXA Gestão Sustentável"),
        //     array("CODIGO"=>"267","NOME"=>"Folha Gratuita"),
        //     array("CODIGO"=>"413","NOME"=>"Quota - Salário Educação")
        //  );
    }
}
