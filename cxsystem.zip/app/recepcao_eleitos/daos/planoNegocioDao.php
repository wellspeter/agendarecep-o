<?php

/**
 * Classe que possui as regras para buscar as informações no banco de dados.
 * No construtor precisamos chamar o construtor da classe pai e passar qual banco de dados queremos usar.
 * (O mesmo que foi configurado em configs.php) 
 * 
 * A classe pai DAO está definida no arquivo lib/dao/dao.php e é incluída no index.php principal.
 * Essa classe possui 5 métodos básicos para acesso ao banco de dados. Esses métodos foram criados para simplificar
 * as consultas, sem precisar ficar sempre tratando os possíveis erros e retornos.
 * 
 * São esses os 5 metodos:
 * 
 * buscar_lista($sql, $params) 
 * -> Retorna um array com a lista de registros retornados pela query $sql
 * -> $params é um array com as variaveis a serem trocadas na preparação da query (evitar SQL Injection)
 * exemplo de uso logo abaixo em busca_unidade_rede_atacado, utilizamos o padrão do PDO de :nome_variavel para as substituições). 
 * 
 * buscar_primeiro($sql, $params)
 * -> Retorna o primeiro registro da query $sql
 * 
 * inserir($sql, $params)
 * -> Retorna true ou false, função para informar sql de INSERT
 * 
 * atualizar($sql, $params)
 * -> Retorna true ou false, função para informar sql de UPDATE
 * 
 * deletar($sql, $params)
 * -> Retorna true ou false, função para informar sql de DELETE
 */

class planoNegocioDao extends DAO
{
    public function __construct()
    {
        parent::__construct('DATABASE');
    }

    public function buscaArvoreAcessoPorMatricula($matricula,$data)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = ".$matricula."
                AND [ID_TIPO_ACESSO] = 'M'
                AND DT_INICIO_ACESSO < '".$data."'
	            AND DT_FIM_ACESSO > '".$data."'
        ";
        return $this->buscar_lista($sql,array());
        //return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }
    
    public function buscaArvoreAcesso($matricula)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                where nu_matricula = :matricula
        ";
        return $this->buscar_lista($sql,array(':matricula' => $matricula));
    }
    

    public function buscaArvoreAcessoPorUnidade($unidade)
    {
        $sql = "SELECT *
                FROM [DB5131_GOV].[recepcao].[T004_ARVORE_ACESSO]
                WHERE NU_UNIDADE = :unidade AND DT_FIM_ACESSO IS NULL AND [ID_TIPO_ACESSO] = 'U'
                GROUP BY 
                     [NU_MATRICULA]
                    ,[NU_UNIDADE]
                    ,[NO_UNIDADE]
                    ,[DT_INICIO_ACESSO]
                    ,[DT_FIM_ACESSO]
                    ,[IDENTIFICACAO_UNIDADE]
                    ,[IDENTIFICACAO_UNIDADE_TIPO]
                    ,[DT_INSERT]
                    ,[ID_TIPO_ACESSO]
                    ,[NIVEL_ACESSO_EDITAR]
                    ,[NIVEL_ACESSO_CONSULTAR]";
        return $this->buscar_lista($sql, array(':unidade' => $unidade));
    }


    public function buscaDadosCliente($cnpj)
    {
        $sql = "SELECT 
                    cc.[co_cnpj] AS CNPJ
                    ,cc.[no_municipio] AS NOME_MUNICIPIO
                    ,cc.[sg_uf]
                FROM 
                    [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as CC
                WHERE 
                    cc.CO_CNPJ = :cnpj
        ";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    } 

    public function buscaDadosOportunidadeCliente($cnpj)
    {
        $sql = "SELECT 
                   *
                FROM 
                    [DB5131_GOV].[recepcao].[T006_DADOS_OPORT] 
                WHERE 
                    CO_CNPJ = :cnpj";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    } 
    
    public function buscaDadosClientePlanoNegocio($cnpj)
    {
        $sql = "SELECT 
                    cc.no_municipio
                    ,cc.sg_uf
                    ,cc.no_segmento_curto
                    ,cc.no_regiao
                    ,cc.[co_pv]
                    ,cc.[no_pv]
                    ,cc.[co_sr]
                    ,cc.[no_sr]
                    ,cc.[co_seg]
                    ,cc.[no_seg]
                    ,cc.[co_seh]
                    ,cc.[no_seh]
                    ,cc.[co_sev]
                    ,cc.[no_sev]
                    ,cc.[co_suv]
                    ,cc.[no_suv]
                    ,cc.[co_gigov]
                    ,cc.[sg_gigov]
                    ,cc.[no_gigov]
                    ,cc.[co_regov]
                    ,cc.[no_regov]
                    ,dgp.*
                FROM 
                    [DB5131_GOV].[recepcao].[T005_DADOS_GERAIS_RECEPCAO] as dgp
                    inner join [DB5131_GOV].[dbo].[T001_CLIENTE_COMPLETO] as cc on dgp.CO_CNPJ = cc.co_cnpj
                WHERE 
                    dgp.CO_CNPJ = :cnpj
        ";
        return $this->buscar_lista($sql,array(':cnpj' => $cnpj));
    } 

    public function salvarRascunho($data)
    {
        $sql = "INSERT INTO [DB5131_GOV].[recepcao].[T008_PLANO_NEGOCIO]
           ([CO_CNPJ]
           ,[DT_INSERT]
           ,[NU_MATRICULA_INSERT]
           ,[STATUS]
           ,[ANALISE_PLANO_GOVERNO]
           ,[ANALISE_NOTICIA_DEBATE]
           ,[FOLHA_NEGOCIACAO_ACAO]
           ,[FOLHA_NEGOCIACAO_DESC]
           ,[CPP_NEGOCIACAO_ACAO]
           ,[CPP_NEGOCIACAO_DESC]
           ,[CPP_NEGOCIACAO_QTD]
           ,[ARREC_NEGOCIACAO_ACAO]
           ,[ARREC_NEGOCIACAO_DESC]
           ,[COB_NEGOCIACAO_ACAO]
           ,[COB_NEGOCIACAO_DESC]
           ,[PAG_FOR_NEGOCIACAO_ACAO]
           ,[PAG_FOR_NEGOCIACAO_DESC]
           ,[CONSIG_NEGOCIACAO_ACAO]
           ,[CONSIG_NEGOCIACAO_DESC]
           ,[ESTEIRA_NEGOCIACAO_ACAO]
           ,[ESTEIRA_NEGOCIACAO_DESC]
           ,[FIN_PARALIZADOS_NEGOCIACAO_ACAO]
           ,[FIN_PARALIZADOS_NEGOCIACAO_DESC]
           ,[OGU_PARALIZADOS_NEGOCIACAO_ACAO]
           ,[OGU_PARALIZADOS_NEGOCIACAO_DESC]
           ,[FI_CDB_NEGOCIACAO_ACAO]
           ,[FI_CDB_NEGOCIACAO_DESC]
           ,[FAF_NEGOCIACAO_ACAO]
           ,[FAF_NEGOCIACAO_DESC]
           ,[FUNDEB_NEGOCIACAO_ACAO]
           ,[FUNDEB_NEGOCIACAO_DESC]
           ,[QUOTA_NEGOCIACAO_ACAO]
           ,[QUOTA_NEGOCIACAO_DESC]
           ,[TRANSF_NEGOCIACAO_ACAO]
           ,[TRANSF_NEGOCIACAO_DESC]
           ,[SELO_NEGOCIACAO_ACAO]
           ,[SELO_NEGOCIACAO_DESC]
           ,[SOCIAL_NEGOCIACAO_ACAO]
           ,[SOCIAL_NEGOCIACAO_DESC]
           ,[HABITACAO_CRIT_NEGOCIACAO_ACAO]
           ,[HABITACAO_CRIT_NEGOCIACAO_DESC])
     VALUES
           (:cnpj
           ,:datainsert
           ,:matricula
           ,:statusPlanoNegocio
           ,:analisePlanoGoverno
           ,:analiseNoticiasGoverno
           ,:folhaRadio
           ,:justificativaFolha
           ,:cppRadio
           ,:justificativaCPP
           ,:qtdCPP
           ,:arrecadacaoRadio
           ,:justificativaArrecadacao
           ,:cobrancaRadio
           ,:justificativaCobranca
           ,:pagFornRadio
           ,:justificativapagForn
           ,:sgrRadio
           ,:justificativaSGR
           ,:financEsteiraRadio
           ,:justificativaFinancEsteira
           ,:financObraParalRadio
           ,:justificativaFinancObraParal
           ,:oguObrasParalRadio
           ,:justificativaOguObrasParal
           ,:fiCDBRadio
           ,:justificativafiCDB
           ,:fafRadio
           ,:justificativaFaf
           ,:fundebRadio
           ,:justificativaFundeb
           ,:quotaRadio
           ,:justificativaQuota
           ,:tranfEspecRadio
           ,:justificativaTranfEspec
           ,:seloRadio
           ,:justificativaSelo
           ,:benefSocialRadio
           ,:justificativaBenefSocial
           ,:acaoNormRadio
           ,:justificativaAcaoNorm)";

        return $this->buscar_lista($sql,array(
            ':cnpj' => $data['cnpj'],
            ':datainsert' => $data['datainsert'],
            ':matricula' => $data['matricula'],
            ':statusPlanoNegocio' => $data['statusPlanoNegocio'],

            ':analisePlanoGoverno' => $data['analisePlanoGoverno'],
            ':analiseNoticiasGoverno' => $data['analiseNoticiasGoverno'],

            ':folhaRadio' => $data['folhaRadio'],
            ':justificativaFolha' => $data['justificativaFolha'],

            ':cppRadio' => $data['cppRadio'],
            ':justificativaCPP' => $data['justificativaCPP'],
            ':qtdCPP' => $data['qtdCPP'],

            ':arrecadacaoRadio' => $data['arrecadacaoRadio'],
            ':justificativaArrecadacao' => $data['justificativaArrecadacao'],

            ':cobrancaRadio' => $data['cobrancaRadio'],
            ':justificativaCobranca' => $data['justificativaCobranca'],

            ':pagFornRadio' => $data['pagFornRadio'],
            ':justificativapagForn' => $data['justificativapagForn'],

            ':sgrRadio' => $data['sgrRadio'],
            ':justificativaSGR' => $data['justificativaSGR'],

            ':financEsteiraRadio' => $data['financEsteiraRadio'],
            ':justificativaFinancEsteira' => $data['justificativaFinancEsteira'],

            ':financObraParalRadio' => $data['financObraParalRadio'],
            ':justificativaFinancObraParal' => $data['justificativaFinancObraParal'],
        
            ':oguObrasParalRadio' => $data['oguObrasParalRadio'],
            ':justificativaOguObrasParal' => $data['justificativaOguObrasParal'],

            ':fiCDBRadio' => $data['fiCDBRadio'],
            ':justificativafiCDB' => $data['justificativafiCDB'],

            ':fafRadio' => $data['fafRadio'],
            ':justificativaFaf' => $data['justificativaFaf'],

            ':fundebRadio' => $data['fundebRadio'],
            ':justificativaFundeb' => $data['justificativaFundeb'],

            ':quotaRadio' => $data['quotaRadio'],
            ':justificativaQuota' => $data['justificativaQuota'],

            ':tranfEspecRadio' => $data['tranfEspecRadio'],
            ':justificativaTranfEspec' => $data['justificativaTranfEspec'],

            ':seloRadio' => $data['seloRadio'],
            ':justificativaSelo' => $data['justificativaSelo'],

            ':benefSocialRadio' => $data['benefSocialRadio'],
            ':justificativaBenefSocial' => $data['justificativaBenefSocial'],

            ':acaoNormRadio' => $data['acaoNormRadio'],
            ':justificativaAcaoNorm' => $data['justificativaAcaoNorm'],
        ));
    } 

    public function getPlanoNegocio($cnpj)
    {
        $sql = "SELECT * FROM [DB5131_GOV].[recepcao].[T008_PLANO_NEGOCIO]
                where CO_CNPJ = :cnpj1 AND DT_INSERT = (
                    SELECT MAX(DT_INSERT)
                    FROM [DB5131_GOV].[recepcao].[T008_PLANO_NEGOCIO]
                    where CO_CNPJ = :cnpj2
                ) ";
        return $this->buscar_lista($sql,array(':cnpj1' => $cnpj,':cnpj2' => $cnpj));
    } 
    
}

