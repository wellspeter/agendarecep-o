<?php

class CxConfig
{
    private static $base_path = '';
    private static $statics_folder = 'statics';
    private static $media_folder = 'media';
    private static $app_folder = 'app';
    private static $layouts_folder = 'layouts';
    private static $configs = array();
    private static $debug = false;

    public static function init()
    {
        if (CxConfig::$debug) {
            ini_set('display_errors', 1);
            ini_set('display_startup_erros', 1);
            error_reporting(E_ALL);
        }

        date_default_timezone_set('America/Sao_Paulo');
        header('Content-Type: text/html; charset=UTF-8');

        ini_set('mssql.charset', 'UTF-8');
        ini_set('max_execution_time', 1200);
        set_time_limit(0);
        setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'portuguese');
    }

    public static function base_path($base_path = null)
    {
        if ($base_path !== null) {
            CxConfig::$base_path = $base_path;
        }

        return CxConfig::$base_path;
    }

    public static function configs($key = null)
    {
        if ($key === null) {
            return CxConfig::$configs;
        }

        return isset(CxConfig::$configs[$key]) ? CxConfig::$configs[$key] : null;
    }

    public static function set_config($key, $value)
    {
        CxConfig::$configs[$key] = $value;
    }

    public static function unset_config($key)
    {
        unset(CxConfig::$configs[$key]);
    }

    public static function debug($debug = null)
    {
        if ($debug !== null) {
            CxConfig::$debug = $debug;
        }

        return CxConfig::$debug;
    }

    public static function statics_folder($folder = null)
    {
        if ($folder !== null) {
            CxConfig::$statics_folder = $folder;
        }

        return CxConfig::$statics_folder;
    }

    public static function media_folder($folder = null)
    {
        if ($folder !== null) {
            CxConfig::$media_folder = $folder;
        }

        return CxConfig::$media_folder;
    }

    public static function app_folder($folder = null)
    {
        if ($folder !== null) {
            CxConfig::$app_folder = $folder;
        }

        return CxConfig::$app_folder;
    }

    public static function layouts_folder($folder = null)
    {
        if ($folder !== null) {
            CxConfig::$layouts_folder = $folder;
        }

        return CxConfig::$layouts_folder;
    }
}
