<?php


class CxUrlPattern
{
    private $url;
    private $regex;
    private $file;
    private $name;
    private $layout;
    private $app;
    private $params_keys = array();
    private $params_values = array();

    public function __construct($url, $file, $name, $layout, $app = null)
    {
        $this->url = $this->sanitizeUrl($url);
        $this->regex = $this->generateRegex($url);
        $this->file = $file;
        $this->name = $name;
        $this->layout = $layout;
        $this->app = $app;
    }

    private function sanitizeUrl($url)
    {
        if (substr($url, -1) == "/") {
            $url = substr($url, 0, -1);
        }
        if (strlen($url) > 0 && $url[0] == "/") {
            $url = substr($url, 1);
        }

        return $url;
    }

    private function generateRegex($url)
    {
        $url = $this->sanitizeUrl($url);
        $pattern = '/<([a-zA-Z0-9_]++)>/';
        $terms = null;

        $n_matches = preg_match_all($pattern, $url, $terms);
        for ($i = 0; $i < $n_matches; $i++) {
            array_push($this->params_keys, $terms[1][$i]);
        }

        $regex = preg_replace($pattern, '([a-zA-Z0-9_]++)', $url);
        $regex = str_replace('/', '\/', $regex);
        return '/^' . $regex . '$/';
    }

    public function get_url($params = null)
    {
        if ($params == null) {
            return $this->url;
        }

        $url = strtr($this->url, $params);
        $url = str_replace("<", "", $url);
        $url = str_replace(">", "", $url);

        return $url;
    }

    public function get_file()
    {
        return $this->file;
    }

    public function get_name()
    {
        return $this->name;
    }

    public function get_layout()
    {
        return $this->layout;
    }

    public function get_regex()
    {
        return $this->regex;
    }

    public function has_params()
    {
        return count($this->params_keys) > 0;
    }

    public function push_param_value($value)
    {
        array_push($this->params_values, $value);
    }

    public function get_params()
    {
        $params = [];
        for ($i = 0; $i < count($this->params_keys); $i++) {
            $params[$this->params_keys[$i]] = $this->params_values[$i];
        }
        return $params;
    }

    public function get_app()
    {
        return $this->app;
    }
}

class CxRouter
{
    private static $routes = array();
    private static $urlAtual = null;
    private static $appAtual = null;

    private static function sanitizeUrl($url)
    {
        if (substr($url, -1) == "/") {
            $url = substr($url, 0, -1);
        }
        if (strlen($url) > 0 && $url[0] == "/") {
            $url = substr($url, 1);
        }

        return $url;
    }

    public static function all()
    {
        return CxRouter::$routes;
    }

    public static function addUrl($url, $file, $name = null, $layout = 'default.php')
    {
        $url = CxRouter::sanitizeUrl($url);
        array_push(CxRouter::$routes, new CxUrlPattern($url, $file, $name, $layout, CxRouter::$appAtual));
    }

    public static function addApiUrl($url, $file, $name = null)
    {
        $url = CxRouter::sanitizeUrl($url);
        array_push(CxRouter::$routes, new CxUrlPattern($url, $file, $name, null, CxRouter::$appAtual));
    }

    public static function matchUrl()
    {
        $urlRequest = CxRouter::sanitizeUrl($_SERVER['REQUEST_URI']);
        $urlRequest = preg_replace('/' . CxConfig::base_path() . '\/?/', '', $urlRequest);

        foreach (CxRouter::$routes as $url) {
            $terms = null;
            $n_matches = preg_match_all($url->get_regex(), $urlRequest, $terms);
            if ($n_matches) {
                if ($url->has_params()) {
                    for ($i = 0; $i < count($terms) - 1; $i++) {
                        $url->push_param_value($terms[$i + 1][0]);
                    }
                    CxRequest::set_params($url->get_params());
                }

                CxRouter::$urlAtual = $url;
                break;
            }
        }

        return;
    }

    public static function get_response()
    {
        // TODO: Tratamento de retornos HTTP: 404, 403, 200 ...
        $response = null;

        if (CxRouter::$urlAtual) {
            $layout = CxRouter::$urlAtual->get_layout();
            if ($layout) {
                $response = 'layouts/' . CxRouter::$urlAtual->get_layout();
            } else {
                $response = CxRouter::get_current_file();
            }
        }

        return $response;
    }

    public static function get_current_file()
    {
        return CxConfig::app_folder() . '/' . CxRouter::$urlAtual->get_file();
    }

    public static function set_app($app)
    {
        CxRouter::$appAtual = $app;
    }

    public static function unset_app()
    {
        CxRouter::$appAtual = null;
    }

    public static function get_current_url()
    {
        return CxRouter::$urlAtual;
    }

    public static function get_current_app()
    {
        return CxRouter::$urlAtual ? CxRouter::$urlAtual->get_app() : null;
    }
}


class CxUrl
{

    public static function site($name, $params = null)
    {
        foreach (CxRouter::all() as $url) {
            if ($url->get_name() === $name) {
                return '/' . CxConfig::base_path() . '/' . $url->get_url($params);
            }
        }
    }

    public static function statics()
    {
        return '/' . CxConfig::base_path() . '/' . CxConfig::statics_folder();
    }

    public static function media()
    {
        return '/' . CxConfig::base_path() . '/' . CxConfig::media_folder();
    }

    public static function layouts()
    {
        return '/' . CxConfig::base_path() . '/' . CxConfig::layouts_folder();
    }

    public static function app()
    {
        return '/' . CxConfig::base_path() . '/' . CxConfig::app_folder();
    }
}
