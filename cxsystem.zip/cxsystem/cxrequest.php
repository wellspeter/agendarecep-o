<?php
class CxRequest
{

    private static $params = array();
    const HTTP_POST = "POST";
    const HTTP_GET = "GET";
    const HTTP_DELETE = "DELETE";
    const HTTP_PUT = "PUT";


    public static function method()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    public static function get($key = null)
    {
        if ($key === null) {
            return $_GET;
        }

        return isset($_GET[$key]) ? $_GET[$key] : null;
    }

    public static function params($key = null)
    {
        if ($key === null) {
            return CxRequest::$params;
        }

        return isset(CxRequest::$params[$key]) ? CxRequest::$params[$key] : null;
    }

    public static function set_params($params)
    {
        return CxRequest::$params = $params;
    }

    public static function post($key = null)
    {
        $post = $_POST;
        if (empty($post)) {
            $post = json_decode(CxRequest::body(), true);
        }

        if ($post == null) {
            $post = array();
        }

        if ($key === null) {
            return $post;
        }

        return isset($post[$key]) ? $post[$key] : null;
    }

    public static function body()
    {
        return file_get_contents('php://input');
    }

    public static function render_http_404_not_found()
    {
        http_response_code(404);
        ob_end_clean();
        include(__DIR__ . '/../layouts/error/404.php');
        die();
    }

    public static function render_http_403_forbidden()
    {
        http_response_code(403);
        ob_end_clean();
        include(__DIR__ . '/../layouts/error/403.php');
        die();
    }

    public static function render_response($response)
    {
        if ($response === null) {
            CxRequest::render_http_404_not_found();
        } else {
            include(__DIR__ . '/../' . $response);
        }
    }
}
