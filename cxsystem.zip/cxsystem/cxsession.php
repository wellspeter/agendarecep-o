<?php
//phpinfo();
//ini_set('session.save_path',realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
//session_save_path('/home/example.com/sessions');
ini_set('session.save_path', getcwd() . '/tmp');
session_start();

class CxSession
{
    public static function get($key = null)
    {
        if ($key === null) {
            return $_SESSION;
        }

        return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
    }

    public static function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }
}
