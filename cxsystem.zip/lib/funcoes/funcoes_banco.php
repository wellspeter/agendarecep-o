<?php

function listaDadosArray($conn, $query) {
  try {
    $dados = array();    

    $sth = $conn->prepare($query);

    $sth->execute();

    $sth->setFetchMode(PDO::FETCH_ASSOC);
    while($item = $sth->fetch()){
      array_push($dados, $item);
    }

    return $dados;
  }
  catch (PDOException $e) {
    echo 'Erro ao tentar carregar os dados.' . $e->getMessage();    
    return false;
  }
}
