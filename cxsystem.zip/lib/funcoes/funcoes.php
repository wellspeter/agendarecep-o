<?php

function abreviar_nome($nome)
{

  // $nome = "João da Silva Guimarães";

  $temp = explode(" ", $nome);

  $nomeNovo = $temp[0] . " " . $temp[count($temp) - 1];

  return $nomeNovo;
}

function saudacao()
{

  $hr = date(" H ");

  if ($hr >= 12 && $hr < 18) {
    $resp = "Boa tarde";
  } else if ($hr >= 0 && $hr < 12) {
    $resp = "Bom dia";
  } else {
    $resp = "Boa noite";
  }

  return $resp;
}

function primeiroNome($name)
{
  $array = explode(" ", $name);
  return $array[0];
}

// oculta o nome para retornar assim: fula********@*******com
function ocultarEmail($email) {
  // Verifica se o e-mail é válido
  if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      // Divide o e-mail em duas partes: usuário e domínio
      list($usuario, $dominio) = explode('@', $email);

      // Exibir os primeiros 4 caracteres do usuário e ocultar o restante
      $usuarioOcultado = substr($usuario, 0, 4) . str_repeat('*', strlen($usuario) - 4);

      // Exibir o primeiro caractere do domínio e ocultar o restante até os últimos 3 caracteres
      $dominioOcultado = substr($dominio, 0, 1) . str_repeat('*', strlen($dominio) - 4) . substr($dominio, -3);

      // Monta o e-mail com a máscara aplicada
      $emailOcultado = $usuarioOcultado . '@' . $dominioOcultado;

      return $emailOcultado;
  } else {
      // Retorna uma mensagem de erro se o e-mail for inválido
      return "";
  }
}

// oculta o nome para retornar assim: Saída: (61) 9*****23
function ocultarTelefone($telefone) {
  // Remove todos os caracteres que não são números
  $somenteNumeros = preg_replace('/\D/', '', $telefone);

  // Verifica se o telefone tem o tamanho correto (11 dígitos, incluindo DDD)
  if (strlen($somenteNumeros) == 11) {
      // Divide o telefone em partes: DDD, primeiro dígito, parte oculta e últimos 2 dígitos
      $ddd = substr($somenteNumeros, 0, 2); // Os primeiros 2 dígitos (DDD)
      $primeiroDigito = substr($somenteNumeros, 2, 1); // O primeiro dígito do número (normalmente 9)
      $ocultado = str_repeat('*', 5); // 5 asteriscos para ocultar o meio
      $ultimosDois = substr($somenteNumeros, -2); // Os últimos 2 dígitos

      // Monta o número com a máscara (00) 9*****00
      $telefoneFormatado = "($ddd) $primeiroDigito$ocultado$ultimosDois";

      return $telefoneFormatado;
  } else {
      // Retorna uma mensagem de erro se o telefone não tiver o tamanho esperado
      return "";
  }
}


// oculta o nome para retornar assim: Saída: Fulano ** ***** **uro
function ocultarNome($nomeCompleto) {
  // Quebra o nome completo em partes
  $partesNome = explode(" ", $nomeCompleto);

  // Mantém o primeiro nome como está
  $primeiroNome = $partesNome[0];

  // Pega o último nome
  $ultimoNome = end($partesNome);

  // Oculta todas as letras do último nome, exceto as últimas 3
  $tamanhoUltimoNome = strlen($ultimoNome);
  if ($tamanhoUltimoNome > 3) {
      $ultimoNomeOculto = str_repeat('*', $tamanhoUltimoNome - 3) . substr($ultimoNome, -3);
  } else {
      // Se o último nome tiver 3 ou menos letras, não oculta nada
      $ultimoNomeOculto = $ultimoNome;
  }

  // Oculta todos os nomes intermediários
  $nomesIntermediariosOcultos = [];
  for ($i = 1; $i < count($partesNome) - 1; $i++) {
      $nomesIntermediariosOcultos[] = str_repeat('*', strlen($partesNome[$i]));
  }

  // Constrói o nome final
  $nomeOcultado = $primeiroNome . ' ' . implode(' ', $nomesIntermediariosOcultos) . ' ' . $ultimoNomeOculto;

  return $nomeOcultado;
}




function arrayToTable($array)
{
  // start table
  $html = '<table class="table table-hover " >';

  // header row
  $html .= '<thead>';
  $html .= '<tr>';
  foreach ($array[0] as $key => $value) {
    $html .= '<th scope="col">' . htmlspecialchars($key) . '</th>';
  }
  $html .= '</tr>';
  $html .= '</thead>';

  // data rows    
  $html .= '<tbody>';
  foreach ($array as $key => $value) {
    $html .= '<tr>';
    foreach ($value as $key2 => $value2) {
      $html .= '<td>' . htmlspecialchars($value2) . '</td>';
    }
    $html .= '</tr>';
  }
  $html .= '</tbody>';

  // finish table and return it
  $html .= '</table>';
  return $html;
}

function arrayToTableCd($array)
{
  // start table
  $html = '<table class="table table-hover " >';

  // header row
  $html .= '<thead>';
  $html .= '<tr>';
  foreach ($array[0] as $key => $value) {
    $html .= '<th scope="col">' . htmlspecialchars($key) . '</th>';
  }
  $html .= '</tr>';
  $html .= '</thead>';

  // data rows    
  $html .= '<tbody>';
  foreach ($array as $key => $value) {
    $html .= '<tr>';
    foreach ($value as $key2 => $value2) {
      $html .= '<td>' . htmlspecialchars($value2) . '</td>';
    }
    $html .= '</tr>';
  }
  $html .= '</tbody>';

  // finish table and return it
  $html .= '</table>';
  return $html;
}


function ConcatNum($num)
{

  switch (true) {
    case ($num >= 1000000000):
      return number_format($num / 1000000000, 3, ',', '.') . '<b> B</b>';
    case ($num >= 1000000):
      return number_format($num / 1000000, 2, ',', '.') . '<b> M</b>';
    case ($num >= 1000):
      return number_format($num / 1000, 1, ',', '.') . '<b> K</b>';
    case ($num < 1000):
      return number_format($num, 2, ',', '.');
  }
}

function ConcatNumNegativo($num)
{

  $num = ($num * -1);

  switch (true) {
    case ($num >= 1000000000):
      return number_format($num / 1000000000, 3, ',', '.') . '<b> B</b>';
    case ($num >= 1000000):
      return number_format($num / 1000000, 2, ',', '.') . '<b> M</b>';
    case ($num >= 1000):
      return number_format($num / 1000, 1, ',', '.') . '<b> K</b>';
    case ($num < 1000):
      return number_format($num, 2, ',', '.');
  }
}


function formatarNumero($valor)
{
  return number_format($valor, 2, ",", ".");
}

function formatarReal($valor)
{
  // $formatter = new NumberFormatter('pt_BR',  NumberFormatter::CURRENCY);
  // return $formatter->formatCurrency($valor, 'BRL');
  return "R$ " . formatarNumero($valor);
}

function formatarNumeroTamanho($valor, $tamanho)
{
  return number_format($valor, $tamanho, ",", ".");
}

function valorFormatadoConquiste($valor)
{
  if ($valor >= 1000000000) {
    $valor_formatado = number_format($valor / 1000000000, 2) . " Bilhões";
  } else if ($valor >= 1000000) {
    $valor_formatado = number_format($valor / 1000000, 2) . " Milhões";
  } else if ($valor >= 1000) {
    $valor_formatado = ($valor / 1000) . " Mil";
  } else if ($valor < 1000 && $valor > 0) {
    $valor_formatado = number_format($valor);
  } else if ($valor <= -1000000000) {
    $valor_formatado = number_format($valor / 1000000000) . +" Bilhões";
  } else if ($valor <= -1000000) {
    $valor_formatado = number_format($valor / 1000000) . +" Milhões";
  } else if ($valor <= -1000) {
    $valor_formatado = number_format($valor / 1000) . " Mil";
  } else if ($valor > -1000 && $valor < 0) {
    $valor_formatado = number_format($valor);
  } else if ($valor == 0) {
    $valor_formatado = number_format($valor);
  }
  return $valor_formatado;
}

function formatar_cnpj($cnpj)
{
  if (!$cnpj) {
    return '';
  }

  $cnpj = '00000000000000' . strval($cnpj);
  $cnpj = substr($cnpj, -14);
  return substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . substr($cnpj, 5, 3) . '/' . substr($cnpj, 8, 4) . '-' . substr($cnpj, 12, 2);
}

function formatar_cnpj_base($cnpj)
{
  if (!$cnpj) {
    return '';
  }

  $cnpj = '00000000' . strval($cnpj);
  $cnpj = substr($cnpj, -8);
  return substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . substr($cnpj, 5, 3);
}

function formatar_cpf($cpf)
{
  if (!$cpf) {
    return '';
  }

  $cpf = '00000000000' . strval($cpf);
  $cpf = substr($cpf, -11);
  return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
}


function mes_nome($mes_num)
{
  if ($mes_num == 1) {
    $mes_nome = "Janeiro";
  } elseif ($mes_num == 2) {
    $mes_nome = "Fevereiro";
  } elseif ($mes_num == 3) {
    $mes_nome = "Março";
  } elseif ($mes_num == 4) {
    $mes_nome = "Abril";
  } elseif ($mes_num == 5) {
    $mes_nome = "Maio";
  } elseif ($mes_num == 6) {
    $mes_nome = "Junho";
  } elseif ($mes_num == 7) {
    $mes_nome = "Julho";
  } elseif ($mes_num == 8) {
    $mes_nome = "Agosto";
  } elseif ($mes_num == 9) {
    $mes_nome = "Setembro";
  } elseif ($mes_num == 10) {
    $mes_nome = "Outubro";
  } elseif ($mes_num == 11) {
    $mes_nome = "Novembro";
  } else {
    $mes_nome = "Dezembro";
  }
  return $mes_nome;
}

function mes_nome_reduz($mes_num)
{
  if ($mes_num == 1) {
    $mes_nome_reduz = "Jan";
  } elseif ($mes_num == 2) {
    $mes_nome_reduz = "Fev";
  } elseif ($mes_num == 3) {
    $mes_nome_reduz = "Mar";
  } elseif ($mes_num == 4) {
    $mes_nome_reduz = "Abr";
  } elseif ($mes_num == 5) {
    $mes_nome_reduz = "Mai";
  } elseif ($mes_num == 6) {
    $mes_nome_reduz = "Jun";
  } elseif ($mes_num == 7) {
    $mes_nome_reduz = "Jul";
  } elseif ($mes_num == 8) {
    $mes_nome_reduz = "Ago";
  } elseif ($mes_num == 9) {
    $mes_nome_reduz = "Set";
  } elseif ($mes_num == 10) {
    $mes_nome_reduz = "Out";
  } elseif ($mes_num == 11) {
    $mes_nome_reduz = "Nov";
  } else {
    $mes_nome_reduz = "Dez";
  }
  return $mes_nome_reduz;
}


function formataAnoMes($ano_mes)
{
  if (substr($ano_mes, 4, 2) == "01") {
    $mes_nome = "Jan/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "02") {
    $mes_nome = "Fev/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "03") {
    $mes_nome = "Mar/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "04") {
    $mes_nome = "Abr/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "05") {
    $mes_nome = "Mai/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "06") {
    $mes_nome = "Jun/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "07") {
    $mes_nome = "Jul/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "08") {
    $mes_nome = "Ago/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "09") {
    $mes_nome = "Set/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "10") {
    $mes_nome = "Out/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "11") {
    $mes_nome = "Nov/" . substr($ano_mes, 0, 4);
  } else {
    $mes_nome = "Dez/" . substr($ano_mes, 0, 4);
  }
  return $mes_nome;
}

function formataAnoMesCompleto($ano_mes)
{
  if (substr($ano_mes, 4, 2) == "01") {
    $mes_nome = "Janeiro/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "02") {
    $mes_nome = "Fevereiro/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "03") {
    $mes_nome = "Março/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "04") {
    $mes_nome = "Abril/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "05") {
    $mes_nome = "Maio/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "06") {
    $mes_nome = "Junho/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "07") {
    $mes_nome = "Julho/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "08") {
    $mes_nome = "Agosto/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "09") {
    $mes_nome = "Setembro/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "10") {
    $mes_nome = "Outubro/" . substr($ano_mes, 0, 4);
  } elseif (substr($ano_mes, 4, 2) == "11") {
    $mes_nome = "Novembro/" . substr($ano_mes, 0, 4);
  } else {
    $mes_nome = "Dezembro/" . substr($ano_mes, 0, 4);
  }
  return $mes_nome;
}

function formataDiaAnoMes($diaAnoMes)
{
  $anoMesDiaTemp = explode("-", $diaAnoMes);
  $anoTemp = $anoMesDiaTemp[0];
  $mesTemp = $anoMesDiaTemp[1];
  return formataAnoMes($anoTemp . $mesTemp);
}

function formataDataBrasil($diaAnoMes)
{
  $anoMesDiaTemp = explode("-", $diaAnoMes);
  $anoTemp = $anoMesDiaTemp[0];
  $mesTemp = $anoMesDiaTemp[1];
  $diaTemp = $anoMesDiaTemp[2];
  return $diaTemp . '/' . $mesTemp . '/' . $anoTemp;
}

function formataDataHoraBrasil($diaAnoMesHora)
{
  return (new DateTime($diaAnoMesHora))->format('d/m/Y H:i:s');
}


function calcularIdade($data)
{
  $idade = 0;
  $data_nascimento = date('Y-m-d', strtotime($data));
  $data = explode("-", $data_nascimento);
  $anoNasc    = $data[0];
  $mesNasc    = $data[1];
  $diaNasc    = $data[2];
  $anoAtual   = date("Y");
  $mesAtual   = date("m");
  $diaAtual   = date("d");
  $idade      = $anoAtual - $anoNasc;

  if ($mesAtual < $mesNasc) {
    $idade -= 1;
  } elseif (($mesAtual == $mesNasc) && ($diaAtual <= $diaNasc)) {
    $idade -= 1;
  }
  return $idade;
}

function nomeUndConquiste($cgc)
{
  switch ($cgc) {
    case 5281:
      echo "SER - SR AGRONEGOCIO ";
      break;
    case 9991:
      echo "TOTALIZADOR DA REDE PJ VINAT ";
      break;
    case 9995:
      echo "TOTALIZADOR DA REDE PRIVATE ";
      break;
    case 9997:
      echo "TOTALIZADOR SE CORPORATIVO ";
      break;
    case 9999:
      echo "TOTALIZADOR SE EMPRESARIAL ";
      break;
    case 5194:
      echo "SUMEP - SN MEDIAS EMPRESAS";
      break;
    case 5190:
      echo "SUNCO - SN CORPORATIVO";
      break;
    case 5795:
      echo "SUPRA - SN PRIVATE E AGRONEGOCIO ";
      break;
    case 6515:
      echo "SEP - SR PRIVATE ";
      break;
  }
}

function formataCoresConquiste($valor)
{
  if ($valor >= 100) {
    return "<font style='color:blue;'> " . $valor . "  </font>";
  } else if ($valor < 100 && $valor >= 95) {
    return "<font style='color:green;'> " . $valor . " </font>";
  } else if ($valor < 95 && $valor >= 90) {
    return "<font style='color:#e2a200;'> " . $valor . "  </font>";
  } else if ($valor < 90) {
    if ($valor == 0) {
      return "<font style='color:red;'> 0.00  </font>";
    } else {
      return "<font style='color:red;'> " . $valor . "  </font>";
    }
  }
}

function retornaCoresConquiste($valor)
{
  if ($valor >= 100) {
    return "#0e64ed";
  } else if ($valor < 100 && $valor >= 95) {
    return "#06d110";
  } else if ($valor < 95 && $valor >= 90) {
    return "#e2a200";
  } else if ($valor < 90) {
    return "#f00505";
  }
}


function Quartil_25($Array)
{
  return Quartil($Array, 0.25);
}

function Quartil_50($Array)
{
  return Quartil($Array, 0.5);
}

function Quartil_75($Array)
{
  return Quartil($Array, 0.75);
}

function Quartil($Array, $Quartil)
{
  sort($Array);
  $pos = (count($Array) - 1) * $Quartil;

  $base = floor($pos);
  $rest = $pos - $base;

  if (isset($Array[$base + 1])) {
    return $Array[$base] + $rest * ($Array[$base + 1] - $Array[$base]);
  } else {
    return $Array[$base];
  }
}

function Average($Array)
{
  return array_sum($Array) / count($Array);
}

function StdDev($Array)
{
  if (count($Array) < 2) {
    return;
  }

  $avg = Average($Array);

  $sum = 0;
  foreach ($Array as $value) {
    $sum += pow($value - $avg, 2);
  }

  return sqrt((1 / (count($Array) - 1)) * $sum);
}

function getQuadrante($valor, $arrayValores)
{

  // Calcula os quartis 
  $quartil_1 = Quartil_25($arrayValores);
  $quartil_2 = Quartil_50($arrayValores);
  $quartil_3 = Quartil_75($arrayValores);


  // Encontra o quartil e seta o quadrante baseado na propria unidade do empregado 
  if ($valor <= $quartil_1) {
    return '4';
  } else if ($valor > $quartil_1 && $valor <= $quartil_2) {
    return '3';
  } else if ($valor > $quartil_2 && $valor <= $quartil_3) {
    return '2';
  } else {
    return  '1';
  }
}


function valorFormatadoConquisteReduzido($valor)
{
  if ($valor >= 1000000000) {
    $valor_formatado = number_format($valor / 1000000000, 0) . " Bi";
  } else if ($valor >= 1000000) {
    $valor_formatado = number_format($valor / 1000000, 0) . " Mi";
  } else if ($valor >= 1000) {
    $valor_formatado = ($valor / 1000) . " Mil";
  } else if ($valor < 1000 && $valor > 0) {
    $valor_formatado = number_format($valor);
  } else if ($valor <= -1000000000) {
    $valor_formatado = number_format($valor / 1000000000) . +" Bi";
  } else if ($valor <= -1000000) {
    $valor_formatado = number_format($valor / 1000000) . +" Mi";
  } else if ($valor <= -1000) {
    $valor_formatado = number_format($valor / 1000) . " Mil";
  } else if ($valor > -1000 && $valor < 0) {
    $valor_formatado = number_format($valor);
  } else if ($valor == 0) {
    $valor_formatado = number_format($valor);
  }
  return $valor_formatado;
}

function formataCoresQuadrante($quadrante, $ordenacao)
{
  if ($ordenacao == 'ASC') {
    if ($quadrante == 1) {
      return "primary";
    } else if ($quadrante == 2) {
      return "success";
    } else if ($quadrante == 3) {
      return "warning";
    } else if ($quadrante == 4) {
      return "danger";
    }
  } else if ($ordenacao == 'DESC'){
    if ($quadrante == 1) {
      return "danger";
    } else if ($quadrante == 2) {
      return "warning";
    } else if ($quadrante == 3) {
      return "success";
    } else if ($quadrante == 4) {
      return "primary";
    }
  }
}
