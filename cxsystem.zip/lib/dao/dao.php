<?php

class DAO
{
    private $database = '';

    function __construct($database)
    {
        $this->database = $database;
    }

    protected function buscar_primeiro($sql, $params = array())
    {
        $result = null;

        try {
            $conn = DataBase::get_connection($this->database);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sth = $conn->prepare($sql);
            $sth->execute($params);
            $sth->setFetchMode(PDO::FETCH_ASSOC);

            $result = $sth->fetch();
        } catch (PDOException $e) {
            echo 'ERRO AO EXECUTAR INSTRUÇÃO SQL ' . $e->getMessage();
        }

        return $result;
    }

    protected function buscar_lista($sql, $params = array())
    {
        $result = [];
        try {
            $conn = DataBase::get_connection($this->database);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sth = $conn->prepare($sql);
            $sth->execute($params);
            $sth->setFetchMode(PDO::FETCH_ASSOC);

            $result = $sth->fetchAll();
        } catch (PDOException $e) {
            echo 'ERRO AO EXECUTAR INSTRUÇÃO SQL ' . $e->getMessage();
        }

        return $result;
    }

    protected function exec_sp($sql, $params)
    {
        $result = [];
        try {
            $conn = DataBase::get_connection($this->database);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sth = $conn->prepare('SET NOCOUNT ON ;'.$sql);
            $sth->execute($params);
            $sth->setFetchMode(PDO::FETCH_ASSOC);

            $result = $sth->fetchAll();
        } catch (PDOException $e) {
            echo 'ERRO AO EXECUTAR INSTRUÇÃO SQL ' . $e->getMessage();
        }

        return $result;
    }


    private function exec($sql, $params)
    {
        try {
            $conn = DataBase::get_connection($this->database);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sth = $conn->prepare($sql);
            $sth->execute($params);
            return true;
        } catch (PDOException $e) {
            echo 'ERRO AO EXECUTAR INSTRUÇÃO SQL ' . $e->getMessage();
        }

        return false;
    }

    protected function inserir($sql, $params = array())
    {
        return $this->exec($sql, $params);
    }

    protected function atualizar($sql, $params = array())
    {
        return $this->exec($sql, $params);
    }

    protected function deletar($sql, $params = array())
    {
        return $this->exec($sql, $params);
    }

}
