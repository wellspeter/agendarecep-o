<?php

class Permissoes
{
    public function __construct()
    {
    }

    public function usuario_gedat($unidade_usuario)
    {
        return $unidade_usuario == '5131';
    }
}
