<!DOCTYPE html>
<html lang="pt-br">

<head>

    <?php
    if (isset($css_extras)) {
        foreach ($css_extras as $css_file) {
            $file = CxUrl::statics() . '/' . $css_file;
            echo "<link rel='stylesheet' type='text/css' href='" . $file . "'>";
        }
    }
    ?>

    <?php require_once('inc/head.php'); ?>

    <?php
    if (isset($js_extras)) {
        foreach ($js_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>


</head>

<body class="horizontal-layout horizontal-menu navbar-static 2-columns footer-static pace-done" data-open="hover" data-menu="horizontal-menu" data-col="2-columns">

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <?php require __DIR__ . '/../' . CxRouter::get_current_file(); ?>

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <?php require_once('inc/scripts.php'); ?>

    <?php
    if (isset($js_scripts_extras)) {
        foreach ($js_scripts_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>
    <script type="text/javascript">
        var element = $("<div></div>");
        properties = {
            "overflow": "hidden",
            "z-index": "98",
            "background-color": "rgba(0,0,0,0.0)",
            "position": "fixed",
            "width": "100%",
            "height": "100%",
            "top": "0",
            "left": "0",
            "right": "0",
            "bottom": "0",
            "font-size": "20pt",
            "color": "rgba(0, 0, 0, 0.1)",
            "text-align": "justify",
            "margin-left": "6px",
            "margin-right": "6px",
            "line-height": "5rem"
        };

        <?php
        $usuario_session = CxSession::get('usuario');
        $marca_dagua = strtoupper($usuario_session['co_usuario']) . ' - ' . $usuario_session['no_usuario'];
        ?>

        var text = ' ';

        for (var i = 0; i < 5000; i++) {
            text += '<?php echo $marca_dagua; ?> ';
        }
        element.html(text);
        element.css(properties);
        $("body").append(element);

        button = $("<button><i class='bx bx-printer'></i></button>");
        button.addClass("btn btn-icon btn-outline-primary mr-1 mb-1 float-right");
        properties = {
            "z-index": "99",
            "position": "fixed",
            "top": "0",
            "right": "0",
            "margin-top": "15px"
        };
        button.css(properties);
        button.on('click', () => {
            window.print();
        });
        $("body").append(button);
    </script>
</body>

</html>