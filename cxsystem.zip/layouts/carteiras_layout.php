<!DOCTYPE html>
<html lang="pt-br">

<head>

    <?php
    if (isset($css_extras)) {
        foreach ($css_extras as $css_file) {
            $file = CxUrl::statics() . '/' . $css_file;
            echo "<link rel='stylesheet' type='text/css' href='" . $file . "'>";
        }
    }
    ?>

    <?php require_once('inc/head.php'); ?>

    <?php
    if (isset($js_extras)) {
        foreach ($js_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>

</head>

<body data-statics-url="<?php echo CxUrl::statics() ?>" class="horizontal-layout horizontal-menu navbar-static 2-columns footer-static pace-done" data-open="hover" data-menu="horizontal-menu" data-col="2-columns">

    <?php require_once('inc/header.php'); ?>

    <?php require_once('inc/nav.php'); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <?php
                // require_once(__DIR__ . '/../app/carteiras/views/_menu_lateral.php');
                ?>

                <section id="page-account-settings">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <!-- left menu section -->
                                <!--
                                <div class="col-md-3 mb-2 mb-md-0 pills-stacked">
                                    <ul class="nav nav-pills flex-column">
                                        <?php
                                        /* foreach ($menu_lateral as $item_lateral) {
                                        ?>
                                            <li class="nav-item">
                                                <?php if (isset($item_lateral['target']) && $item_lateral['target'] == '_blank') : ?>
                                                    <a target="_blank" class="nav-link d-flex <?php echo $item_lateral['titulo'] == $menu_lateral[0]['titulo'] ? 'active' : '' ?> align-items-center" href="<?php echo $item_lateral['url'] ?>">
                                                <?php else : ?>
                                                    <?php if ($item_lateral['nivel'] == '0') : ?>
                                                        <div style="margin-top:7px; margin-bottom: 6px; ">
                                                            <i class="bx <?php echo $item_lateral['icone'] ?>"></i>
                                                            <span><?php echo $item_lateral['titulo'] ?></span>
                                                        </div>  
                                                    <?php else : ?>
                                                        <a class="nav-link d-flex 
                                                            <?php echo CxRouter::get_current_url()->get_url() == $menu_lateral[0]['url'] ? 'active' : '' ?> align-items-center cls_listar_dados_tab" 
                                                                href="<?php echo $item_lateral['url'] ?>" 
                                                                <?php if ($item_lateral['nivel'] == '2') : ?> style="margin-left:22px" <?php endif; ?>  
                                                                <?php if ($item_lateral['nivel'] == '1') : ?> style="margin-left:-20px"<?php endif; ?>>
                                                            <i class="bx <?php echo $item_lateral['icone'] ?>"></i>
                                                            <span><?php echo $item_lateral['titulo'] ?></span>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </li>
                                        <?php
                                        } */
                                        ?>
                                    </ul>
                                </div>
                                -->
                                <!-- right content section -->
                                <div class="col-md-12">
                                    <div class="card" style="background-size: auto;">
                                        <div class="card-body">
                                            <div class="">
                                                <div id="div-conteudo" aria-labelledby="account-pill-general" aria-expanded="true">

                                                    <?php require __DIR__ . '/../' . CxRouter::get_current_file(); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <?php require_once('inc/footer.php'); ?>

    <?php require_once('inc/scripts.php'); ?>

    <?php
    if (isset($js_scripts_extras)) {
        foreach ($js_scripts_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>
</body>

</html>