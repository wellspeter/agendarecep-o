    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

    <meta name="Recepção Eleitos 2024" content="GEEGO">

    <title>Recepção Eleitos 2024 - agendarecepcap.caixa</title>
    <!-- <link rel="apple-touch-icon" href="<?php echo CxUrl::statics() ?>/app-assets/images/ico/apple-icon-120.png"> -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo CxUrl::statics() ?>/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">

    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/jquery/jquery.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/jquery/jquery-ui.js"></script> -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.js"></script>

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/tables/datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/charts/apexcharts.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/extensions/dragula.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/forms/select/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/editors/quill/quill.snow.css">

    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/themes/semi-dark-layout.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/core/menu/menu-types/horizontal-menu.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/pages/widgets.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/pages/dashboard-analytics.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/pages/app-todo.css">
    <!-- END: Page CSS-->

    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/plugins/forms/wizard.css">
	
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/plugins/datepicker/datepicker3.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/pickers/pickadate/pickadate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/pickers/daterange/daterangepicker.css">


    <!-- Calendar CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/calendars/tui-time-picker.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/calendars/tui-date-picker.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/calendars/tui-calendar.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css">

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/assets/css/style.css">
    <!-- END: Custom CSS-->

    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/select.dataTables.min.css">   

    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/plugins/extensions/toastr.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/extensions/toastr.css">

    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/charts/apexcharts.css">

    <!-- BEGIN: Custom JS-->
  
    <!-- END: Custom JS-->

    <!-- END: Head-->


    
	