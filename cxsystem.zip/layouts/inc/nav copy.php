<!-- BEGIN: Main Menu-->
<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-sticky navbar-light navbar-without-dd-arrow" role="navigation" data-menu="menu-wrapper">
	<!-- Horizontal menu content-->
	<div class="navbar-container main-menu-content" data-menu="menu-container">
		<!-- include <?php echo CxUrl::statics() ?>/includes/mixins-->
		<ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="filled">
			
			<!-- ########################## ÁREA AGRO -->

			<li class=" nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="<?php echo CxUrl::site('metas:index') ?>" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="screenshot"></i>
				<span data-i18n="Forms &amp; Tables">Distribuição Meta</span></a>		
			</li>

			<li class=" nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="like"></i>
				<span data-i18n="Forms &amp; Tables">Nova Distribuição Meta</span></a>		
			</li>

			<!-- MENU DE CARTEIRA -->
			<?php  /*if (CxSession::get('usuario')['nu_matricula'] == '111232' || CxSession::get('usuario')['nu_matricula'] == '093558' || CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '090724') { */ ?>
				
			<li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="menu-livicon" data-icon="box"></i><span data-i18n="Pages">Histórico de Distribuição</span></a>
				<ul class="dropdown-menu">
						<?php
							if (CxSession::get('usuario')['nu_lotacao_fisica'] == '5197' || CxSession::get('usuario')['nu_lotacao_fisica'] == '5186'  ) { 
						?>
					
						<li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a class="dropdown-item align-items-center dropdown-toggle" href="#" data-toggle="dropdown"><span data-i18n="Second Level">Resultado Comitê</span></a>
							<ul class="dropdown-menu">

								<li class="dropdown dropdown-submenu" data-menu="dropdown-submenu">
									<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('cliente:comite:lista_inclusao_cliente') ?>" target="_self" data-toggle="dropdown">
										<span data-i18n="Menu Levels"><span>Listar</span>
									</a>
								</li>
								<li data-menu="">
									<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('cliente:comite:inclusao_cliente') ?>" target="_self" data-toggle="dropdown">
										<span data-i18n="Menu Levels"><span>Incluir</span>
									</a>
								</li>
							</ul>
						</li>
					<?
						} 
					?>
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="https://caixa.sharepoint.com/sites/recuperacaoatacado" data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>GEGOV</span>
						</a>
					</li>
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="https://caixa.sharepoint.com/sites/recuperacaoatacado" data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>GIGOV</span>
						</a>
					</li>
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="https://caixa.sharepoint.com/sites/recuperacaoatacado" data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>DERAT</span>
						</a>
					</li>
				</ul>
			</li>

			<!-- MENU RESTRITO -->
			<!--
			<?php if (CxSession::get('usuario')['nu_lotacao_fisica'] == '5197') { ?>
				<li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="menu-livicon" data-icon="shield"></i><span data-i18n="Charts &amp; Maps">Restrito</span></a>
					<ul class="dropdown-menu">
						<li data-menu=""><a class="dropdown-item align-items-center" href="#" target="_self" data-toggle="dropdown">Aniversariantes</a></li>

					</ul>
				</li>
			<?php } ?>
			-->


		</ul>
	</div>
	<!-- /horizontal menu content-->
</div>
<!-- END: Main Menu-->



<script type="text/javascript">
	function abrirPastaKitFeira() {
		// var shell = new ActiveXObject("WScript.Shell");
		var file = "\"\\\\arquivos.caixa\\br\\DF5197FS201\\GETAC_PUBLICO\\FEIRAS_AGRO\\KIT_FEIRA\"";

		alert('Arquivos disponíveis em :\n' + file);

		// shell.Run(file);

	}
</script>