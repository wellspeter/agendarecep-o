<?php

#Configuration options
$ldap_server = "LDAP://corp.caixa.gov.br/RootDSE";
$ldap_user = "ldapuser@domain.net";
$ldap_pass = "password";
$dn = "dc=domain,dc=net";
# End config

$u = "";
if (isset($_GET['username']) and preg_match("/^[A-Za-z0-9]+$/", $_GET['username'])) {
    $ldap = ldap_connect($ldap_server, 3268);
    ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_bind($ldap, $ldap_user, $ldap_pass) or die ("No LDAP Bind to ".$ldap_server);

    $filter = '(samaccountname='.$_GET['username'].')';
    $sr = ldap_search($ldap, $dn, $filter, array('thumbnailphoto'));
    $u = ldap_get_entries($ldap, $sr);
}

header('content-type: image/jpeg');
if (isset($u[0]['thumbnailphoto'])) {
    echo $u[0]['thumbnailphoto'][0];
} else {
    $fp = fopen('default.jpg', 'r');
    fpassthru($fp);
}

?>