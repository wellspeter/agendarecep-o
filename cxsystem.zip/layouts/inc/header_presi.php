<!-- BEGIN: Header-->
<nav style="background: linear-gradient(to right, rgba(19,41,55), rgba(40,87,128)) !important;" class="header-navbar navbar-expand-lg navbar navbar-with-menu navbar-static-top bg-primary navbar-brand-center">

	<div class="navbar-wrapper">
		<div class="navbar-container content">

			<div class="navbar-collapse d-flex" style="justify-content: space-between;" id="navbar-mobile">
				<div class="brand-logo">
					<a class="navbar-brand" href="<?php echo CxUrl::site('pagina_inicial') ?>">
						<img style="width: 150px !important;height: 35px !important;" class="logo" src="<?php echo CxUrl::statics() ?>/app-assets/images/logo/logo_nova-03.png">
					</a>
					<a class="navbar-brand" href="<?php echo CxUrl::site('pagina_inicial') ?>">
						<h4 style="color:#FFFFFF !important;font-family: 'Rubik', Helvetica, Arial, serif !important" class="brand-text mb-0"></h4>
					</a>
				</div>

				<ul class="nav navbar-nav float-left d-flex align-items-center">
					<!--
					<li class="nav-item mobile-menu mr-auto"><a class="nav-link nav-menu-main menu-toggle" href="javascript:void(0);"><i class="bx bx-menu" style="font-size: 1.8rem; vertical-align: middle"></i></a></li>
					-->
					<li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-expand"><i class="ficon bx bx-fullscreen"></i></a></li>

					<!--
					<li class="nav-item nav-search"><a class="nav-link nav-link-search pt-2"><i class="ficon bx bx-search"></i></a>
						<div class="search-input">
							<div id="icone-busca-principal" class="search-input-icon"><i class="bx bx-search primary"></i></div>
							<span id="spinner-busca-principal" class="spinner-border" style="position:absolute; top: 20px; left:15px; color: #5A8DEE; display: none;"></span>
							<input class="input" type="text" placeholder="Pesquisar por Cliente (CPF, CNPJ ou Nome)" tabindex="-1" data-search="template-search" data-url="<?php echo CxUrl::site('cliente:api:buscar_cliente') ?>">
							<div class="search-input-close"><i class="bx bx-x"></i></div>
							<ul class="search-list"></ul>
						</div>
					</li>
					-->
					<!-- NOTIFICAÇÕES
					<li class="dropdown dropdown-notification nav-item"><a class="nav-link nav-link-label" href="javascript:void(0);" data-toggle="dropdown"><i class="ficon bx bx-bell bx-tada bx-flip-horizontal"></i><span class="badge badge-pill badge-danger badge-up">5</span></a>
						<ul class="dropdown-menu dropdown-menu-media dropdown-menu-right">
							<li class="dropdown-menu-header">
								<div class="dropdown-header px-1 py-75 d-flex justify-content-between"><span class="notification-title">7 new Notification</span><span class="text-bold-400 cursor-pointer">Mark all as read</span></div>
							</li>
							<li class="scrollable-container media-list"><a class="d-flex justify-content-between" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar mr-1 m-0"><img src="<?php echo CxUrl::statics() ?>/app-assets/images/portrait/small/avatar-s-11.jpg" alt="avatar" height="39" width="39"></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">Congratulate Socrates Itumay</span> for work anniversaries</h6><small class="notification-text">Mar 15 12:32pm</small>
										</div>
									</div>
								</a><a class="d-flex justify-content-between read-notification cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar mr-1 m-0"><img src="<?php echo CxUrl::statics() ?>/app-assets/images/portrait/small/avatar-s-16.jpg" alt="avatar" height="39" width="39"></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">New Message</span> received</h6><small class="notification-text">You have 18 unread messages</small>
										</div>
									</div>
								</a><a class="d-flex justify-content-between cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center py-0">
										<div class="media-left pr-0"><img class="mr-1" src="<?php echo CxUrl::statics() ?>/app-assets/images/icon/sketch-mac-icon.png" alt="avatar" height="39" width="39"></div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">Updates Available</span></h6><small class="notification-text">Sketch 50.2 is currently newly added</small>
										</div>
										<div class="media-right pl-0">
											<div class="row border-left text-center">
												<div class="col-12 px-50 py-75 border-bottom">
													<h6 class="media-heading text-bold-500 mb-0">Update</h6>
												</div>
												<div class="col-12 px-50 py-75">
													<h6 class="media-heading mb-0">Close</h6>
												</div>
											</div>
										</div>
									</div>
								</a><a class="d-flex justify-content-between cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar bg-primary bg-lighten-5 mr-1 m-0 p-25"><span class="avatar-content text-primary font-medium-2">LD</span></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">New customer</span> is registered</h6><small class="notification-text">1 hrs ago</small>
										</div>
									</div>
								</a><a href="javascript:void(0);">
									<div class="media d-flex align-items-center justify-content-between">
										<div class="media-left pr-0">
											<div class="media-body">
												<h6 class="media-heading">New Offers</h6>
											</div>
										</div>
										<div class="media-right">
											<div class="custom-control custom-switch">
												<input class="custom-control-input" type="checkbox" checked id="notificationSwtich">
												<label class="custom-control-label" for="notificationSwtich"></label>
											</div>
										</div>
									</div>
								</a><a class="d-flex justify-content-between cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar bg-danger bg-lighten-5 mr-1 m-0 p-25"><span class="avatar-content"><i class="bx bxs-heart text-danger"></i></span></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">Application</span> has been approved</h6><small class="notification-text">6 hrs ago</small>
										</div>
									</div>
								</a><a class="d-flex justify-content-between read-notification cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar mr-1 m-0"><img src="<?php echo CxUrl::statics() ?>/app-assets/images/portrait/small/avatar-s-4.jpg" alt="avatar" height="39" width="39"></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">New file</span> has been uploaded</h6><small class="notification-text">4 hrs ago</small>
										</div>
									</div>
								</a><a class="d-flex justify-content-between cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center">
										<div class="media-left pr-0">
											<div class="avatar bg-rgba-danger m-0 mr-1 p-25">
												<div class="avatar-content"><i class="bx bx-detail text-danger"></i></div>
											</div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">Finance report</span> has been generated</h6><small class="notification-text">25 hrs ago</small>
										</div>
									</div>
								</a><a class="d-flex justify-content-between cursor-pointer" href="javascript:void(0);">
									<div class="media d-flex align-items-center border-0">
										<div class="media-left pr-0">
											<div class="avatar mr-1 m-0"><img src="<?php echo CxUrl::statics() ?>/app-assets/images/portrait/small/avatar-s-16.jpg" alt="avatar" height="39" width="39"></div>
										</div>
										<div class="media-body">
											<h6 class="media-heading"><span class="text-bold-500">New customer</span> comment recieved</h6><small class="notification-text">2 days ago</small>
										</div>
									</div>
								</a></li>
							<li class="dropdown-menu-footer"><a class="dropdown-item p-50 text-primary justify-content-center" href="javascript:void(0);">Read all notifications</a></li>
						</ul>
					</li>
					-->
					<!--
					<li class="dropdown dropdown-user nav-item">
						<a class="dropdown-toggle nav-link dropdown-user-link" href="javascript:void(0);" data-toggle="dropdown">
							<div class="user-nav d-lg-flex d-none ">
								<span class="user-name"><?php echo abreviar_nome(CxSession::get('usuario')['no_usuario']) ?></span>
								<span class="user-status"><?php echo CxSession::get('usuario')['nu_lotacao_fisica'] . '-' . substr(CxSession::get('usuario')['no_lotacao_fisica'], 0, 5) ?></span>

							</div>
						</a>
						<div class="dropdown-menu dropdown-menu-right pb-0">
							<a class="dropdown-item" href="auth-login.html"><i class="bx bx-power-off mr-50"></i> Sair</a>
						</div>
					</li>
					-->
					<!--
					<li>
						<?php echo '<img style="width: 50px;border-radius: 100px; " alt="Sem Imagem" src="data:image/jpeg;base64,' . base64_encode(CxSession::get('usuario')['foto']) . '" onerror="javascript: $(this).attr("src", "img/unknow.png");" />' ?>
					</li>
					-->
				</ul>


			</div>
		</div>
	</div>
</nav>
<!-- END: Header-->