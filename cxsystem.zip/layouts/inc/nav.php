<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-sticky navbar-light navbar-without-dd-arrow" role="navigation" data-menu="menu-wrapper">
	<!-- Horizontal menu content-->
	<div class="navbar-container main-menu-content" data-menu="menu-container">
		<!-- include <?php echo CxUrl::statics() ?>/includes/mixins-->
		<ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="filled">

			<!-- ########################## ÁREA AGRO -->
			<!-- MENU DE CARTEIRA -->
			<?php  /*if (CxSession::get('usuario')['nu_matricula'] == '111232' || CxSession::get('usuario')['nu_matricula'] == '093558' || CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '090724') { */ ?>
			<?php 
				if (
					CxSession::get('usuario')['nu_matricula'] == '145234' 
				) { ?>
					<li data-menu="">
						<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="users"></i><span data-i18n="Pages">Acompanhamento das Ações</span>
						</a>	
					</li>
					
					<li class="dropdown nav-item" data-menu="dropdown">
						<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="users"></i><span data-i18n="Pages">Configurações</span>
						</a>
						<ul class="dropdown-menu">
							<li data-menu="">
								<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('rep_eleitos:acao_index') ?>"
									data-toggle="dropdown">
									<span data-i18n="Menu Levels"><span>Novas Ações</span>
								</a>
							</li>
							<li data-menu="">
								<a class="dropdown-item align-items-center"
									href="<?php echo CxUrl::site('rep_eleitos:acoes_acompanhamento_rel') ?>" data-toggle="dropdown">
									<span></span>Editar Ações
								</a>
							</li>
						</ul>

					</li>
					</li>
			<?php } ?>
			<li class="dropdown nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="users"></i><span data-i18n="Pages">Ações de Relacionamento</span>
				</a>
				<ul class="dropdown-menu">
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('rep_eleitos:acao_index') ?>"
							data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>Painel das Ações de Relacionamento</span>
						</a>
					</li>

					<?php if (
						CxSession::get('usuario')['nu_matricula'] == '145234' || 
						CxSession::get('usuario')['nu_matricula'] == '116313' || 
						CxSession::get('usuario')['nu_matricula'] == '073936' || 
						CxSession::get('usuario')['nu_matricula'] == '109028' || 
						CxSession::get('usuario')['nu_matricula'] == '132717' || 
						CxSession::get('usuario')['nu_matricula'] == '108336' 
						) { ?>
						<li data-menu="">
							<a class="dropdown-item align-items-center"
								href="<?php echo CxUrl::site('rep_eleitos:acoes_acompanhamento_rel') ?>" data-toggle="dropdown">
								<span></span>Acompanhamento das Ações
							</a>
						</li>
					<?php } ?>
				</ul>

			</li>

			<li class="dropdown nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="comments"></i>
					<span data-i18n="Pages">Plano de Negócios 279</span>
				</a>
				<ul class="dropdown-menu">
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('rep_eleitos:plano_negocio_index') ?>"
							data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>Plano de Negócios</span>
						</a>
					</li>

					<?php if (CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '116313') { ?>
						<li data-menu="">
							<a class="dropdown-item align-items-center"
								href="<?php echo CxUrl::site('planonegocios:acompanhamento') ?>" data-toggle="dropdown">
								<span></span>Acompanhamento do Plano de Negócios 
							</a>
						</li>
					<?php } ?>
				</ul>
			</li>


			<li class="dropdown nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="globe"></i><span data-i18n="Pages">Eventos</span>
				</a>
				<ul class="dropdown-menu">
					<li data-menu="">
						<a class="dropdown-item align-items-center" href="<?php echo CxUrl::site('eventos:index') ?>"
							data-toggle="dropdown">
							<span data-i18n="Menu Levels"><span>Incluir Convidados</span>
						</a>
					</li>

					<li data-menu="">
						<a class="dropdown-item align-items-center"
							href="<?php echo CxUrl::site('eventos:indexConfirmacao') ?>" data-toggle="dropdown">
							<span></span>Confirmar Presença no Dia
						</a>
					</li>
					<li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
							class="dropdown-item align-items-center dropdown-toggle" href="#"
							data-toggle="dropdown"><span data-i18n="Material de Apoio">Relatórios</span></a>

						<ul class="dropdown-menu">
							<li data-menu="">
								<a class="dropdown-item align-items-center"
									href="<?php echo CxUrl::site('eventos:eventosImpressaoConvidados') ?>" data-toggle="dropdown">
									<span></span>
									<span data-i18n="Lista de Pré Confirmados">Lista de Pré Confirmados</span>
								</a>
							</li>
							<li data-menu=""><a class="dropdown-item align-items-center"
									href="<?php echo CxUrl::site('eventos:relatorioPresentesDiaEvento') ?>" data-toggle="dropdown">
									<span data-i18n="Lista de Presentes no Evento">Lista de Presentes no Evento</span></a>
							</li>
							<?php if (CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '116313') { ?>

							<?php } ?>
						</ul>
					</li>
				</ul>
			</li>

			<?php if (CxSession::get('usuario')['nu_matricula'] == '145234' || CxSession::get('usuario')['nu_matricula'] == '116313') { ?>

				<!-- <li class="" data-menu="">
					<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:acao_index_homol') ?>" >
						<i class="menu-livicon" data-icon="users"></i> 
						<span >Painel das Ações de Relacionamento</span>
					</a>		
				</li> 

				
				<li class="" data-menu="">
					<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:plano_negocio_index_homol') ?>" >
						<i class="menu-livicon" data-icon="comments"></i> 
						<span >Plano de Negócios 278</span>
					</a>		
				</li>   -->


			<?php } ?>

			<?php // if (CxSession::get('usuario')['nu_matricula'] == '145234' ) { 
			?>
			<!--<li class="" data-menu="">
					<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:painel_gestao_index') ?>">
						<i class="menu-livicon" data-icon="notebook"></i> 
						<span>Painel de Gestão e Acompanhamento</span>
					</a>			
				</li>-->
			<?php //} 
			?>



			<!-- <li class="dropdown nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">
					<i class="menu-livicon" data-icon="users"></i><span data-i18n="Pages">Recepção Eleitos</span></a>
				<ul class="dropdown-menu">
					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:index') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="screenshot"></i> 
						<span data-i18n="Forms &amp; Tables">Acompanhamento da Recepção</span></a>		
					</li> 
					
					 <li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:acao_index') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="screenshot"></i> 
						<span data-i18n="Forms &amp; Tables">Ações de Relacionamento</span></a>		
					</li> 
					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:plano_negocio_index') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="screenshot"></i> 
						<span data-i18n="Forms &amp; Tables">Plano de Negócios</span></a>		
					</li>  
					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('rep_eleitos:painel_gestao_index') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="screenshot"></i> 
						<span data-i18n="Forms &amp; Tables">Painel de Gestão e Acompanhamento</span></a>		
					</li> 

				</ul>
			</li> -->
			<!-- 
			<li class="dropdown nav-item" data-menu="dropdown">
				<a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="menu-livicon" data-icon="globe"></i><span data-i18n="Pages">Metas Gov</span></a>
				<ul class="dropdown-menu">
					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('metas:index') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="screenshot"></i> 
						<span data-i18n="Forms &amp; Tables">Distribuição Meta</span></a>		
					</li> 

					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('metas:orcamento') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="like"></i>
						<span data-i18n="Forms &amp; Tables">Nova Distribuição Meta</span></a>		
					</li>

					<li class=" nav-item" data-menu="dropdown">
						<a class="dropdown-item nav-link" href="<?php echo CxUrl::site('metas:distribuicao') ?>" data-toggle="dropdown">
							<i class="menu-livicon" data-icon="like"></i>
						<span data-i18n="Forms &amp; Tables">Distribuição</span></a>		 
					</li>
				</ul>
			</li> -->

			<!-- MENU RESTRITO -->
			<!--
			<?php if (CxSession::get('usuario')['nu_lotacao_fisica'] == '5197') { ?>
				<li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="menu-livicon" data-icon="shield"></i><span data-i18n="Charts &amp; Maps">Restrito</span></a>
					<ul class="dropdown-menu">
						<li data-menu=""><a class="dropdown-item align-items-center" href="#" target="_self" data-toggle="dropdown">Aniversariantes</a></li>

					</ul>
				</li>
			<?php } ?>
			-->


		</ul>
	</div>
	<!-- /horizontal menu content-->
</div>

<script type="text/javascript">

</script>