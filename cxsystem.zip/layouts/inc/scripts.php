  
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/jquery/jquery.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/jquery/jquery-ui.js"></script>
  
  <!-- BEGIN: Vendor JS -->
    
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/vendors.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/pickers/pickadate/picker.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/pickers/pickadate/picker.date.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/pickers/pickadate/picker.time.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/pickers/pickadate/legacy.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/extensions/moment.min.js"></script>
    <!-- END: Page Vendor JS-->

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/datepicker/bootstrap-datepicker.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/datepicker/bootstrap-datepicker.pt-BR.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/jquery.mask.js"></script> 

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/lodash.min.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/extensions/moment.min.js"></script>  
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/pickers/daterange/daterangepicker.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/extensions/dragula.min.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/extensions/sweetalert2.all.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/extensions/toastr.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js"></script>


    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/datatables/dataTables.select.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/configs/horizontal-menu.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/core/app-functions.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/forms/select/form-select2.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/core/app.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/components.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/footer.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/html2canvas.min.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.js"></script>

   <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/charts/apexcharts.min.js"></script>

    
  

    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/pages/table-extended.min.js"></script> -->
   <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/datatables/datatable.js"></script> -->
    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/pages/app-todo.js"></script> -->

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/plugins/datepicker/datepicker3.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/pickers/pickadate/pickadate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/pickers/daterange/daterangepicker.css">
 -->

    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <!-- 

    
 




 -->
    <!-- -->

    <!-- 

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/pickers/dateTime/pick-a-datetime.js"></script>

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/calendar/tui-time-picker.min.js"></script>
  
    
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/jcarousel.js"></script>
    

 
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/charts/chartist.min.js"></script>
 
    



 -->
    <!-- Calendar -->
    
    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/calendar/tui-code-snippet.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/calendar/tui-dom.js"></script>
 
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/calendar/chance.min.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/calendar/tui-calendar.min.js"></script> -->

    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <!-- 

    <script src="<?php echo CxUrl::statics() ?>/app-assets/vendors/js/charts/apexcharts.min.js"></script> -->

    <!-- JSPDF -->
    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/jspdf.min.js"></script>
   

    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/extensions/bootstrap-treeview.min.js"></script>  --> 


    


    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/forms/wizard-steps.js"></script>
    <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/forms/wizard-steps.min.js"></script> -->
    <!-- END: Page JS-->


    <!-- BEGIN: Page JS-->
    <!-- <script src="<?php echo CxUrl::statics() ?>/app-assets/js/scripts/pages/dashboard-analytics.js"></script> -->
    <!-- END: Page JS-->

   
   <!-- BEGIN: Page JS-->    
    <!-- -->


   

    
   

    <!-- JQUERY MASK -->
    

    

    <!-- END: Page JS-->
    