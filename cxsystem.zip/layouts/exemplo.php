<?php

/**
 * Essas três variáveis são carregadas pelo template 'default.php'
 * nela nós colocamos o caminho a partir de 'scripts' para os arquivos que queremos importar.
 * 
 * Os arquivos que estiverem em $css_extras e $js_extras são carregados no começo da página.
 * Os arquivos que estiverem em $js_cripts_extras são carregados no final da página.
 * 
 * Essas três variáveis é a solução para quando a aplicação precisar de js e css específicos.
 * Quando a app precisar disso, ela precisa criar um novo arquivo em layouts seguindo esse como exemplo.
 */

$css_extras = [
    'app/exemplo/css/exemplo_css.css'
];

$js_extras = [
    'app/exemplo/js/exemplo_js.js'
];

$js_scripts_extras = [
    'app/exemplo/js/exemplo_script_js.js'
];

include_once('default.php');
