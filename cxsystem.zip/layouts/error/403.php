<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
    <title>Error 403</title>
    <link rel="apple-touch-icon" href="<?php echo CxUrl::statics() ?>/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="../../../app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/vendors/css/vendors.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/themes/semi-dark-layout.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/app-assets/css/core/menu/menu-types/horizontal-menu.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo CxUrl::statics() ?>/assets/css/style.css">
    <!-- END: Custom CSS-->

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="horizontal-layout horizontal-menu navbar-static 1-column   footer-static bg-full-screen-image  blank-page" data-open="hover" data-menu="horizontal-menu" data-col="1-column">
    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <!-- not authorized start -->
                <section class="row flexbox-container">
                    <div class="col-xl-7 col-md-8 col-12">
                        <div class="card bg-transparent shadow-none">
                            <div class="card-body text-center bg-transparent">
                                <img src="<?php echo CxUrl::statics()  ?>/app-assets/images/pages/not-authorized.png" class="img-fluid" alt="not authorized" width="400">
                                <h1 class="my-2 error-title">Usuário sem permissão</h1>
                                <p>Você não possui permissão para acessar essa página</p>
                                <a href="<?php echo CxUrl::site('pagina_inicial') ?>" class="btn btn-primary round glow mt-2">Ir para a Página Inicial</a>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- not authorized end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

</body>
<!-- END: Body-->

</html>