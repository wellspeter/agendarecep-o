<!DOCTYPE html>
<html lang="pt-br">

<head>

    <?php
    if (isset($css_extras)) {
        foreach ($css_extras as $css_file) {
            $file = CxUrl::statics() . '/' . $css_file;
            echo "<link rel='stylesheet' type='text/css' href='" . $file . "'>";
        }
    }
    ?>

    <?php require_once('inc/head.php'); ?>

    <?php
    if (isset($js_extras)) {
        foreach ($js_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>

</head>

<body data-statics-url="<?php echo CxUrl::statics() ?>" class="horizontal-layout horizontal-menu navbar-static 2-columns footer-static pace-done" data-open="hover" data-menu="horizontal-menu" data-col="2-columns">

    <?php require_once('inc/header.php'); ?>

    <?php require_once('inc/nav.php'); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">    
            </div>
            <div class="content-body">

                <?php require __DIR__ . '/../' . CxRouter::get_current_file(); ?>

            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <?php require_once('inc/footer.php'); ?>

    <?php require_once('inc/scripts.php'); ?>

    <?php
    if (isset($js_scripts_extras)) {
        foreach ($js_scripts_extras as $js_file) {
            $file = CxUrl::statics() . '/' . $js_file;
            echo "<script src='" . $file . "'></script>";
        }
    }
    ?>
</body>

</html>