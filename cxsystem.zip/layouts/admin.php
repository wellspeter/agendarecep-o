<!DOCTYPE html>
<html lang="pt-br">

<body>
    <h1>PAINEL ADMINISTRATIVO</h1>
    <h1>Conteudo</h1>

    <?php require __DIR__ . '/../' . CxRouter::get_current_file(); ?>

    <h1>Footer</h1>
</body>

</html>