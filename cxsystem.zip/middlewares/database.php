<?php

class DataBase
{
    public static $connection = array();

    public static function get_connection($database)
    {
        if (!array_key_exists($database, DataBase::$connection)) {
            DataBase::$connection[$database] = null;
        }


        if (DataBase::$connection[$database] == null) {
            $credentials = CxConfig::configs($database);
            try {
                $conn_string = "sqlsrv:Server=" . $credentials['SERVIDOR'] . ";Database=" . $credentials['BANCO_DE_DADOS'];
                DataBase::$connection[$database] = new PDO($conn_string, $credentials['USUARIO'], $credentials['SENHA']);

                DataBase::$connection[$database]->setAttribute(PDO::SQLSRV_ATTR_ENCODING, PDO::SQLSRV_ENCODING_UTF8);
                DataBase::$connection[$database]->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
                print_r("Sistema temporariamente indisponivel");
                die();
            }
        }

        return DataBase::$connection[$database];
    }
}
