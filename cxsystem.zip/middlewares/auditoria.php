<?php

class LogDAO extends DAO
{

    public function __construct()
    {
        parent::__construct('DATABASE');
    }


    public function gravar_log_aud()
    {
        
        if(isset(CxSession::get('usuario')['nu_matricula'])){
            $sql = "
            INSERT INTO [DB5131_GOV].[recepcao].[T007_LOG_SISTEMA]
                ([NU_MATRICULA]
                ,[DE_URL]
                ,[DT_ACESSO])
            VALUES
                (:matricula
                ,:url
                , GETDATE())
            ";

            return $this->inserir(
                $sql,
                array(
                    ':matricula' => CxSession::get('usuario')['nu_matricula'],
                    ':url' => $_SERVER['REQUEST_URI'],
                )
            );
        } else{
            $sql = "
            INSERT INTO [DB5131_GOV].[recepcao].[T007_LOG_SISTEMA]
                ([NU_MATRICULA]
                ,[DE_URL]
                ,[DT_ACESSO])
            VALUES
                (:matricula
                ,:url
                , GETDATE())
            ";

            return $this->inserir(
                $sql,
                array(
                    ':matricula' => '999999',
                    ':url' => $_SERVER['REQUEST_URI'],
                )
            );

          
        } 

        return true;
    }
  

}

function strposa($haystack, $needles=array(), $offset=0) {
	$chr = array();
	foreach($needles as $needle) {
			$res = strpos($haystack, $needle, $offset);
			if ($res !== false) $chr[$needle] = $res;
	}
	if(empty($chr)) return false;
	return min($chr);
}

$string = $_SERVER['REQUEST_URI'];
$array  = array('.json', '.png', '.css', '.js');

if (!strposa($string, $array, 1)) {
    $logDAO = new LogDAO();
    $logDAO->gravar_log_aud();
    unset($logDAO);
} 
















