<?php

function middleware_login()
{
    //print_r($_SERVER);
    //var_dump($_SERVER);

    //verificar se tem sessão salva ou ja existe
    $usuarioLogado = CxSession::get('usuario')['nu_matricula'];

    if($usuarioLogado){
        //se existe um usuario, nao faz nova verificação
        //echo "usuario existe: ".$usuarioLogado;
        return;
    }
  
    if( isset($_SERVER["LOGON_USER"]) ) {
        $username = substr(
                $_SERVER["LOGON_USER"],
                strpos($_SERVER["LOGON_USER"], "\\") + 1,
                strlen($_SERVER["LOGON_USER"]) - strpos($_SERVER["LOGON_USER"], "\\")
            ); 
            // echo "usuario logado: ";
            // echo $username ;
    }else{
        echo "erro usuario logado: ";
    }

    $username = substr(
        $_SERVER["LOGON_USER"],
        strpos($_SERVER["LOGON_USER"], "\\") + 1,
        strlen($_SERVER["LOGON_USER"]) - strpos($_SERVER["LOGON_USER"], "\\")
    ); // pega usuario da maquina

    if ($username == 'c145234') {
        //$username = 'c058012'; c051125@corp.caixa.gov.br
        //$username = 'c042127'; 
    }
    //echo $username ;
    
    //$username = 'c145234'; 

    $usuario = get_usuario_ldap($username);
    //echo $username ;

    if ($usuario) {
        CxSession::set('usuario', $usuario);
    } else {
        // Usuario nao encontrado
        //echo  $username;
        echo "Usuário não Encontrado";
        die();
    }
}

middleware_login();
