/*=========================================================================================
    File Name: app-orcamento.js
    Description: app-orcamento
    ----------------------------------------------------------------------------------------
    Item Name: Frest HTML Admin Template
   Version: 1.0
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/
// Todo App variables
var orcamentoNewTasksidebar = $(".orcamento-new-task-sidebar"),
  appContentOverlay = $(".app-content-overlay"),
  sideBarLeft = $(".sidebar-left"),
  orcamentoTaskListWrapper = $(".orcamento-task-list-wrapper"),
  orcamentoItem = $(".orcamento-item"),
  updateTodo = $(".update-orcamento"),
  addTodo = $(".add-orcamento"),
  markCompleteBtn = $(".mark-complete-btn"),
  newTaskTitle = $(".new-task-title"),
  taskTitle = $(".task-title"),
  noResults = $(".no-results"),
  assignedAvatarContent = $(".assigned .avatar .avatar-content"),
  orcamentoAppMenu = $(".orcamento-app-menu");

// badge colors object define here for badge color
var badgeColors = {
  "Frontend": "badge-light-primary",
  "Backend": "badge-light-success",
  "Issue": "badge-light-danger",
  "Design": "badge-light-warning",
  "Wireframe": "badge-light-info",
}

$(function () {
  "use strict";

  // dragable list
  dragula([document.getElementById("orcamento-task-list-drag")], {
    moves: function (el, container, handle) {
      return handle.classList.contains("handle");
    }
  });

  // select label
  selectAssignLable.select2({
    dropdownAutoWidth: true,
    width: '100%'
  });

  // Sidebar scrollbar
  if ($('.sidebar-menu-list').length > 0) {
    var sidebarMenuList = new PerfectScrollbar('.sidebar-menu-list', {
      theme: "dark",
      wheelPropagation: false
    });
  }

  //  New task scrollbar
  if (orcamentoNewTasksidebar.length > 0) {
    var orcamento_new_task_sidebar = new PerfectScrollbar('.orcamento-new-task-sidebar', {
      theme: "dark",
      wheelPropagation: false
    });
  }

  // Task list scrollbar
  if ($('.orcamento-task-list').length > 0) {
    var sidebar_orcamento = new PerfectScrollbar('.orcamento-task-list', {
      theme: "dark",
      wheelPropagation: false
    });
  }

  // New compose message compose field
  var composeEditor = new Quill('.snow-container .compose-editor', {
    modules: {
      toolbar: '.compose-quill-toolbar'
    },
    placeholder: 'Add Description..... ',
    theme: 'snow'
  });

  //Assigner Comment Quill editor
  var commentEditor = new Quill('.snow-container .comment-editor', {
    modules: {
      toolbar: '.comment-quill-toolbar'
    },
    placeholder: 'Write a Comment...',
    theme: 'snow'
  });

  // **************Sidebar Left**************//
  // -----------------------------------------

  // Main menu toggle should hide app menu
  // $('.menu-toggle').on('click', function () {
  //   sideBarLeft.removeClass('show');
  //   appContentOverlay.removeClass('show');
  //   orcamentoNewTasksidebar.removeClass('show');
  // });

  //on click of app overlay removeclass show from sidebar left and overlay
  appContentOverlay.on('click', function () {
    sideBarLeft.removeClass('show');
    appContentOverlay.removeClass('show');
  });

  // Add class active on click of sidebar menu's filters
  orcamentoAppMenu.find(".list-group a").on('click', function () {
    var $this = $(this);
    orcamentoAppMenu.find(".active").removeClass('active');
    $this.addClass("active")
    // if active class available icon color primary blue else gray
    if ($this.hasClass('active')) {
      $this.find(".livicon-evo").updateLiviconEvo({
        strokeColor: '#5A8DEE'
      });
      orcamentoAppMenu.find(".list-group a").not(".active").find(".livicon-evo").updateLiviconEvo({
        strokeColor: '#475f7b'
      });
    }
  });

  //On compose btn click of compose mail visible and sidebar left hide
  $('.add-task-btn').on('click', function () {
    //show class add on new task sidebar,overlay
    orcamentoNewTasksidebar.addClass('show');
    appContentOverlay.addClass('show');
    sideBarLeft.removeClass('show');
    taskTitle.focus();
    //d-none add on avatar and remove from avatar-content
    avatarUserImage.addClass("d-none");
    assignedAvatarContent.removeClass("d-none");
    //select2 value null assign
    selectUsersName.val(null).trigger('change');
    selectAssignLable.val(null).trigger('change');
    //update button has add class d-none remove from add TODO
    updateTodo.addClass("d-none");
    addTodo.removeClass("d-none");
    //mark complete btn should hide & new task title will visible
    markCompleteBtn.addClass("d-none");
    newTaskTitle.removeClass("d-none");
    //Input field Value empty
    taskTitle.val("");
    var compose_editor = $(".compose-editor .ql-editor");
    compose_editor[0].innerHTML = "";
    var comment_editor = $(".comment-editor .ql-editor");
    comment_editor[0].innerHTML = "";
    selectAssignLable.attr("disabled", "true");
  });

  // On sidebar close click hide sidebarleft and overlay
  $(".sidebar-close-icon").on('click', function () {
    sideBarLeft.removeClass('show');
    appContentOverlay.removeClass('show');
  });

  // **************New Task sidebar**************//
  // ---------------------------------------------

  // add new task
  addTodo.on("click", function () {
    // check task assigned or not
    function renderAvatar(src) {
      if (src !== undefined) {
        return '<img src="' + src + '"alt="avatar" height="30" width="30" >'
      }
      else {
        return '<div class="avatar-content"><i class="bx bx-user font-medium-4"></i></div>'
      }
    };
    // if add task field are fiill and create a new task
    if (taskTitle.val().length > 0) {
      var titleTask = taskTitle.val(),
        selectAssign = $(".select2-users-name option:selected").val(),
        $randomID = Math.floor((Math.random() * 100) + Date.now()), //generate random id
        selectedVal = $(".select2-assign-label option:selected"),
        selectedTags = [];
      selectedVal.each(function () {
        selectedTags.push($(this).text());
      })
      var newTags = selectedTags.map(function (tag) {
        // map through every tag and create badges accordingly.
        return '<span class="badge ' + badgeColors[tag] + ' badge-pill ml-25"> ' + tag + ' </span>' //badge created here
      })

      var avatarSRC = orcamentoTaskListWrapper.find("[data-name='" + selectAssign + "']").find(".avatar img").attr("src"); //Img src find if data name matches with list
      orcamentoTaskListWrapper.append(
        // append a new task in task list
        '<li class="orcamento-item no-animation" data-name="' + selectAssign + '">' +
        '<div class="orcamento-title-wrapper d-flex justify-content-between align-items-center">' +
        '<div class="orcamento-title-area d-flex">' +
        '<i class="bx bx-grid-vertical handle"></i>' +
        '<div class="checkbox">' +
        '<input type="checkbox" class="checkbox-input" id="' + $randomID + '">' +
        '<label for="' + $randomID + '"></label>' + '</div>' +
        '<p class="orcamento-title mx-50 m-0 truncate">' + titleTask + '</p>' +
        '</div>' +
        '<div class="orcamento-item-action d-flex align-items-center">' + newTags.join("") +
        '<div class="avatar ml-1">' + renderAvatar(avatarSRC) +
        '</div>' +
        '<a class="orcamento-item-favorite ml-50">' +
        '<i class="bx bx-star"></i>' + '</a>' +
        '<a class="orcamento-item-delete ml-50">' + '<i class="bx bx-trash"></i>' + '</a>' +
        '</div></div></li>');
      // new task sidebar, overlay hide
      orcamentoNewTasksidebar.removeClass('show');
      appContentOverlay.removeClass('show');
      selectAssignLable.attr("disabled", "true");
    }
    else {
      // new task sidebar, overlay hide
      orcamentoNewTasksidebar.removeClass('show');
      appContentOverlay.removeClass('show');
      selectAssignLable.attr("disabled", "true");
    }
  });

  // On Click of Close Icon btn, cancel btn and overlay remove show class from new task sidebar and overlay
  // and reset all form fields
  $(".close-icon, .cancel-btn, .app-content-overlay, .mark-complete-btn").on('click', function () {
    orcamentoNewTasksidebar.removeClass('show');
    appContentOverlay.removeClass('show');
    setTimeout(function () {
      orcamentoNewTasksidebar.find('textarea').val("");
      var compose_editor = $(".compose-editor .ql-editor");
      compose_editor[0].innerHTML = "";
      var comment_editor = $(".comment-editor .ql-editor");
      comment_editor[0].innerHTML = "";
      selectAssignLable.attr("disabled", "true");
    }, 100)
  });

  // on click of add label icon select 2 display
  $(".add-tags").on("click", function () {
    if (selectAssignLable.is('[disabled]')) {
      selectAssignLable.removeAttr("disabled");
    }
    else {
      selectAssignLable.attr("disabled", "true");
    }
  });

  // Update Task
  updateTodo.on("click", function () {
    orcamentoNewTasksidebar.removeClass('show');
    appContentOverlay.removeClass('show');
    selectAssignLable.attr("disabled", "true");
  });

  // ************Rightside content************//
  // -----------------------------------------

  // Filtro de pesquisa para lista de produtos
  $(document).on("keyup", ".orcamento-search", function () {
    orcamentoItem = $(".orcamento-item");
    $('.orcamento-item').css('animation', 'none')
    var value = $(this).val().toLowerCase();
    if (value != "") {
      orcamentoItem.filter(function () {
        $(this).toggle($(this).text().toLowerCase().includes(value));
      });
      var tbl_row = $(".orcamento-item:visible").length; 

      //Verifique se a tabela tem linha ou não
      if (tbl_row == 0) {
        if (!noResults.hasClass('show')) {
          noResults.addClass('show');
        }
      }
      else {
        noResults.removeClass('show');
      }
    }
    else {
      // Se a caixa de filtro estiver vazia
      orcamentoItem.show();
      if (noResults.hasClass('show')) {
        noResults.removeClass('show');
      }
    }
  });
  // on Todo Item click show data in sidebar
  var globalThis = ""; // Global variable use in multiple function
  orcamentoTaskListWrapper.on('click', '.orcamento-item', function (e) {
    var $this = $(this);
    globalThis = $this;

    orcamentoNewTasksidebar.addClass('show');
    appContentOverlay.addClass('show');

    var orcamentoTitle = $this.find(".orcamento-title").text();
    taskTitle.val(orcamentoTitle);
    var compose_editor = $(".compose-editor .ql-editor");
    compose_editor[0].innerHTML = orcamentoTitle;

    // if avatar is available
    if ($this.find(".avatar img").length) {
      avatarUserImage.removeClass("d-none");
      assignedAvatarContent.addClass("d-none");
    }
    else {
      avatarUserImage.addClass("d-none");
      assignedAvatarContent.removeClass("d-none");
    }
    //current task's image source assign to variable
    var avatarSrc = $this.find(".avatar img").attr('src');

    avatarUserImage.attr("src", avatarSrc);
    var assignName = $this.attr('data-name');

    $(".select2-users-name").val(assignName).trigger('change');

    // badge selected value check
    if ($(this).find('.badge').length) {
      //if badge available in current task
      var badgevalAll = [];
      var selected = $(this).find('.badge');

      selected.each(function () {
        var badgeVal = $(this).text();
        badgevalAll.push(badgeVal);
        selectAssignLable.val(badgevalAll).trigger("change");
      });
    }
    else {
      selectAssignLable.val(null).trigger("change");
    }
    // update button has remove class d-none & add class d-none in add orcamento button
    updateTodo.removeClass("d-none");
    addTodo.addClass("d-none");
    markCompleteBtn.removeClass("d-none");
    newTaskTitle.addClass("d-none");

  }).on('click', '.orcamento-item-favorite', function (e) {
    e.stopPropagation();
    $(this).toggleClass("warning");
    $(this).find("i").toggleClass("bxs-star");
  }).on('click', '.orcamento-item-delete', function (e) {
    e.stopPropagation();
    $(this).closest('.orcamento-item').remove();
  }).on('click', '.checkbox', function (e) {
    e.stopPropagation();
  });

  // Complete task strike through
  orcamentoTaskListWrapper.on('click', ".orcamento-item .checkbox-input", function (e) {
    $(this).closest('.orcamento-item').toggleClass("completed");
  });

  // Complete button click action
  markCompleteBtn.on("click", function () {
    globalThis.addClass("completed");
    globalThis.find(".checkbox-input").prop("checked", true);
    selectAssignLable.attr("disabled", "true");
  });

  // Todo sidebar toggle
  $('.sidebar-toggle').on('click', function (e) {
    e.stopPropagation();
    sideBarLeft.toggleClass('show');
    appContentOverlay.addClass('show');
  });

  // sorting task list item
  $(".ascending").on("click", function () {
    orcamentoItem = $(".orcamento-item");
    $('.orcamento-item').css('animation', 'none')
    orcamentoItem.sort(sort_li).appendTo(orcamentoTaskListWrapper);
    function sort_li(a, b) {
      return ($(b).find('.orcamento-title').text().toLowerCase()) < ($(a).find('.orcamento-title').text().toLowerCase()) ? 1 : -1;
    }
  });

  // descending sorting
  $(".descending").on("click", function () {
    orcamentoItem = $(".orcamento-item");
    $('.orcamento-item').css('animation', 'none')
    orcamentoItem.sort(sort_li).appendTo(orcamentoTaskListWrapper);
    function sort_li(a, b) {
      return ($(b).find('.orcamento-title').text().toLowerCase()) > ($(a).find('.orcamento-title').text().toLowerCase()) ? 1 : -1;
    }
  });
});

$(window).on("resize", function () {
  // remove show classes from sidebar and overlay if size is > 992
  if ($(window).width() > 992) {
    if (appContentOverlay.hasClass('show')) {
      sideBarLeft.removeClass('show');
      appContentOverlay.removeClass('show');
      orcamentoNewTasksidebar.removeClass("show");
    }
  }
});

