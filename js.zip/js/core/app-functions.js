var lContinua = "false";

var conteudo = 				"<div id='Carregando' align='center' style='display:block; margin-top:100px;margin-bottom:20px;'><br><br>";
    conteudo = conteudo + 		"<font face='Arial, Tahoma' size='6' color='#4A4A4A'><b>Carregando...</b></font><br><br>";
    conteudo = conteudo +		"<div class='sk-spinner sk-spinner-wave'>";
    conteudo = conteudo +		"	<div class='sk-rect1'></div>";
    conteudo = conteudo +		"	<div class='sk-rect2'></div>";
    conteudo = conteudo +		"	<div class='sk-rect3'></div>";
    conteudo = conteudo +		"	<div class='sk-rect4'></div>";
    conteudo = conteudo +		"	<div class='sk-rect5'></div>";
    conteudo = conteudo +		"</div>";
    conteudo = conteudo +	"</div>";

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function LoadPag(div, pag, filtro) {
	Pace.restart();
	$.ajax({url: pag, async: true, error: function(xhr){
		$(div).load('../erro.asp', {CodErro: xhr.status});
		}}).success(function(resp){
		$(div).html(resp);
	});
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function LoadPagAsync(div, pag, filtro) {
	Pace.restart();
	$.ajax({url: pag, async: true, error: function(xhr){
		$(div).load('../erro.asp', {CodErro: xhr.status});
		}}).success(function(resp){
		$(div).html(resp);
	});
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

// Mensagem Alerta Estilo.
function MensagemUser(cTitulo, cTexto, cTipo) {

	swal({
		title: cTitulo,
		text: cTexto,
		type: cTipo
	});
	
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

// Mensagem Alerta Estilo.
function MsgUserQuest(cTitulo, cTexto, cTipo) {

	swal({
	  title: cTitulo,
	  text: cTexto,
	  type: cTipo,
	  showCancelButton: true,
	  //confirmButtonClass: "btn-success",
	  confirmButtonColor: "#00a65a",
	  cancelButtonColor: "#dd4b39",
	  confirmButtonText: "Sim, Gerar Excel!",
	  cancelButtonText: "Cancelar",
	  closeOnConfirm: true,
	  closeOnCancel: true
	},
	function(isConfirm) {
	  if (isConfirm) {
		  GeraExcel()
		//swal("Deleted!", "Your imaginary file has been deleted.", "success");
	  //} else {
		//swal("Cancelled", "Your imaginary file is safe :)", "error");
	  }
	});	
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function MsgUser(cTitulo, cTexto, cTipo) {
	
	
	swal({
	  title: cTitulo,
	  text: cTexto,
	  type: cTipo,
	  showCancelButton: true,
	  //confirmButtonClass: "btn-success",
	  confirmButtonColor: "#00a65a",
	  cancelButtonColor: "#dd4b39",
	  confirmButtonText: "Sim, desejo continuar!",
	  cancelButtonText: "Cancelar",
	  closeOnConfirm: true,
	  closeOnCancel: true
	},
	function(isConfirm) {
		if (isConfirm) {
			lContinua = "true";
		//} else {
		//	lContinua = "false";
		}
	});	
}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
/*
 ********** Menu *********
*/
function CarregaPagina(cCodItem) {
	var cPag = '';
	
	if (cCodItem == 0) {
		cPag = "conteudo.asp"
	} else if (cCodItem == 1) {
		cPag = "visao01.asp"
	}else if (cCodItem == 7) {
		cPag = "visao01_new.asp" 
	} else if (cCodItem == 2) {
		cPag = "officer.asp"
	} else if (cCodItem == 3) {
		cPag = "Lista_Geral.asp"
	} else if (cCodItem == 4) {
		cPag = "cliente_dados.asp"
	} else if (cCodItem == 5) {
		cPag = "sunep_visao.asp"
	} else if (cCodItem == 6) {
		cPag = "officer_visao.asp"	
	} else if (cCodItem == 8) {
		cPag = "destaques.asp"
	} else if (cCodItem == 9) {
		cPag = "officer_01.asp"
	} else if (cCodItem == 10) {
		cPag = "sn_sr_visao.asp?Unidade=5194&TipoUnidade=SN"
	} else if (cCodItem == 11) {
		cPag = "pa_age_visao.asp?Unidade=3337&TipoUnidade=PA"
	} else if (cCodItem == 20) {
		cPag = "cliente_01.asp"
	} else if (cCodItem == 21) {
		cPag = "SR_01.asp"
	} else if (cCodItem == 22) {
		cPag = "relatorio_produtos.asp"
	}else if (cCodItem == 23) {
		cPag = "cliente_02.asp"
	}else if (cCodItem == 24) {
		cPag = "relatorio_agrupado.asp"
	}else if (cCodItem == 25) {
		cPag = "inclusao_cliente.asp"
	}else if (cCodItem == 26) {
		cPag = "lista_clientes_atacado_pre_cadastro.asp"
	}else if (cCodItem == 27) {
		cPag = "lista_clientes_atacado_pre_cadastro_gestor.asp"
	}else if (cCodItem == 28) {
		cPag = "migracao_carteiras.asp"
	} else if (cCodItem == 99) {
		cPag = "manutencao.asp"
	} else if (cCodItem == 100) {
		cPag = "lista_acessos.asp"
	} else if (cCodItem == 29) {
		cPag = "oportunidades.asp"
	}
	
	/*
	var conteudo = 				"<div id='Carregando' align='center' style='display:block; margin-top:100px;margin-bottom:20px;'><br><br>"
		conteudo = conteudo + 		"<font face='Arial, Tahoma' size='2' color='#4A4A4A'><b>Carregando...</b></font><br><br>"
		conteudo = conteudo +		"<i class='fa fa-refresh fa-spin fa-5x'></i>"
		conteudo = conteudo +	"</div>"
	*/
	/*var conteudo = 				"<div id='Carregando' align='center' style='display:block; margin-top:100px;margin-bottom:20px;'><br><br>";
		conteudo = conteudo + 		"<font face='Arial, Tahoma' size='6' color='#4A4A4A'><b>Carregando...</b></font><br><br>";
		conteudo = conteudo +		"<div class='sk-spinner sk-spinner-wave'>";
		conteudo = conteudo +		"	<div class='sk-rect1'></div>";
		conteudo = conteudo +		"	<div class='sk-rect2'></div>";
		conteudo = conteudo +		"	<div class='sk-rect3'></div>";
		conteudo = conteudo +		"	<div class='sk-rect4'></div>";
		conteudo = conteudo +		"	<div class='sk-rect5'></div>";
		conteudo = conteudo +		"</div>";
		conteudo = conteudo +	"</div>";*/
	
	
	$('#conteudo').html('');
	$('#conteudo').html(conteudo);
	LoadPag('#conteudo', cPag);
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
function Detalhes_Item(cFunc, cUnid, cCart) {

	// Crédito
	if (cFunc == "cre") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/credito.asp?Unidade='+cUnid+'&Carteira='+cCart);
	} else if (cFunc == "rps") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/rps.asp?Unidade='+cUnid+'&Carteira='+cCart);
	} else if (cFunc == "cap") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/Captacao.asp?Unidade='+cUnid+'&Carteira='+cCart);
	} else if (cFunc == "seg") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/Seguridade.asp?Unidade='+cUnid+'&Carteira='+cCart);
	} else if (cFunc == "rot") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/Rotativo.asp?Unidade='+cUnid+'&Carteira='+cCart);		
	} else if (cFunc == "mob") {
		$(".modal-content").html(conteudo);
		$("#Modal01").modal({});
		LoadPag('.modal-content', 'popup/Mobilizadores.asp?Unidade='+cUnid+'&Carteira='+cCart);		
	} else {
		MensagemUser("Atenção", "Em Construção!", "warning");
	}

}
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function AnoMesParaTexto(iAnoMes) {
    iAnoMes = iAnoMes.toString();
    var ano = iAnoMes.substr(0, 4);
    var mes = iAnoMes.substr(4, 2);
    
    nomeMes = "";

    switch (parseInt(mes)) {
        case 1:
            nomeMes = "Jan";
            break;
        case 2:
            nomeMes = "Fev";
            break;
        case 3:
            nomeMes = "Mar";
            break;
        case 4:
            nomeMes = "Abr";
            break;
        case 5:
            nomeMes = "Mai";
            break;
        case 6:
            nomeMes = "Jun";
            break;
        case 7:
            nomeMes = "Jul";
            break;
        case 8:
            nomeMes = "Ago";
            break;
        case 9:
            nomeMes = "Set";
            break;
        case 10:
            nomeMes = "Out";
            break;
        case 11:
            nomeMes = "Nov";
            break;
        case 12:
            nomeMes = "Dez";
            break;
        default:
            nomeMes = "Mês inexistente";
    }
    
    return nomeMes + "/" + ano;
}

function formataValor(valor) {
    if (valor >= 1000000000)
        valor_formatado = (valor / 1000000000).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + " BI";
    else if (valor >= 1000000)
        valor_formatado = (valor / 1000000).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + " MM"
    else 
        valor_formatado = valor.toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})
    return valor_formatado
}